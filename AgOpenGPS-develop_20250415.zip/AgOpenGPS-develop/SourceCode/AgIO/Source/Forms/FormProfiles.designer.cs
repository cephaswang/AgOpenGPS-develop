﻿namespace AgIO
{
    partial class FormProfiles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cboxOverWrite = new System.Windows.Forms.ComboBox();
            this.tboxCreateNew = new System.Windows.Forms.TextBox();
            this.btnSaveNewProfile = new System.Windows.Forms.Button();
            this.labelNew = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSerialCancel = new System.Windows.Forms.Button();
            this.labelSaveAs = new System.Windows.Forms.Label();
            this.tboxSaveAs = new System.Windows.Forms.TextBox();
            this.btnSaveAs = new System.Windows.Forms.Button();
            this.lblCurrentProfile = new System.Windows.Forms.Label();
            this.labelCurent = new System.Windows.Forms.Label();
            this.cboxChooseExisting = new System.Windows.Forms.ComboBox();
            this.labelOpen = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cboxOverWrite
            // 
            this.cboxOverWrite.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboxOverWrite.Font = new System.Drawing.Font("Tahoma", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboxOverWrite.FormattingEnabled = true;
            this.cboxOverWrite.Location = new System.Drawing.Point(624, 98);
            this.cboxOverWrite.Name = "cboxOverWrite";
            this.cboxOverWrite.Size = new System.Drawing.Size(439, 43);
            this.cboxOverWrite.TabIndex = 212;
            this.cboxOverWrite.SelectedIndexChanged += new System.EventHandler(this.cboxOverWrite_SelectedIndexChanged);
            // 
            // tboxCreateNew
            // 
            this.tboxCreateNew.BackColor = System.Drawing.Color.White;
            this.tboxCreateNew.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tboxCreateNew.Location = new System.Drawing.Point(12, 86);
            this.tboxCreateNew.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.tboxCreateNew.Name = "tboxCreateNew";
            this.tboxCreateNew.Size = new System.Drawing.Size(439, 36);
            this.tboxCreateNew.TabIndex = 214;
            this.tboxCreateNew.Click += new System.EventHandler(this.tboxNewProfile_Click);
            this.tboxCreateNew.TextChanged += new System.EventHandler(this.tboxNewProfile_TextChanged);
            // 
            // btnSaveNewProfile
            // 
            this.btnSaveNewProfile.FlatAppearance.BorderSize = 0;
            this.btnSaveNewProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveNewProfile.Font = new System.Drawing.Font("Tahoma", 15.75F);
            this.btnSaveNewProfile.Image = global::AgIO.Properties.Resources.VehFileSave;
            this.btnSaveNewProfile.Location = new System.Drawing.Point(486, 60);
            this.btnSaveNewProfile.Name = "btnSaveNewProfile";
            this.btnSaveNewProfile.Size = new System.Drawing.Size(84, 69);
            this.btnSaveNewProfile.TabIndex = 215;
            this.btnSaveNewProfile.UseVisualStyleBackColor = true;
            this.btnSaveNewProfile.Click += new System.EventHandler(this.btnSaveNewProfile_Click);
            // 
            // labelNew
            // 
            this.labelNew.AutoSize = true;
            this.labelNew.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNew.Location = new System.Drawing.Point(15, 61);
            this.labelNew.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelNew.Name = "labelNew";
            this.labelNew.Size = new System.Drawing.Size(60, 23);
            this.labelNew.TabIndex = 216;
            this.labelNew.Text = "New:";
            this.labelNew.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(627, 74);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(226, 23);
            this.label2.TabIndex = 217;
            this.label2.Text = "Overwrite This Profile:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnSerialCancel
            // 
            this.btnSerialCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSerialCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSerialCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnSerialCancel.FlatAppearance.BorderSize = 0;
            this.btnSerialCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSerialCancel.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSerialCancel.Image = global::AgIO.Properties.Resources.Cancel64;
            this.btnSerialCancel.Location = new System.Drawing.Point(486, 291);
            this.btnSerialCancel.Name = "btnSerialCancel";
            this.btnSerialCancel.Size = new System.Drawing.Size(84, 69);
            this.btnSerialCancel.TabIndex = 218;
            this.btnSerialCancel.UseVisualStyleBackColor = true;
            this.btnSerialCancel.Click += new System.EventHandler(this.btnSerialCancel_Click);
            // 
            // labelSaveAs
            // 
            this.labelSaveAs.AutoSize = true;
            this.labelSaveAs.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSaveAs.Location = new System.Drawing.Point(15, 150);
            this.labelSaveAs.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelSaveAs.Name = "labelSaveAs";
            this.labelSaveAs.Size = new System.Drawing.Size(91, 23);
            this.labelSaveAs.TabIndex = 221;
            this.labelSaveAs.Text = "Save As:";
            this.labelSaveAs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tboxSaveAs
            // 
            this.tboxSaveAs.BackColor = System.Drawing.Color.White;
            this.tboxSaveAs.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tboxSaveAs.Location = new System.Drawing.Point(12, 175);
            this.tboxSaveAs.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.tboxSaveAs.Name = "tboxSaveAs";
            this.tboxSaveAs.Size = new System.Drawing.Size(439, 36);
            this.tboxSaveAs.TabIndex = 220;
            this.tboxSaveAs.Click += new System.EventHandler(this.tboxSaveAs_Click);
            this.tboxSaveAs.TextChanged += new System.EventHandler(this.tboxSaveAs_TextChanged);
            // 
            // btnSaveAs
            // 
            this.btnSaveAs.FlatAppearance.BorderSize = 0;
            this.btnSaveAs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveAs.Font = new System.Drawing.Font("Tahoma", 15.75F);
            this.btnSaveAs.Image = global::AgIO.Properties.Resources.FileSaveAs;
            this.btnSaveAs.Location = new System.Drawing.Point(486, 150);
            this.btnSaveAs.Name = "btnSaveAs";
            this.btnSaveAs.Size = new System.Drawing.Size(84, 69);
            this.btnSaveAs.TabIndex = 222;
            this.btnSaveAs.UseVisualStyleBackColor = true;
            this.btnSaveAs.Click += new System.EventHandler(this.btnSaveAs_Click);
            // 
            // lblCurrentProfile
            // 
            this.lblCurrentProfile.AutoSize = true;
            this.lblCurrentProfile.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentProfile.Location = new System.Drawing.Point(105, 150);
            this.lblCurrentProfile.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblCurrentProfile.Name = "lblCurrentProfile";
            this.lblCurrentProfile.Size = new System.Drawing.Size(150, 23);
            this.lblCurrentProfile.TabIndex = 223;
            this.lblCurrentProfile.Text = "Current Profile";
            this.lblCurrentProfile.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelCurent
            // 
            this.labelCurent.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCurent.Location = new System.Drawing.Point(19, 3);
            this.labelCurent.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelCurent.Name = "labelCurent";
            this.labelCurent.Size = new System.Drawing.Size(551, 27);
            this.labelCurent.TabIndex = 225;
            this.labelCurent.Text = "Curent Profile";
            this.labelCurent.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cboxChooseExisting
            // 
            this.cboxChooseExisting.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboxChooseExisting.Font = new System.Drawing.Font("Tahoma", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboxChooseExisting.FormattingEnabled = true;
            this.cboxChooseExisting.Location = new System.Drawing.Point(12, 265);
            this.cboxChooseExisting.Name = "cboxChooseExisting";
            this.cboxChooseExisting.Size = new System.Drawing.Size(439, 43);
            this.cboxChooseExisting.TabIndex = 224;
            this.cboxChooseExisting.SelectedIndexChanged += new System.EventHandler(this.cboxChooseExisting_SelectedIndexChanged);
            // 
            // labelOpen
            // 
            this.labelOpen.AutoSize = true;
            this.labelOpen.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOpen.Location = new System.Drawing.Point(19, 241);
            this.labelOpen.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelOpen.Name = "labelOpen";
            this.labelOpen.Size = new System.Drawing.Size(67, 23);
            this.labelOpen.TabIndex = 226;
            this.labelOpen.Text = "Open:";
            this.labelOpen.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // FormProfiles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(576, 364);
            this.Controls.Add(this.labelOpen);
            this.Controls.Add(this.labelCurent);
            this.Controls.Add(this.cboxChooseExisting);
            this.Controls.Add(this.lblCurrentProfile);
            this.Controls.Add(this.btnSaveAs);
            this.Controls.Add(this.labelSaveAs);
            this.Controls.Add(this.tboxSaveAs);
            this.Controls.Add(this.btnSerialCancel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelNew);
            this.Controls.Add(this.btnSaveNewProfile);
            this.Controls.Add(this.tboxCreateNew);
            this.Controls.Add(this.cboxOverWrite);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "FormProfiles";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "AgIO: Manage Profiles";
            this.Load += new System.EventHandler(this.FormCommSaver_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox cboxOverWrite;
        private System.Windows.Forms.TextBox tboxCreateNew;
        private System.Windows.Forms.Button btnSaveNewProfile;
        private System.Windows.Forms.Label labelNew;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSerialCancel;
        private System.Windows.Forms.Label labelSaveAs;
        private System.Windows.Forms.TextBox tboxSaveAs;
        private System.Windows.Forms.Button btnSaveAs;
        private System.Windows.Forms.Label lblCurrentProfile;
        private System.Windows.Forms.Label labelCurent;
        private System.Windows.Forms.ComboBox cboxChooseExisting;
        private System.Windows.Forms.Label labelOpen;
    }
}