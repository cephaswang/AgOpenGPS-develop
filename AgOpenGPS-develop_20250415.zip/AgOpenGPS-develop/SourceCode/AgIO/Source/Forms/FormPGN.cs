﻿using AgIO.Culture;
using System;
using System.Windows.Forms;

namespace AgIO
{
    public partial class FormPGN : Form
    {
        public FormPGN()
        {
            InitializeComponent();
        }

        private void btnSerialOK_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void FormPGN_Load(object sender, EventArgs e)
        {
            labelPGNSescr.Text = gStr.gsPGNSescr;

            labelDescription.Text = gStr.gsDescription;
            labelPGN.Text = gStr.gsPGN;

        }
    }
}