﻿using System.Windows;

namespace AgOpenGPS.WpfApp.Field
{
    public partial class SelectFieldDialog : Window
    {
        public SelectFieldDialog()
        {
            InitializeComponent();
        }
    }
}
