﻿using System.Windows.Controls;

namespace AgOpenGPS.WpfApp.Field
{
    public partial class FieldTable : UserControl
    {
        public FieldTable()
        {
            InitializeComponent();
        }
    }
}
