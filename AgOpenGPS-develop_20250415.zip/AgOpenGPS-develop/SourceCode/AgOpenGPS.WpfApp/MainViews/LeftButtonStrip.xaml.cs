﻿using System.Windows.Controls;

namespace AgOpenGPS.WpfApp.MainViews
{
    public partial class LeftButtonStrip : UserControl
    {
        public LeftButtonStrip()
        {
            InitializeComponent();
        }
    }
}
