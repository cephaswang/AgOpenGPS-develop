﻿using System.Windows.Controls;

namespace AgOpenGPS.WpfApp.MainViews
{
    public partial class BottomButtonStrip : UserControl
    {
        public BottomButtonStrip()
        {
            InitializeComponent();
        }
    }
}
