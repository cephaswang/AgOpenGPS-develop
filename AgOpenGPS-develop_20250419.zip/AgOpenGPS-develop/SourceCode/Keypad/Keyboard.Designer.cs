﻿using System.Windows.Forms;
using System;


namespace Keypad
{
    partial class Keyboard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        #region Component Designer generated code
        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.c7 = new System.Windows.Forms.Button();
            this.c8 = new System.Windows.Forms.Button();
            this.c9 = new System.Windows.Forms.Button();
            this.c10 = new System.Windows.Forms.Button();
            this.d1 = new System.Windows.Forms.Button();
            this.d2 = new System.Windows.Forms.Button();
            this.d3 = new System.Windows.Forms.Button();
            this.d4 = new System.Windows.Forms.Button();
            this.d5 = new System.Windows.Forms.Button();
            this.d6 = new System.Windows.Forms.Button();
            this.d7 = new System.Windows.Forms.Button();
            this.d8 = new System.Windows.Forms.Button();
            this.d9 = new System.Windows.Forms.Button();
            this.e3 = new System.Windows.Forms.Button();
            this.e4 = new System.Windows.Forms.Button();
            this.e5 = new System.Windows.Forms.Button();
            this.e6 = new System.Windows.Forms.Button();
            this.e7 = new System.Windows.Forms.Button();
            this.e8 = new System.Windows.Forms.Button();
            this.e9 = new System.Windows.Forms.Button();
            this.btn_space = new System.Windows.Forms.Button();
            this.btn_clear = new System.Windows.Forms.Button();
            this.c1 = new System.Windows.Forms.Button();
            this.c2 = new System.Windows.Forms.Button();
            this.c3 = new System.Windows.Forms.Button();
            this.c4 = new System.Windows.Forms.Button();
            this.c5 = new System.Windows.Forms.Button();
            this.c6 = new System.Windows.Forms.Button();
            this.chk_shift = new System.Windows.Forms.CheckBox();
            this.btn_OK = new System.Windows.Forms.Button();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.e11 = new System.Windows.Forms.Button();
            this.e1 = new System.Windows.Forms.Button();
            this.d10 = new System.Windows.Forms.Button();
            this.e10 = new System.Windows.Forms.Button();
            this.b6 = new System.Windows.Forms.Button();
            this.b5 = new System.Windows.Forms.Button();
            this.b4 = new System.Windows.Forms.Button();
            this.b3 = new System.Windows.Forms.Button();
            this.b2 = new System.Windows.Forms.Button();
            this.b1 = new System.Windows.Forms.Button();
            this.b10 = new System.Windows.Forms.Button();
            this.b9 = new System.Windows.Forms.Button();
            this.b8 = new System.Windows.Forms.Button();
            this.b7 = new System.Windows.Forms.Button();
            this.b11 = new System.Windows.Forms.Button();
            this.e12 = new System.Windows.Forms.Button();
            this.e2 = new System.Windows.Forms.Button();
            this.btnApos = new System.Windows.Forms.Button();
            this.c11 = new System.Windows.Forms.Button();
            this.c12 = new System.Windows.Forms.Button();
            this.b12 = new System.Windows.Forms.Button();
            this.d11 = new System.Windows.Forms.Button();
            this.d12 = new System.Windows.Forms.Button();
            this.tableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.d14 = new System.Windows.Forms.Button();
            this.e13 = new System.Windows.Forms.Button();
            this.c14 = new System.Windows.Forms.Button();
            this.c13 = new System.Windows.Forms.Button();
            this.e14 = new System.Windows.Forms.Button();
            this.b14 = new System.Windows.Forms.Button();
            this.b13 = new System.Windows.Forms.Button();
            this.a13 = new System.Windows.Forms.Button();
            this.a1 = new System.Windows.Forms.Button();
            this.a12 = new System.Windows.Forms.Button();
            this.a2 = new System.Windows.Forms.Button();
            this.a3 = new System.Windows.Forms.Button();
            this.a4 = new System.Windows.Forms.Button();
            this.a5 = new System.Windows.Forms.Button();
            this.a6 = new System.Windows.Forms.Button();
            this.a7 = new System.Windows.Forms.Button();
            this.a8 = new System.Windows.Forms.Button();
            this.a9 = new System.Windows.Forms.Button();
            this.a10 = new System.Windows.Forms.Button();
            this.a11 = new System.Windows.Forms.Button();
            this.btn_backspace = new System.Windows.Forms.Button();
            this.d13 = new System.Windows.Forms.Button();
            this.btn_lang = new System.Windows.Forms.Button();
            this.langMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.AfrikaansMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AmharicMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ArabicMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AssameseMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AzerbaijaniMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BelarusianMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BulgarianMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BengaliMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BosnianMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CatalanMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CzechMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.WelshMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DanishMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.GermanMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.GreekMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EnglishMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SpanishMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EstonianMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BasqueMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PersianMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.FinnishMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.FilipinoMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.FrenchMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.IrishMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ScottishGaelicMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.GalicianMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.GujaratiMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.HausaMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.HebrewMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.HindiMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CroatianMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.HungarianMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ArmenianMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.IndonesianMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.IgboMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.IcelandicMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ItalianMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.JapaneseMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.GeorgianMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.KazakhMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.KhmerMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.KannadaMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.KoreanMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.KonkaniMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.KurdishMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.KyrgyzMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.LuxembourgishMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.LaoMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.LithuanianMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.LatvianMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MaoriMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MacedonianMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MalayalamMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MongolianMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MarathiMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MalayMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MalteseMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BurmeseMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.NorwegianBokmalMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.NepaliMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DutchMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.NorwegianNynorskMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SesothoSaLeboaMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.OdiaMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PunjabiMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PolishMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PashtoMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PortugueseMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.QuechuaMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.RomanianMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.RussianMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.KinyarwandaMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SinhalaMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SlovakMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SlovenianMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AlbanianMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SerbianMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SwedishMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SwahiliMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TamilMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TeluguMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TajikMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ThaiMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TurkmenMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SetswanaMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TurkishMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TatarMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.UyghurMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.UkrainianMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.UrduMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.UzbekMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.VietnameseMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.WolofMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.XhosaMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.YorubaMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ChineseSimplifiedMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ChineseTraditionalMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ZuluMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel.SuspendLayout();
            this.langMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // c7
            // 
            this.c7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.c7.BackColor = System.Drawing.SystemColors.Control;
            this.c7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c7.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c7.Location = new System.Drawing.Point(393, 169);
            this.c7.Name = "c7";
            this.c7.Size = new System.Drawing.Size(59, 57);
            this.c7.TabIndex = 31;
            this.c7.TabStop = false;
            this.c7.Text = "j";
            this.c7.UseVisualStyleBackColor = false;
            this.c7.Click += new System.EventHandler(this.BtnClick);
            // 
            // c8
            // 
            this.c8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.c8.BackColor = System.Drawing.SystemColors.Control;
            this.c8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c8.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c8.Location = new System.Drawing.Point(458, 169);
            this.c8.Name = "c8";
            this.c8.Size = new System.Drawing.Size(59, 57);
            this.c8.TabIndex = 32;
            this.c8.TabStop = false;
            this.c8.Text = "k";
            this.c8.UseVisualStyleBackColor = false;
            this.c8.Click += new System.EventHandler(this.BtnClick);
            // 
            // c9
            // 
            this.c9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.c9.BackColor = System.Drawing.SystemColors.Control;
            this.c9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c9.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c9.Location = new System.Drawing.Point(523, 169);
            this.c9.Name = "c9";
            this.c9.Size = new System.Drawing.Size(59, 57);
            this.c9.TabIndex = 33;
            this.c9.TabStop = false;
            this.c9.Text = "l";
            this.c9.UseVisualStyleBackColor = false;
            this.c9.Click += new System.EventHandler(this.BtnClick);
            // 
            // c10
            // 
            this.c10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.c10.BackColor = System.Drawing.SystemColors.Control;
            this.c10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c10.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c10.Location = new System.Drawing.Point(588, 169);
            this.c10.Name = "c10";
            this.c10.Size = new System.Drawing.Size(59, 57);
            this.c10.TabIndex = 34;
            this.c10.TabStop = false;
            this.c10.Text = ":";
            this.c10.UseVisualStyleBackColor = false;
            this.c10.Click += new System.EventHandler(this.BtnClick);
            // 
            // d1
            // 
            this.d1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.d1.BackColor = System.Drawing.SystemColors.Control;
            this.d1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d1.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d1.Location = new System.Drawing.Point(3, 248);
            this.d1.Name = "d1";
            this.d1.Size = new System.Drawing.Size(59, 57);
            this.d1.TabIndex = 37;
            this.d1.TabStop = false;
            this.d1.Text = "z";
            this.d1.UseVisualStyleBackColor = false;
            this.d1.Click += new System.EventHandler(this.BtnClick);
            // 
            // d2
            // 
            this.d2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.d2.BackColor = System.Drawing.SystemColors.Control;
            this.d2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d2.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d2.Location = new System.Drawing.Point(68, 248);
            this.d2.Name = "d2";
            this.d2.Size = new System.Drawing.Size(59, 57);
            this.d2.TabIndex = 38;
            this.d2.TabStop = false;
            this.d2.Text = "x";
            this.d2.UseVisualStyleBackColor = false;
            this.d2.Click += new System.EventHandler(this.BtnClick);
            // 
            // d3
            // 
            this.d3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.d3.BackColor = System.Drawing.SystemColors.Control;
            this.d3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d3.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d3.Location = new System.Drawing.Point(133, 248);
            this.d3.Name = "d3";
            this.d3.Size = new System.Drawing.Size(59, 57);
            this.d3.TabIndex = 39;
            this.d3.TabStop = false;
            this.d3.Text = "c";
            this.d3.UseVisualStyleBackColor = false;
            this.d3.Click += new System.EventHandler(this.BtnClick);
            // 
            // d4
            // 
            this.d4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.d4.BackColor = System.Drawing.SystemColors.Control;
            this.d4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d4.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d4.Location = new System.Drawing.Point(198, 248);
            this.d4.Name = "d4";
            this.d4.Size = new System.Drawing.Size(59, 57);
            this.d4.TabIndex = 40;
            this.d4.TabStop = false;
            this.d4.Text = "v";
            this.d4.UseVisualStyleBackColor = false;
            this.d4.Click += new System.EventHandler(this.BtnClick);
            // 
            // d5
            // 
            this.d5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.d5.BackColor = System.Drawing.SystemColors.Control;
            this.d5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d5.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d5.Location = new System.Drawing.Point(263, 248);
            this.d5.Name = "d5";
            this.d5.Size = new System.Drawing.Size(59, 57);
            this.d5.TabIndex = 41;
            this.d5.TabStop = false;
            this.d5.Text = "b";
            this.d5.UseVisualStyleBackColor = false;
            this.d5.Click += new System.EventHandler(this.BtnClick);
            // 
            // d6
            // 
            this.d6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.d6.BackColor = System.Drawing.SystemColors.Control;
            this.d6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d6.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d6.Location = new System.Drawing.Point(328, 248);
            this.d6.Name = "d6";
            this.d6.Size = new System.Drawing.Size(59, 57);
            this.d6.TabIndex = 42;
            this.d6.TabStop = false;
            this.d6.Text = "n";
            this.d6.UseVisualStyleBackColor = false;
            this.d6.Click += new System.EventHandler(this.BtnClick);
            // 
            // d7
            // 
            this.d7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.d7.BackColor = System.Drawing.SystemColors.Control;
            this.d7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d7.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d7.Location = new System.Drawing.Point(393, 248);
            this.d7.Name = "d7";
            this.d7.Size = new System.Drawing.Size(59, 57);
            this.d7.TabIndex = 43;
            this.d7.TabStop = false;
            this.d7.Text = "m";
            this.d7.UseVisualStyleBackColor = false;
            this.d7.Click += new System.EventHandler(this.BtnClick);
            // 
            // d8
            // 
            this.d8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.d8.BackColor = System.Drawing.SystemColors.Control;
            this.d8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d8.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d8.Location = new System.Drawing.Point(458, 248);
            this.d8.Name = "d8";
            this.d8.Size = new System.Drawing.Size(59, 57);
            this.d8.TabIndex = 44;
            this.d8.TabStop = false;
            this.d8.Text = "<";
            this.d8.UseVisualStyleBackColor = false;
            this.d8.Click += new System.EventHandler(this.BtnClick);
            // 
            // d9
            // 
            this.d9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.d9.BackColor = System.Drawing.SystemColors.Control;
            this.d9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d9.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d9.Location = new System.Drawing.Point(523, 248);
            this.d9.Name = "d9";
            this.d9.Size = new System.Drawing.Size(59, 57);
            this.d9.TabIndex = 45;
            this.d9.TabStop = false;
            this.d9.Text = ">";
            this.d9.UseVisualStyleBackColor = false;
            this.d9.Click += new System.EventHandler(this.BtnClick);
            // 
            // e3
            // 
            this.e3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.e3.BackColor = System.Drawing.SystemColors.Control;
            this.e3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e3.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e3.Location = new System.Drawing.Point(718, 398);
            this.e3.Name = "e3";
            this.e3.Size = new System.Drawing.Size(59, 1);
            this.e3.TabIndex = 63;
            this.e3.TabStop = false;
            this.e3.Text = "0";
            this.e3.UseVisualStyleBackColor = false;
            this.e3.Click += new System.EventHandler(this.BtnClick);
            // 
            // e4
            // 
            this.e4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.e4.BackColor = System.Drawing.SystemColors.Control;
            this.e4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e4.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e4.Location = new System.Drawing.Point(653, 398);
            this.e4.Name = "e4";
            this.e4.Size = new System.Drawing.Size(59, 1);
            this.e4.TabIndex = 64;
            this.e4.TabStop = false;
            this.e4.Text = "0";
            this.e4.UseVisualStyleBackColor = false;
            this.e4.Click += new System.EventHandler(this.BtnClick);
            // 
            // e5
            // 
            this.e5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.e5.BackColor = System.Drawing.SystemColors.Control;
            this.e5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e5.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e5.Location = new System.Drawing.Point(588, 398);
            this.e5.Name = "e5";
            this.e5.Size = new System.Drawing.Size(59, 1);
            this.e5.TabIndex = 65;
            this.e5.TabStop = false;
            this.e5.Text = "0";
            this.e5.UseVisualStyleBackColor = false;
            this.e5.Click += new System.EventHandler(this.BtnClick);
            // 
            // e6
            // 
            this.e6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.e6.BackColor = System.Drawing.SystemColors.Control;
            this.e6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e6.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e6.Location = new System.Drawing.Point(523, 398);
            this.e6.Name = "e6";
            this.e6.Size = new System.Drawing.Size(59, 1);
            this.e6.TabIndex = 66;
            this.e6.TabStop = false;
            this.e6.Text = "0";
            this.e6.UseVisualStyleBackColor = false;
            this.e6.Click += new System.EventHandler(this.BtnClick);
            // 
            // e7
            // 
            this.e7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.e7.BackColor = System.Drawing.SystemColors.Control;
            this.e7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e7.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e7.Location = new System.Drawing.Point(393, 398);
            this.e7.Name = "e7";
            this.e7.Size = new System.Drawing.Size(59, 1);
            this.e7.TabIndex = 67;
            this.e7.TabStop = false;
            this.e7.Text = "0";
            this.e7.UseVisualStyleBackColor = false;
            this.e7.Click += new System.EventHandler(this.BtnClick);
            // 
            // e8
            // 
            this.e8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.e8.BackColor = System.Drawing.SystemColors.Control;
            this.e8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e8.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e8.Location = new System.Drawing.Point(263, 398);
            this.e8.Name = "e8";
            this.e8.Size = new System.Drawing.Size(59, 1);
            this.e8.TabIndex = 68;
            this.e8.TabStop = false;
            this.e8.Text = "0";
            this.e8.UseVisualStyleBackColor = false;
            this.e8.Click += new System.EventHandler(this.BtnClick);
            // 
            // e9
            // 
            this.e9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.e9.BackColor = System.Drawing.SystemColors.Control;
            this.e9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e9.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e9.Location = new System.Drawing.Point(198, 398);
            this.e9.Name = "e9";
            this.e9.Size = new System.Drawing.Size(59, 1);
            this.e9.TabIndex = 69;
            this.e9.TabStop = false;
            this.e9.Text = "0";
            this.e9.UseVisualStyleBackColor = false;
            this.e9.Click += new System.EventHandler(this.BtnClick);
            // 
            // btn_space
            // 
            this.btn_space.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_space.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel.SetColumnSpan(this.btn_space, 6);
            this.btn_space.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_space.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_space.Location = new System.Drawing.Point(199, 327);
            this.btn_space.Name = "btn_space";
            this.btn_space.Size = new System.Drawing.Size(381, 57);
            this.btn_space.TabIndex = 76;
            this.btn_space.TabStop = false;
            this.btn_space.Text = "__";
            this.btn_space.UseVisualStyleBackColor = false;
            this.btn_space.Click += new System.EventHandler(this.Btn_space_Click);
            // 
            // btn_clear
            // 
            this.btn_clear.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_clear.BackColor = System.Drawing.Color.LightSalmon;
            this.tableLayoutPanel.SetColumnSpan(this.btn_clear, 2);
            this.btn_clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_clear.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clear.Location = new System.Drawing.Point(68, 327);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(124, 57);
            this.btn_clear.TabIndex = 74;
            this.btn_clear.TabStop = false;
            this.btn_clear.Text = "Clr";
            this.btn_clear.UseVisualStyleBackColor = false;
            this.btn_clear.Click += new System.EventHandler(this.Btn_clear_Click);
            // 
            // c1
            // 
            this.c1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.c1.BackColor = System.Drawing.SystemColors.Control;
            this.c1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c1.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c1.Location = new System.Drawing.Point(3, 169);
            this.c1.Name = "c1";
            this.c1.Size = new System.Drawing.Size(59, 57);
            this.c1.TabIndex = 25;
            this.c1.TabStop = false;
            this.c1.Text = "a";
            this.c1.UseVisualStyleBackColor = false;
            this.c1.Click += new System.EventHandler(this.BtnClick);
            // 
            // c2
            // 
            this.c2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.c2.BackColor = System.Drawing.SystemColors.Control;
            this.c2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c2.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c2.Location = new System.Drawing.Point(68, 169);
            this.c2.Name = "c2";
            this.c2.Size = new System.Drawing.Size(59, 57);
            this.c2.TabIndex = 26;
            this.c2.TabStop = false;
            this.c2.Text = "s";
            this.c2.UseVisualStyleBackColor = false;
            this.c2.Click += new System.EventHandler(this.BtnClick);
            // 
            // c3
            // 
            this.c3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.c3.BackColor = System.Drawing.SystemColors.Control;
            this.c3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c3.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c3.Location = new System.Drawing.Point(133, 169);
            this.c3.Name = "c3";
            this.c3.Size = new System.Drawing.Size(59, 57);
            this.c3.TabIndex = 27;
            this.c3.TabStop = false;
            this.c3.Text = "d";
            this.c3.UseVisualStyleBackColor = false;
            this.c3.Click += new System.EventHandler(this.BtnClick);
            // 
            // c4
            // 
            this.c4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.c4.BackColor = System.Drawing.SystemColors.Control;
            this.c4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c4.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c4.Location = new System.Drawing.Point(198, 169);
            this.c4.Name = "c4";
            this.c4.Size = new System.Drawing.Size(59, 57);
            this.c4.TabIndex = 28;
            this.c4.TabStop = false;
            this.c4.Text = "f";
            this.c4.UseVisualStyleBackColor = false;
            this.c4.Click += new System.EventHandler(this.BtnClick);
            // 
            // c5
            // 
            this.c5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.c5.BackColor = System.Drawing.SystemColors.Control;
            this.c5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c5.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c5.Location = new System.Drawing.Point(263, 169);
            this.c5.Name = "c5";
            this.c5.Size = new System.Drawing.Size(59, 57);
            this.c5.TabIndex = 29;
            this.c5.TabStop = false;
            this.c5.Text = "g";
            this.c5.UseVisualStyleBackColor = false;
            this.c5.Click += new System.EventHandler(this.BtnClick);
            // 
            // c6
            // 
            this.c6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.c6.BackColor = System.Drawing.SystemColors.Control;
            this.c6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c6.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c6.Location = new System.Drawing.Point(328, 169);
            this.c6.Name = "c6";
            this.c6.Size = new System.Drawing.Size(59, 57);
            this.c6.TabIndex = 30;
            this.c6.TabStop = false;
            this.c6.Text = "h";
            this.c6.UseVisualStyleBackColor = false;
            this.c6.Click += new System.EventHandler(this.BtnClick);
            // 
            // chk_shift
            // 
            this.chk_shift.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chk_shift.Appearance = System.Windows.Forms.Appearance.Button;
            this.chk_shift.BackColor = System.Drawing.SystemColors.Control;
            this.chk_shift.BackgroundImage = global::Keypad.Properties.Resources.Shift;
            this.chk_shift.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.chk_shift.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.chk_shift.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chk_shift.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_shift.Location = new System.Drawing.Point(718, 327);
            this.chk_shift.Name = "chk_shift";
            this.chk_shift.Size = new System.Drawing.Size(59, 57);
            this.chk_shift.TabIndex = 77;
            this.chk_shift.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chk_shift.UseVisualStyleBackColor = false;
            this.chk_shift.CheckedChanged += new System.EventHandler(this.Chk_shift_CheckedChanged);
            // 
            // btn_OK
            // 
            this.btn_OK.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_OK.BackColor = System.Drawing.SystemColors.Control;
            this.btn_OK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_OK.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_OK.Image = global::Keypad.Properties.Resources.OK64;
            this.btn_OK.Location = new System.Drawing.Point(853, 327);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(59, 57);
            this.btn_OK.TabIndex = 78;
            this.btn_OK.TabStop = false;
            this.btn_OK.UseVisualStyleBackColor = false;
            this.btn_OK.Click += new System.EventHandler(this.Btn_OK_Click);
            // 
            // btn_cancel
            // 
            this.btn_cancel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_cancel.BackColor = System.Drawing.SystemColors.Control;
            this.btn_cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cancel.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cancel.Image = global::Keypad.Properties.Resources.Cancel64;
            this.btn_cancel.Location = new System.Drawing.Point(3, 327);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(59, 57);
            this.btn_cancel.TabIndex = 73;
            this.btn_cancel.TabStop = false;
            this.btn_cancel.UseVisualStyleBackColor = false;
            this.btn_cancel.Click += new System.EventHandler(this.Btn_cancel_Click);
            // 
            // e11
            // 
            this.e11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.e11.BackColor = System.Drawing.SystemColors.Control;
            this.e11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e11.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e11.Location = new System.Drawing.Point(68, 398);
            this.e11.Name = "e11";
            this.e11.Size = new System.Drawing.Size(59, 1);
            this.e11.TabIndex = 71;
            this.e11.TabStop = false;
            this.e11.Text = "0";
            this.e11.UseVisualStyleBackColor = false;
            this.e11.Click += new System.EventHandler(this.BtnClick);
            // 
            // e1
            // 
            this.e1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.e1.BackColor = System.Drawing.SystemColors.Control;
            this.e1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e1.Location = new System.Drawing.Point(3, 398);
            this.e1.Name = "e1";
            this.e1.Size = new System.Drawing.Size(59, 1);
            this.e1.TabIndex = 61;
            this.e1.TabStop = false;
            this.e1.Text = "0";
            this.e1.UseVisualStyleBackColor = false;
            this.e1.Click += new System.EventHandler(this.BtnClick);
            // 
            // d10
            // 
            this.d10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.d10.BackColor = System.Drawing.SystemColors.Control;
            this.d10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d10.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d10.Location = new System.Drawing.Point(588, 248);
            this.d10.Name = "d10";
            this.d10.Size = new System.Drawing.Size(59, 57);
            this.d10.TabIndex = 46;
            this.d10.TabStop = false;
            this.d10.Text = "?";
            this.d10.UseVisualStyleBackColor = false;
            this.d10.Click += new System.EventHandler(this.BtnClick);
            // 
            // e10
            // 
            this.e10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.e10.BackColor = System.Drawing.SystemColors.Control;
            this.e10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e10.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e10.Location = new System.Drawing.Point(133, 398);
            this.e10.Name = "e10";
            this.e10.Size = new System.Drawing.Size(59, 1);
            this.e10.TabIndex = 70;
            this.e10.TabStop = false;
            this.e10.Text = "0";
            this.e10.UseVisualStyleBackColor = false;
            this.e10.Click += new System.EventHandler(this.BtnClick);
            // 
            // b6
            // 
            this.b6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.b6.BackColor = System.Drawing.SystemColors.Control;
            this.b6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b6.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b6.Location = new System.Drawing.Point(328, 90);
            this.b6.Name = "b6";
            this.b6.Size = new System.Drawing.Size(59, 57);
            this.b6.TabIndex = 18;
            this.b6.TabStop = false;
            this.b6.Text = "y";
            this.b6.UseVisualStyleBackColor = false;
            this.b6.Click += new System.EventHandler(this.BtnClick);
            // 
            // b5
            // 
            this.b5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.b5.BackColor = System.Drawing.SystemColors.Control;
            this.b5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b5.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b5.Location = new System.Drawing.Point(263, 90);
            this.b5.Name = "b5";
            this.b5.Size = new System.Drawing.Size(59, 57);
            this.b5.TabIndex = 17;
            this.b5.TabStop = false;
            this.b5.Text = "t";
            this.b5.UseVisualStyleBackColor = false;
            this.b5.Click += new System.EventHandler(this.BtnClick);
            // 
            // b4
            // 
            this.b4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.b4.BackColor = System.Drawing.SystemColors.Control;
            this.b4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b4.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b4.Location = new System.Drawing.Point(198, 90);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(59, 57);
            this.b4.TabIndex = 16;
            this.b4.TabStop = false;
            this.b4.Text = "r";
            this.b4.UseVisualStyleBackColor = false;
            this.b4.Click += new System.EventHandler(this.BtnClick);
            // 
            // b3
            // 
            this.b3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.b3.BackColor = System.Drawing.SystemColors.Control;
            this.b3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b3.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b3.Location = new System.Drawing.Point(133, 90);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(59, 57);
            this.b3.TabIndex = 15;
            this.b3.TabStop = false;
            this.b3.Text = "e";
            this.b3.UseVisualStyleBackColor = false;
            this.b3.Click += new System.EventHandler(this.BtnClick);
            // 
            // b2
            // 
            this.b2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.b2.BackColor = System.Drawing.SystemColors.Control;
            this.b2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b2.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b2.Location = new System.Drawing.Point(68, 90);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(59, 57);
            this.b2.TabIndex = 14;
            this.b2.TabStop = false;
            this.b2.Text = "w";
            this.b2.UseVisualStyleBackColor = false;
            this.b2.Click += new System.EventHandler(this.BtnClick);
            // 
            // b1
            // 
            this.b1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.b1.BackColor = System.Drawing.SystemColors.Control;
            this.b1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b1.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b1.Location = new System.Drawing.Point(3, 90);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(59, 57);
            this.b1.TabIndex = 13;
            this.b1.TabStop = false;
            this.b1.Text = "q";
            this.b1.UseVisualStyleBackColor = false;
            this.b1.Click += new System.EventHandler(this.BtnClick);
            // 
            // b10
            // 
            this.b10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.b10.BackColor = System.Drawing.SystemColors.Control;
            this.b10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b10.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b10.Location = new System.Drawing.Point(588, 90);
            this.b10.Name = "b10";
            this.b10.Size = new System.Drawing.Size(59, 57);
            this.b10.TabIndex = 22;
            this.b10.TabStop = false;
            this.b10.Text = "p";
            this.b10.UseVisualStyleBackColor = false;
            this.b10.Click += new System.EventHandler(this.BtnClick);
            // 
            // b9
            // 
            this.b9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.b9.BackColor = System.Drawing.SystemColors.Control;
            this.b9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b9.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b9.Location = new System.Drawing.Point(523, 90);
            this.b9.Name = "b9";
            this.b9.Size = new System.Drawing.Size(59, 57);
            this.b9.TabIndex = 21;
            this.b9.TabStop = false;
            this.b9.Text = "o";
            this.b9.UseVisualStyleBackColor = false;
            this.b9.Click += new System.EventHandler(this.BtnClick);
            // 
            // b8
            // 
            this.b8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.b8.BackColor = System.Drawing.SystemColors.Control;
            this.b8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b8.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b8.Location = new System.Drawing.Point(458, 90);
            this.b8.Name = "b8";
            this.b8.Size = new System.Drawing.Size(59, 57);
            this.b8.TabIndex = 20;
            this.b8.TabStop = false;
            this.b8.Text = "i";
            this.b8.UseVisualStyleBackColor = false;
            this.b8.Click += new System.EventHandler(this.BtnClick);
            // 
            // b7
            // 
            this.b7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.b7.BackColor = System.Drawing.SystemColors.Control;
            this.b7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b7.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b7.Location = new System.Drawing.Point(393, 90);
            this.b7.Name = "b7";
            this.b7.Size = new System.Drawing.Size(59, 57);
            this.b7.TabIndex = 19;
            this.b7.TabStop = false;
            this.b7.Text = "u";
            this.b7.UseVisualStyleBackColor = false;
            this.b7.Click += new System.EventHandler(this.BtnClick);
            // 
            // b11
            // 
            this.b11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.b11.BackColor = System.Drawing.SystemColors.Control;
            this.b11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b11.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b11.Location = new System.Drawing.Point(653, 90);
            this.b11.Name = "b11";
            this.b11.Size = new System.Drawing.Size(59, 57);
            this.b11.TabIndex = 23;
            this.b11.TabStop = false;
            this.b11.Text = "{";
            this.b11.UseVisualStyleBackColor = false;
            this.b11.Click += new System.EventHandler(this.BtnClick);
            // 
            // e12
            // 
            this.e12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.e12.BackColor = System.Drawing.SystemColors.Control;
            this.e12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e12.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e12.Location = new System.Drawing.Point(458, 398);
            this.e12.Name = "e12";
            this.e12.Size = new System.Drawing.Size(59, 1);
            this.e12.TabIndex = 72;
            this.e12.TabStop = false;
            this.e12.Text = "0";
            this.e12.UseVisualStyleBackColor = false;
            this.e12.Click += new System.EventHandler(this.BtnClick);
            // 
            // e2
            // 
            this.e2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.e2.BackColor = System.Drawing.SystemColors.Control;
            this.e2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e2.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e2.Location = new System.Drawing.Point(328, 398);
            this.e2.Name = "e2";
            this.e2.Size = new System.Drawing.Size(59, 1);
            this.e2.TabIndex = 62;
            this.e2.TabStop = false;
            this.e2.Text = "0";
            this.e2.UseVisualStyleBackColor = false;
            this.e2.Click += new System.EventHandler(this.BtnClick);
            // 
            // btnApos
            // 
            this.btnApos.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnApos.BackColor = System.Drawing.SystemColors.Control;
            this.btnApos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnApos.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnApos.Location = new System.Drawing.Point(783, 327);
            this.btnApos.Name = "btnApos";
            this.btnApos.Size = new System.Drawing.Size(59, 57);
            this.btnApos.TabIndex = 75;
            this.btnApos.TabStop = false;
            this.btnApos.Text = "\'";
            this.btnApos.UseVisualStyleBackColor = false;
            this.btnApos.Click += new System.EventHandler(this.BtnClick);
            // 
            // c11
            // 
            this.c11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.c11.BackColor = System.Drawing.SystemColors.Control;
            this.c11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c11.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c11.Location = new System.Drawing.Point(653, 169);
            this.c11.Name = "c11";
            this.c11.Size = new System.Drawing.Size(59, 57);
            this.c11.TabIndex = 35;
            this.c11.TabStop = false;
            this.c11.Text = "\"";
            this.c11.UseVisualStyleBackColor = false;
            this.c11.Click += new System.EventHandler(this.BtnClick);
            // 
            // c12
            // 
            this.c12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.c12.BackColor = System.Drawing.SystemColors.Control;
            this.c12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c12.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c12.Location = new System.Drawing.Point(718, 169);
            this.c12.Name = "c12";
            this.c12.Size = new System.Drawing.Size(59, 57);
            this.c12.TabIndex = 36;
            this.c12.TabStop = false;
            this.c12.Text = "0";
            this.c12.UseVisualStyleBackColor = false;
            this.c12.Click += new System.EventHandler(this.BtnClick);
            // 
            // b12
            // 
            this.b12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.b12.BackColor = System.Drawing.SystemColors.Control;
            this.b12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b12.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b12.Location = new System.Drawing.Point(718, 90);
            this.b12.Name = "b12";
            this.b12.Size = new System.Drawing.Size(59, 57);
            this.b12.TabIndex = 24;
            this.b12.TabStop = false;
            this.b12.Text = "}";
            this.b12.UseVisualStyleBackColor = false;
            this.b12.Click += new System.EventHandler(this.BtnClick);
            // 
            // d11
            // 
            this.d11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.d11.BackColor = System.Drawing.SystemColors.Control;
            this.d11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d11.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d11.Location = new System.Drawing.Point(653, 248);
            this.d11.Name = "d11";
            this.d11.Size = new System.Drawing.Size(59, 57);
            this.d11.TabIndex = 47;
            this.d11.TabStop = false;
            this.d11.Text = "0";
            this.d11.UseVisualStyleBackColor = false;
            this.d11.Click += new System.EventHandler(this.BtnClick);
            // 
            // d12
            // 
            this.d12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.d12.BackColor = System.Drawing.SystemColors.Control;
            this.d12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d12.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d12.Location = new System.Drawing.Point(718, 248);
            this.d12.Name = "d12";
            this.d12.Size = new System.Drawing.Size(59, 57);
            this.d12.TabIndex = 48;
            this.d12.TabStop = false;
            this.d12.Text = "0";
            this.d12.UseVisualStyleBackColor = false;
            this.d12.Click += new System.EventHandler(this.BtnClick);
            // 
            // tableLayoutPanel
            // 
            this.tableLayoutPanel.ColumnCount = 14;
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142856F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142856F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142856F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142856F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142856F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142856F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142856F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142856F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142856F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142856F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142856F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142856F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142856F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142856F));
            this.tableLayoutPanel.Controls.Add(this.d14, 13, 3);
            this.tableLayoutPanel.Controls.Add(this.e13, 13, 5);
            this.tableLayoutPanel.Controls.Add(this.c14, 13, 2);
            this.tableLayoutPanel.Controls.Add(this.c13, 12, 2);
            this.tableLayoutPanel.Controls.Add(this.e14, 12, 5);
            this.tableLayoutPanel.Controls.Add(this.b14, 13, 1);
            this.tableLayoutPanel.Controls.Add(this.e3, 11, 5);
            this.tableLayoutPanel.Controls.Add(this.b13, 12, 1);
            this.tableLayoutPanel.Controls.Add(this.e4, 10, 5);
            this.tableLayoutPanel.Controls.Add(this.a13, 12, 0);
            this.tableLayoutPanel.Controls.Add(this.e5, 9, 5);
            this.tableLayoutPanel.Controls.Add(this.a1, 0, 0);
            this.tableLayoutPanel.Controls.Add(this.e6, 8, 5);
            this.tableLayoutPanel.Controls.Add(this.btn_clear, 1, 4);
            this.tableLayoutPanel.Controls.Add(this.e12, 7, 5);
            this.tableLayoutPanel.Controls.Add(this.btn_space, 3, 4);
            this.tableLayoutPanel.Controls.Add(this.e7, 6, 5);
            this.tableLayoutPanel.Controls.Add(this.a12, 11, 0);
            this.tableLayoutPanel.Controls.Add(this.e2, 5, 5);
            this.tableLayoutPanel.Controls.Add(this.a2, 1, 0);
            this.tableLayoutPanel.Controls.Add(this.e8, 4, 5);
            this.tableLayoutPanel.Controls.Add(this.d11, 10, 3);
            this.tableLayoutPanel.Controls.Add(this.e9, 3, 5);
            this.tableLayoutPanel.Controls.Add(this.a3, 2, 0);
            this.tableLayoutPanel.Controls.Add(this.e1, 0, 5);
            this.tableLayoutPanel.Controls.Add(this.e10, 2, 5);
            this.tableLayoutPanel.Controls.Add(this.c12, 11, 2);
            this.tableLayoutPanel.Controls.Add(this.e11, 1, 5);
            this.tableLayoutPanel.Controls.Add(this.b12, 11, 1);
            this.tableLayoutPanel.Controls.Add(this.c11, 10, 2);
            this.tableLayoutPanel.Controls.Add(this.a4, 3, 0);
            this.tableLayoutPanel.Controls.Add(this.d10, 9, 3);
            this.tableLayoutPanel.Controls.Add(this.a5, 4, 0);
            this.tableLayoutPanel.Controls.Add(this.a6, 5, 0);
            this.tableLayoutPanel.Controls.Add(this.a7, 6, 0);
            this.tableLayoutPanel.Controls.Add(this.a8, 7, 0);
            this.tableLayoutPanel.Controls.Add(this.b11, 10, 1);
            this.tableLayoutPanel.Controls.Add(this.a9, 8, 0);
            this.tableLayoutPanel.Controls.Add(this.a10, 9, 0);
            this.tableLayoutPanel.Controls.Add(this.b10, 9, 1);
            this.tableLayoutPanel.Controls.Add(this.b6, 5, 1);
            this.tableLayoutPanel.Controls.Add(this.b9, 8, 1);
            this.tableLayoutPanel.Controls.Add(this.c6, 5, 2);
            this.tableLayoutPanel.Controls.Add(this.a11, 10, 0);
            this.tableLayoutPanel.Controls.Add(this.c5, 4, 2);
            this.tableLayoutPanel.Controls.Add(this.b8, 7, 1);
            this.tableLayoutPanel.Controls.Add(this.c4, 3, 2);
            this.tableLayoutPanel.Controls.Add(this.d9, 8, 3);
            this.tableLayoutPanel.Controls.Add(this.b5, 4, 1);
            this.tableLayoutPanel.Controls.Add(this.d8, 7, 3);
            this.tableLayoutPanel.Controls.Add(this.c3, 2, 2);
            this.tableLayoutPanel.Controls.Add(this.d7, 6, 3);
            this.tableLayoutPanel.Controls.Add(this.b7, 6, 1);
            this.tableLayoutPanel.Controls.Add(this.d6, 5, 3);
            this.tableLayoutPanel.Controls.Add(this.c2, 1, 2);
            this.tableLayoutPanel.Controls.Add(this.d5, 4, 3);
            this.tableLayoutPanel.Controls.Add(this.d4, 3, 3);
            this.tableLayoutPanel.Controls.Add(this.c1, 0, 2);
            this.tableLayoutPanel.Controls.Add(this.d3, 2, 3);
            this.tableLayoutPanel.Controls.Add(this.b4, 3, 1);
            this.tableLayoutPanel.Controls.Add(this.d2, 1, 3);
            this.tableLayoutPanel.Controls.Add(this.b1, 0, 1);
            this.tableLayoutPanel.Controls.Add(this.d1, 0, 3);
            this.tableLayoutPanel.Controls.Add(this.b3, 2, 1);
            this.tableLayoutPanel.Controls.Add(this.b2, 1, 1);
            this.tableLayoutPanel.Controls.Add(this.c7, 6, 2);
            this.tableLayoutPanel.Controls.Add(this.c8, 7, 2);
            this.tableLayoutPanel.Controls.Add(this.c9, 8, 2);
            this.tableLayoutPanel.Controls.Add(this.c10, 9, 2);
            this.tableLayoutPanel.Controls.Add(this.btn_backspace, 13, 0);
            this.tableLayoutPanel.Controls.Add(this.d13, 12, 3);
            this.tableLayoutPanel.Controls.Add(this.btn_lang, 9, 4);
            this.tableLayoutPanel.Controls.Add(this.d12, 11, 3);
            this.tableLayoutPanel.Controls.Add(this.btn_cancel, 0, 4);
            this.tableLayoutPanel.Controls.Add(this.btn_OK, 13, 4);
            this.tableLayoutPanel.Controls.Add(this.btnApos, 12, 4);
            this.tableLayoutPanel.Controls.Add(this.chk_shift, 11, 4);
            this.tableLayoutPanel.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel.Name = "tableLayoutPanel";
            this.tableLayoutPanel.RowCount = 6;
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.76285F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.76285F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.76285F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.76285F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.76285F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 1.185771F));
            this.tableLayoutPanel.Size = new System.Drawing.Size(920, 400);
            this.tableLayoutPanel.TabIndex = 73;
            this.tableLayoutPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel_Paint);
            // 
            // d14
            // 
            this.d14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.d14.BackColor = System.Drawing.SystemColors.Control;
            this.d14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d14.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d14.Location = new System.Drawing.Point(853, 248);
            this.d14.Name = "d14";
            this.d14.Size = new System.Drawing.Size(59, 57);
            this.d14.TabIndex = 77;
            this.d14.TabStop = false;
            this.d14.Text = "0";
            this.d14.UseVisualStyleBackColor = false;
            // 
            // e13
            // 
            this.e13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.e13.BackColor = System.Drawing.SystemColors.Control;
            this.e13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e13.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e13.Location = new System.Drawing.Point(853, 398);
            this.e13.Name = "e13";
            this.e13.Size = new System.Drawing.Size(59, 1);
            this.e13.TabIndex = 76;
            this.e13.TabStop = false;
            this.e13.Text = "0";
            this.e13.UseVisualStyleBackColor = false;
            // 
            // c14
            // 
            this.c14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.c14.BackColor = System.Drawing.SystemColors.Control;
            this.c14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c14.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c14.Location = new System.Drawing.Point(853, 169);
            this.c14.Name = "c14";
            this.c14.Size = new System.Drawing.Size(59, 57);
            this.c14.TabIndex = 79;
            this.c14.TabStop = false;
            this.c14.Text = "0";
            this.c14.UseVisualStyleBackColor = false;
            // 
            // c13
            // 
            this.c13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.c13.BackColor = System.Drawing.SystemColors.Control;
            this.c13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c13.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c13.Location = new System.Drawing.Point(783, 169);
            this.c13.Name = "c13";
            this.c13.Size = new System.Drawing.Size(59, 57);
            this.c13.TabIndex = 80;
            this.c13.TabStop = false;
            this.c13.Text = "0";
            this.c13.UseVisualStyleBackColor = false;
            this.c13.Click += new System.EventHandler(this.button7_Click);
            // 
            // e14
            // 
            this.e14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.e14.BackColor = System.Drawing.SystemColors.Control;
            this.e14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e14.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e14.Location = new System.Drawing.Point(783, 398);
            this.e14.Name = "e14";
            this.e14.Size = new System.Drawing.Size(59, 1);
            this.e14.TabIndex = 75;
            this.e14.TabStop = false;
            this.e14.Text = "0";
            this.e14.UseVisualStyleBackColor = false;
            // 
            // b14
            // 
            this.b14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.b14.BackColor = System.Drawing.SystemColors.Control;
            this.b14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b14.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b14.Location = new System.Drawing.Point(853, 90);
            this.b14.Name = "b14";
            this.b14.Size = new System.Drawing.Size(59, 57);
            this.b14.TabIndex = 81;
            this.b14.TabStop = false;
            this.b14.Text = "0";
            this.b14.UseVisualStyleBackColor = false;
            // 
            // b13
            // 
            this.b13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.b13.BackColor = System.Drawing.SystemColors.Control;
            this.b13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b13.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b13.Location = new System.Drawing.Point(783, 90);
            this.b13.Name = "b13";
            this.b13.Size = new System.Drawing.Size(59, 57);
            this.b13.TabIndex = 82;
            this.b13.TabStop = false;
            this.b13.Text = "|";
            this.b13.UseVisualStyleBackColor = false;
            // 
            // a13
            // 
            this.a13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.a13.BackColor = System.Drawing.SystemColors.Control;
            this.a13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a13.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a13.Location = new System.Drawing.Point(783, 11);
            this.a13.Name = "a13";
            this.a13.Size = new System.Drawing.Size(59, 57);
            this.a13.TabIndex = 83;
            this.a13.TabStop = false;
            this.a13.Text = "e.";
            this.a13.UseVisualStyleBackColor = false;
            // 
            // a1
            // 
            this.a1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.a1.BackColor = System.Drawing.SystemColors.Control;
            this.a1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a1.Location = new System.Drawing.Point(3, 11);
            this.a1.Name = "a1";
            this.a1.Size = new System.Drawing.Size(59, 57);
            this.a1.TabIndex = 1;
            this.a1.TabStop = false;
            this.a1.Text = "1";
            this.a1.UseVisualStyleBackColor = false;
            this.a1.Click += new System.EventHandler(this.BtnClick);
            // 
            // a12
            // 
            this.a12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.a12.BackColor = System.Drawing.SystemColors.Control;
            this.a12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a12.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a12.Location = new System.Drawing.Point(718, 11);
            this.a12.Name = "a12";
            this.a12.Size = new System.Drawing.Size(59, 57);
            this.a12.TabIndex = 74;
            this.a12.TabStop = false;
            this.a12.Text = "+";
            this.a12.UseVisualStyleBackColor = false;
            // 
            // a2
            // 
            this.a2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.a2.BackColor = System.Drawing.SystemColors.Control;
            this.a2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a2.Location = new System.Drawing.Point(68, 11);
            this.a2.Name = "a2";
            this.a2.Size = new System.Drawing.Size(59, 57);
            this.a2.TabIndex = 2;
            this.a2.TabStop = false;
            this.a2.Text = "2";
            this.a2.UseVisualStyleBackColor = false;
            this.a2.Click += new System.EventHandler(this.BtnClick);
            // 
            // a3
            // 
            this.a3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.a3.BackColor = System.Drawing.SystemColors.Control;
            this.a3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a3.Location = new System.Drawing.Point(133, 11);
            this.a3.Name = "a3";
            this.a3.Size = new System.Drawing.Size(59, 57);
            this.a3.TabIndex = 3;
            this.a3.TabStop = false;
            this.a3.Text = "3";
            this.a3.UseVisualStyleBackColor = false;
            this.a3.Click += new System.EventHandler(this.BtnClick);
            // 
            // a4
            // 
            this.a4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.a4.BackColor = System.Drawing.SystemColors.Control;
            this.a4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a4.Location = new System.Drawing.Point(198, 11);
            this.a4.Name = "a4";
            this.a4.Size = new System.Drawing.Size(59, 57);
            this.a4.TabIndex = 4;
            this.a4.TabStop = false;
            this.a4.Text = "4";
            this.a4.UseVisualStyleBackColor = false;
            this.a4.Click += new System.EventHandler(this.BtnClick);
            // 
            // a5
            // 
            this.a5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.a5.BackColor = System.Drawing.SystemColors.Control;
            this.a5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a5.Location = new System.Drawing.Point(263, 11);
            this.a5.Name = "a5";
            this.a5.Size = new System.Drawing.Size(59, 57);
            this.a5.TabIndex = 5;
            this.a5.TabStop = false;
            this.a5.Text = "5";
            this.a5.UseVisualStyleBackColor = false;
            this.a5.Click += new System.EventHandler(this.BtnClick);
            // 
            // a6
            // 
            this.a6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.a6.BackColor = System.Drawing.SystemColors.Control;
            this.a6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a6.Location = new System.Drawing.Point(328, 11);
            this.a6.Name = "a6";
            this.a6.Size = new System.Drawing.Size(59, 57);
            this.a6.TabIndex = 6;
            this.a6.TabStop = false;
            this.a6.Text = "6";
            this.a6.UseVisualStyleBackColor = false;
            this.a6.Click += new System.EventHandler(this.BtnClick);
            // 
            // a7
            // 
            this.a7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.a7.BackColor = System.Drawing.SystemColors.Control;
            this.a7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a7.Location = new System.Drawing.Point(393, 11);
            this.a7.Name = "a7";
            this.a7.Size = new System.Drawing.Size(59, 57);
            this.a7.TabIndex = 7;
            this.a7.TabStop = false;
            this.a7.Text = "7";
            this.a7.UseVisualStyleBackColor = false;
            this.a7.Click += new System.EventHandler(this.BtnClick);
            // 
            // a8
            // 
            this.a8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.a8.BackColor = System.Drawing.SystemColors.Control;
            this.a8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a8.Location = new System.Drawing.Point(458, 11);
            this.a8.Name = "a8";
            this.a8.Size = new System.Drawing.Size(59, 57);
            this.a8.TabIndex = 8;
            this.a8.TabStop = false;
            this.a8.Text = "8";
            this.a8.UseVisualStyleBackColor = false;
            this.a8.Click += new System.EventHandler(this.BtnClick);
            // 
            // a9
            // 
            this.a9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.a9.BackColor = System.Drawing.SystemColors.Control;
            this.a9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a9.Location = new System.Drawing.Point(523, 11);
            this.a9.Name = "a9";
            this.a9.Size = new System.Drawing.Size(59, 57);
            this.a9.TabIndex = 9;
            this.a9.TabStop = false;
            this.a9.Text = "9";
            this.a9.UseVisualStyleBackColor = false;
            this.a9.Click += new System.EventHandler(this.BtnClick);
            // 
            // a10
            // 
            this.a10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.a10.BackColor = System.Drawing.SystemColors.Control;
            this.a10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a10.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a10.Location = new System.Drawing.Point(588, 11);
            this.a10.Name = "a10";
            this.a10.Size = new System.Drawing.Size(59, 57);
            this.a10.TabIndex = 10;
            this.a10.TabStop = false;
            this.a10.Text = "0";
            this.a10.UseVisualStyleBackColor = false;
            this.a10.Click += new System.EventHandler(this.BtnClick);
            // 
            // a11
            // 
            this.a11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.a11.BackColor = System.Drawing.SystemColors.Control;
            this.a11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a11.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a11.Location = new System.Drawing.Point(653, 11);
            this.a11.Name = "a11";
            this.a11.Size = new System.Drawing.Size(59, 57);
            this.a11.TabIndex = 11;
            this.a11.TabStop = false;
            this.a11.Text = "-";
            this.a11.UseVisualStyleBackColor = false;
            this.a11.Click += new System.EventHandler(this.BtnClick);
            // 
            // btn_backspace
            // 
            this.btn_backspace.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_backspace.BackColor = System.Drawing.Color.LightSalmon;
            this.btn_backspace.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_backspace.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_backspace.Image = global::Keypad.Properties.Resources.backspace;
            this.btn_backspace.Location = new System.Drawing.Point(848, 11);
            this.btn_backspace.Name = "btn_backspace";
            this.btn_backspace.Size = new System.Drawing.Size(69, 57);
            this.btn_backspace.TabIndex = 12;
            this.btn_backspace.TabStop = false;
            this.btn_backspace.UseVisualStyleBackColor = false;
            this.btn_backspace.Click += new System.EventHandler(this.Btn_backspace_Click);
            // 
            // d13
            // 
            this.d13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.d13.BackColor = System.Drawing.SystemColors.Control;
            this.d13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d13.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d13.Location = new System.Drawing.Point(783, 248);
            this.d13.Name = "d13";
            this.d13.Size = new System.Drawing.Size(59, 57);
            this.d13.TabIndex = 78;
            this.d13.TabStop = false;
            this.d13.Text = "0";
            this.d13.UseVisualStyleBackColor = false;
            // 
            // btn_lang
            // 
            this.btn_lang.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_lang.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel.SetColumnSpan(this.btn_lang, 2);
            this.btn_lang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_lang.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_lang.Location = new System.Drawing.Point(588, 327);
            this.btn_lang.Name = "btn_lang";
            this.btn_lang.Size = new System.Drawing.Size(124, 57);
            this.btn_lang.TabIndex = 79;
            this.btn_lang.TabStop = false;
            this.btn_lang.Text = "Lang";
            this.btn_lang.UseVisualStyleBackColor = false;
            this.btn_lang.Click += new System.EventHandler(this.Btn_lang_Click);
            // 
            // langMenuStrip
            // 
            this.langMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AfrikaansMenuItem,
            this.AmharicMenuItem,
            this.ArabicMenuItem,
            this.AssameseMenuItem,
            this.AzerbaijaniMenuItem,
            this.BelarusianMenuItem,
            this.BulgarianMenuItem,
            this.BengaliMenuItem,
            this.BosnianMenuItem,
            this.CatalanMenuItem,
            this.CzechMenuItem,
            this.WelshMenuItem,
            this.DanishMenuItem,
            this.GermanMenuItem,
            this.GreekMenuItem,
            this.EnglishMenuItem,
            this.SpanishMenuItem,
            this.EstonianMenuItem,
            this.BasqueMenuItem,
            this.PersianMenuItem,
            this.FinnishMenuItem,
            this.FilipinoMenuItem,
            this.FrenchMenuItem,
            this.IrishMenuItem,
            this.ScottishGaelicMenuItem,
            this.GalicianMenuItem,
            this.GujaratiMenuItem,
            this.HausaMenuItem,
            this.HebrewMenuItem,
            this.HindiMenuItem,
            this.CroatianMenuItem,
            this.HungarianMenuItem,
            this.ArmenianMenuItem,
            this.IndonesianMenuItem,
            this.IgboMenuItem,
            this.IcelandicMenuItem,
            this.ItalianMenuItem,
            this.JapaneseMenuItem,
            this.GeorgianMenuItem,
            this.KazakhMenuItem,
            this.KhmerMenuItem,
            this.KannadaMenuItem,
            this.KoreanMenuItem,
            this.KonkaniMenuItem,
            this.KurdishMenuItem,
            this.KyrgyzMenuItem,
            this.LuxembourgishMenuItem,
            this.LaoMenuItem,
            this.LithuanianMenuItem,
            this.LatvianMenuItem,
            this.MaoriMenuItem,
            this.MacedonianMenuItem,
            this.MalayalamMenuItem,
            this.MongolianMenuItem,
            this.MarathiMenuItem,
            this.MalayMenuItem,
            this.MalteseMenuItem,
            this.BurmeseMenuItem,
            this.NorwegianBokmalMenuItem,
            this.NepaliMenuItem,
            this.DutchMenuItem,
            this.NorwegianNynorskMenuItem,
            this.SesothoSaLeboaMenuItem,
            this.OdiaMenuItem,
            this.PunjabiMenuItem,
            this.PolishMenuItem,
            this.PashtoMenuItem,
            this.PortugueseMenuItem,
            this.QuechuaMenuItem,
            this.RomanianMenuItem,
            this.RussianMenuItem,
            this.KinyarwandaMenuItem,
            this.SinhalaMenuItem,
            this.SlovakMenuItem,
            this.SlovenianMenuItem,
            this.AlbanianMenuItem,
            this.SerbianMenuItem,
            this.SwedishMenuItem,
            this.SwahiliMenuItem,
            this.TamilMenuItem,
            this.TeluguMenuItem,
            this.TajikMenuItem,
            this.ThaiMenuItem,
            this.TurkmenMenuItem,
            this.SetswanaMenuItem,
            this.TurkishMenuItem,
            this.TatarMenuItem,
            this.UyghurMenuItem,
            this.UkrainianMenuItem,
            this.UrduMenuItem,
            this.UzbekMenuItem,
            this.VietnameseMenuItem,
            this.WolofMenuItem,
            this.XhosaMenuItem,
            this.YorubaMenuItem,
            this.ChineseSimplifiedMenuItem,
            this.ChineseTraditionalMenuItem,
            this.ZuluMenuItem});
            this.langMenuStrip.Name = "langMenuStrip";
            this.langMenuStrip.Size = new System.Drawing.Size(191, 1038);
            // 
            // AfrikaansMenuItem
            // 
            this.AfrikaansMenuItem.Name = "AfrikaansMenuItem";
            this.AfrikaansMenuItem.Size = new System.Drawing.Size(190, 22);
            this.AfrikaansMenuItem.Text = "Afrikaans";
            // 
            // AmharicMenuItem
            // 
            this.AmharicMenuItem.Name = "AmharicMenuItem";
            this.AmharicMenuItem.Size = new System.Drawing.Size(190, 22);
            this.AmharicMenuItem.Text = "Amharic";
            // 
            // ArabicMenuItem
            // 
            this.ArabicMenuItem.Name = "ArabicMenuItem";
            this.ArabicMenuItem.Size = new System.Drawing.Size(190, 22);
            this.ArabicMenuItem.Text = "Arabic";
            // 
            // AssameseMenuItem
            // 
            this.AssameseMenuItem.Name = "AssameseMenuItem";
            this.AssameseMenuItem.Size = new System.Drawing.Size(190, 22);
            this.AssameseMenuItem.Text = "Assamese";
            // 
            // AzerbaijaniMenuItem
            // 
            this.AzerbaijaniMenuItem.Name = "AzerbaijaniMenuItem";
            this.AzerbaijaniMenuItem.Size = new System.Drawing.Size(190, 22);
            this.AzerbaijaniMenuItem.Text = "Azerbaijani";
            // 
            // BelarusianMenuItem
            // 
            this.BelarusianMenuItem.Name = "BelarusianMenuItem";
            this.BelarusianMenuItem.Size = new System.Drawing.Size(190, 22);
            this.BelarusianMenuItem.Text = "Belarusian";
            // 
            // BulgarianMenuItem
            // 
            this.BulgarianMenuItem.Name = "BulgarianMenuItem";
            this.BulgarianMenuItem.Size = new System.Drawing.Size(190, 22);
            this.BulgarianMenuItem.Text = "Bulgarian";
            // 
            // BengaliMenuItem
            // 
            this.BengaliMenuItem.Name = "BengaliMenuItem";
            this.BengaliMenuItem.Size = new System.Drawing.Size(190, 22);
            this.BengaliMenuItem.Text = "Bengali";
            // 
            // BosnianMenuItem
            // 
            this.BosnianMenuItem.Name = "BosnianMenuItem";
            this.BosnianMenuItem.Size = new System.Drawing.Size(190, 22);
            this.BosnianMenuItem.Text = "Bosnian";
            // 
            // CatalanMenuItem
            // 
            this.CatalanMenuItem.Name = "CatalanMenuItem";
            this.CatalanMenuItem.Size = new System.Drawing.Size(190, 22);
            this.CatalanMenuItem.Text = "Catalan";
            // 
            // CzechMenuItem
            // 
            this.CzechMenuItem.Name = "CzechMenuItem";
            this.CzechMenuItem.Size = new System.Drawing.Size(190, 22);
            this.CzechMenuItem.Text = "Czech";
            // 
            // WelshMenuItem
            // 
            this.WelshMenuItem.Name = "WelshMenuItem";
            this.WelshMenuItem.Size = new System.Drawing.Size(190, 22);
            this.WelshMenuItem.Text = "Welsh";
            // 
            // DanishMenuItem
            // 
            this.DanishMenuItem.Name = "DanishMenuItem";
            this.DanishMenuItem.Size = new System.Drawing.Size(190, 22);
            this.DanishMenuItem.Text = "Danish";
            // 
            // GermanMenuItem
            // 
            this.GermanMenuItem.Name = "GermanMenuItem";
            this.GermanMenuItem.Size = new System.Drawing.Size(190, 22);
            this.GermanMenuItem.Text = "German";
            // 
            // GreekMenuItem
            // 
            this.GreekMenuItem.Name = "GreekMenuItem";
            this.GreekMenuItem.Size = new System.Drawing.Size(190, 22);
            this.GreekMenuItem.Text = "Greek";
            // 
            // EnglishMenuItem
            // 
            this.EnglishMenuItem.Name = "EnglishMenuItem";
            this.EnglishMenuItem.Size = new System.Drawing.Size(190, 22);
            this.EnglishMenuItem.Text = "English";
            // 
            // SpanishMenuItem
            // 
            this.SpanishMenuItem.Name = "SpanishMenuItem";
            this.SpanishMenuItem.Size = new System.Drawing.Size(190, 22);
            this.SpanishMenuItem.Text = "Spanish";
            // 
            // EstonianMenuItem
            // 
            this.EstonianMenuItem.Name = "EstonianMenuItem";
            this.EstonianMenuItem.Size = new System.Drawing.Size(190, 22);
            this.EstonianMenuItem.Text = "Estonian";
            // 
            // BasqueMenuItem
            // 
            this.BasqueMenuItem.Name = "BasqueMenuItem";
            this.BasqueMenuItem.Size = new System.Drawing.Size(190, 22);
            this.BasqueMenuItem.Text = "Basque";
            // 
            // PersianMenuItem
            // 
            this.PersianMenuItem.Name = "PersianMenuItem";
            this.PersianMenuItem.Size = new System.Drawing.Size(190, 22);
            this.PersianMenuItem.Text = "Persian";
            // 
            // FinnishMenuItem
            // 
            this.FinnishMenuItem.Name = "FinnishMenuItem";
            this.FinnishMenuItem.Size = new System.Drawing.Size(190, 22);
            this.FinnishMenuItem.Text = "Finnish";
            // 
            // FilipinoMenuItem
            // 
            this.FilipinoMenuItem.Name = "FilipinoMenuItem";
            this.FilipinoMenuItem.Size = new System.Drawing.Size(190, 22);
            this.FilipinoMenuItem.Text = "Filipino";
            // 
            // FrenchMenuItem
            // 
            this.FrenchMenuItem.Name = "FrenchMenuItem";
            this.FrenchMenuItem.Size = new System.Drawing.Size(190, 22);
            this.FrenchMenuItem.Text = "French";
            // 
            // IrishMenuItem
            // 
            this.IrishMenuItem.Name = "IrishMenuItem";
            this.IrishMenuItem.Size = new System.Drawing.Size(190, 22);
            this.IrishMenuItem.Text = "Irish";
            // 
            // ScottishGaelicMenuItem
            // 
            this.ScottishGaelicMenuItem.Name = "ScottishGaelicMenuItem";
            this.ScottishGaelicMenuItem.Size = new System.Drawing.Size(190, 22);
            this.ScottishGaelicMenuItem.Text = "Scottish Gaelic";
            // 
            // GalicianMenuItem
            // 
            this.GalicianMenuItem.Name = "GalicianMenuItem";
            this.GalicianMenuItem.Size = new System.Drawing.Size(190, 22);
            this.GalicianMenuItem.Text = "Galician";
            // 
            // GujaratiMenuItem
            // 
            this.GujaratiMenuItem.Name = "GujaratiMenuItem";
            this.GujaratiMenuItem.Size = new System.Drawing.Size(190, 22);
            this.GujaratiMenuItem.Text = "Gujarati";
            // 
            // HausaMenuItem
            // 
            this.HausaMenuItem.Name = "HausaMenuItem";
            this.HausaMenuItem.Size = new System.Drawing.Size(190, 22);
            this.HausaMenuItem.Text = "Hausa";
            // 
            // HebrewMenuItem
            // 
            this.HebrewMenuItem.Name = "HebrewMenuItem";
            this.HebrewMenuItem.Size = new System.Drawing.Size(190, 22);
            this.HebrewMenuItem.Text = "Hebrew";
            // 
            // HindiMenuItem
            // 
            this.HindiMenuItem.Name = "HindiMenuItem";
            this.HindiMenuItem.Size = new System.Drawing.Size(190, 22);
            this.HindiMenuItem.Text = "Hindi";
            // 
            // CroatianMenuItem
            // 
            this.CroatianMenuItem.Name = "CroatianMenuItem";
            this.CroatianMenuItem.Size = new System.Drawing.Size(190, 22);
            this.CroatianMenuItem.Text = "Croatian";
            // 
            // HungarianMenuItem
            // 
            this.HungarianMenuItem.Name = "HungarianMenuItem";
            this.HungarianMenuItem.Size = new System.Drawing.Size(190, 22);
            this.HungarianMenuItem.Text = "Hungarian";
            // 
            // ArmenianMenuItem
            // 
            this.ArmenianMenuItem.Name = "ArmenianMenuItem";
            this.ArmenianMenuItem.Size = new System.Drawing.Size(190, 22);
            this.ArmenianMenuItem.Text = "Armenian";
            // 
            // IndonesianMenuItem
            // 
            this.IndonesianMenuItem.Name = "IndonesianMenuItem";
            this.IndonesianMenuItem.Size = new System.Drawing.Size(190, 22);
            this.IndonesianMenuItem.Text = "Indonesian";
            // 
            // IgboMenuItem
            // 
            this.IgboMenuItem.Name = "IgboMenuItem";
            this.IgboMenuItem.Size = new System.Drawing.Size(190, 22);
            this.IgboMenuItem.Text = "Igbo";
            // 
            // IcelandicMenuItem
            // 
            this.IcelandicMenuItem.Name = "IcelandicMenuItem";
            this.IcelandicMenuItem.Size = new System.Drawing.Size(190, 22);
            this.IcelandicMenuItem.Text = "Icelandic";
            // 
            // ItalianMenuItem
            // 
            this.ItalianMenuItem.Name = "ItalianMenuItem";
            this.ItalianMenuItem.Size = new System.Drawing.Size(190, 22);
            this.ItalianMenuItem.Text = "Italian";
            // 
            // JapaneseMenuItem
            // 
            this.JapaneseMenuItem.Name = "JapaneseMenuItem";
            this.JapaneseMenuItem.Size = new System.Drawing.Size(190, 22);
            this.JapaneseMenuItem.Text = "Japanese";
            // 
            // GeorgianMenuItem
            // 
            this.GeorgianMenuItem.Name = "GeorgianMenuItem";
            this.GeorgianMenuItem.Size = new System.Drawing.Size(190, 22);
            this.GeorgianMenuItem.Text = "Georgian";
            // 
            // KazakhMenuItem
            // 
            this.KazakhMenuItem.Name = "KazakhMenuItem";
            this.KazakhMenuItem.Size = new System.Drawing.Size(190, 22);
            this.KazakhMenuItem.Text = "Kazakh";
            // 
            // KhmerMenuItem
            // 
            this.KhmerMenuItem.Name = "KhmerMenuItem";
            this.KhmerMenuItem.Size = new System.Drawing.Size(190, 22);
            this.KhmerMenuItem.Text = "Khmer";
            // 
            // KannadaMenuItem
            // 
            this.KannadaMenuItem.Name = "KannadaMenuItem";
            this.KannadaMenuItem.Size = new System.Drawing.Size(190, 22);
            this.KannadaMenuItem.Text = "Kannada";
            // 
            // KoreanMenuItem
            // 
            this.KoreanMenuItem.Name = "KoreanMenuItem";
            this.KoreanMenuItem.Size = new System.Drawing.Size(190, 22);
            this.KoreanMenuItem.Text = "Korean";
            // 
            // KonkaniMenuItem
            // 
            this.KonkaniMenuItem.Name = "KonkaniMenuItem";
            this.KonkaniMenuItem.Size = new System.Drawing.Size(190, 22);
            this.KonkaniMenuItem.Text = "Konkani";
            // 
            // KurdishMenuItem
            // 
            this.KurdishMenuItem.Name = "KurdishMenuItem";
            this.KurdishMenuItem.Size = new System.Drawing.Size(190, 22);
            this.KurdishMenuItem.Text = "Kurdish";
            // 
            // KyrgyzMenuItem
            // 
            this.KyrgyzMenuItem.Name = "KyrgyzMenuItem";
            this.KyrgyzMenuItem.Size = new System.Drawing.Size(190, 22);
            this.KyrgyzMenuItem.Text = "Kyrgyz";
            // 
            // LuxembourgishMenuItem
            // 
            this.LuxembourgishMenuItem.Name = "LuxembourgishMenuItem";
            this.LuxembourgishMenuItem.Size = new System.Drawing.Size(190, 22);
            this.LuxembourgishMenuItem.Text = "Luxembourgish";
            // 
            // LaoMenuItem
            // 
            this.LaoMenuItem.Name = "LaoMenuItem";
            this.LaoMenuItem.Size = new System.Drawing.Size(190, 22);
            this.LaoMenuItem.Text = "Lao";
            // 
            // LithuanianMenuItem
            // 
            this.LithuanianMenuItem.Name = "LithuanianMenuItem";
            this.LithuanianMenuItem.Size = new System.Drawing.Size(190, 22);
            this.LithuanianMenuItem.Text = "Lithuanian";
            // 
            // LatvianMenuItem
            // 
            this.LatvianMenuItem.Name = "LatvianMenuItem";
            this.LatvianMenuItem.Size = new System.Drawing.Size(190, 22);
            this.LatvianMenuItem.Text = "Latvian";
            // 
            // MaoriMenuItem
            // 
            this.MaoriMenuItem.Name = "MaoriMenuItem";
            this.MaoriMenuItem.Size = new System.Drawing.Size(190, 22);
            this.MaoriMenuItem.Text = "Maori";
            // 
            // MacedonianMenuItem
            // 
            this.MacedonianMenuItem.Name = "MacedonianMenuItem";
            this.MacedonianMenuItem.Size = new System.Drawing.Size(190, 22);
            this.MacedonianMenuItem.Text = "Macedonian";
            // 
            // MalayalamMenuItem
            // 
            this.MalayalamMenuItem.Name = "MalayalamMenuItem";
            this.MalayalamMenuItem.Size = new System.Drawing.Size(190, 22);
            this.MalayalamMenuItem.Text = "Malayalam";
            // 
            // MongolianMenuItem
            // 
            this.MongolianMenuItem.Name = "MongolianMenuItem";
            this.MongolianMenuItem.Size = new System.Drawing.Size(190, 22);
            this.MongolianMenuItem.Text = "Mongolian";
            // 
            // MarathiMenuItem
            // 
            this.MarathiMenuItem.Name = "MarathiMenuItem";
            this.MarathiMenuItem.Size = new System.Drawing.Size(190, 22);
            this.MarathiMenuItem.Text = "Marathi";
            // 
            // MalayMenuItem
            // 
            this.MalayMenuItem.Name = "MalayMenuItem";
            this.MalayMenuItem.Size = new System.Drawing.Size(190, 22);
            this.MalayMenuItem.Text = "Malay";
            // 
            // MalteseMenuItem
            // 
            this.MalteseMenuItem.Name = "MalteseMenuItem";
            this.MalteseMenuItem.Size = new System.Drawing.Size(190, 22);
            this.MalteseMenuItem.Text = "Maltese";
            // 
            // BurmeseMenuItem
            // 
            this.BurmeseMenuItem.Name = "BurmeseMenuItem";
            this.BurmeseMenuItem.Size = new System.Drawing.Size(190, 22);
            this.BurmeseMenuItem.Text = "Burmese";
            // 
            // NorwegianBokmalMenuItem
            // 
            this.NorwegianBokmalMenuItem.Name = "NorwegianBokmalMenuItem";
            this.NorwegianBokmalMenuItem.Size = new System.Drawing.Size(190, 22);
            this.NorwegianBokmalMenuItem.Text = "Norwegian Bokmål";
            // 
            // NepaliMenuItem
            // 
            this.NepaliMenuItem.Name = "NepaliMenuItem";
            this.NepaliMenuItem.Size = new System.Drawing.Size(190, 22);
            this.NepaliMenuItem.Text = "Nepali";
            // 
            // DutchMenuItem
            // 
            this.DutchMenuItem.Name = "DutchMenuItem";
            this.DutchMenuItem.Size = new System.Drawing.Size(190, 22);
            this.DutchMenuItem.Text = "Dutch";
            // 
            // NorwegianNynorskMenuItem
            // 
            this.NorwegianNynorskMenuItem.Name = "NorwegianNynorskMenuItem";
            this.NorwegianNynorskMenuItem.Size = new System.Drawing.Size(190, 22);
            this.NorwegianNynorskMenuItem.Text = "Norwegian Nynorsk";
            // 
            // SesothoSaLeboaMenuItem
            // 
            this.SesothoSaLeboaMenuItem.Name = "SesothoSaLeboaMenuItem";
            this.SesothoSaLeboaMenuItem.Size = new System.Drawing.Size(190, 22);
            this.SesothoSaLeboaMenuItem.Text = "Sesotho sa Leboa";
            // 
            // OdiaMenuItem
            // 
            this.OdiaMenuItem.Name = "OdiaMenuItem";
            this.OdiaMenuItem.Size = new System.Drawing.Size(190, 22);
            this.OdiaMenuItem.Text = "Odia";
            // 
            // PunjabiMenuItem
            // 
            this.PunjabiMenuItem.Name = "PunjabiMenuItem";
            this.PunjabiMenuItem.Size = new System.Drawing.Size(190, 22);
            this.PunjabiMenuItem.Text = "Punjabi";
            // 
            // PolishMenuItem
            // 
            this.PolishMenuItem.Name = "PolishMenuItem";
            this.PolishMenuItem.Size = new System.Drawing.Size(190, 22);
            this.PolishMenuItem.Text = "Polish";
            // 
            // PashtoMenuItem
            // 
            this.PashtoMenuItem.Name = "PashtoMenuItem";
            this.PashtoMenuItem.Size = new System.Drawing.Size(190, 22);
            this.PashtoMenuItem.Text = "Pashto";
            // 
            // PortugueseMenuItem
            // 
            this.PortugueseMenuItem.Name = "PortugueseMenuItem";
            this.PortugueseMenuItem.Size = new System.Drawing.Size(190, 22);
            this.PortugueseMenuItem.Text = "Portuguese";
            // 
            // QuechuaMenuItem
            // 
            this.QuechuaMenuItem.Name = "QuechuaMenuItem";
            this.QuechuaMenuItem.Size = new System.Drawing.Size(190, 22);
            this.QuechuaMenuItem.Text = "Quechua";
            // 
            // RomanianMenuItem
            // 
            this.RomanianMenuItem.Name = "RomanianMenuItem";
            this.RomanianMenuItem.Size = new System.Drawing.Size(190, 22);
            this.RomanianMenuItem.Text = "Romanian";
            // 
            // RussianMenuItem
            // 
            this.RussianMenuItem.Name = "RussianMenuItem";
            this.RussianMenuItem.Size = new System.Drawing.Size(190, 22);
            this.RussianMenuItem.Text = "Russian";
            // 
            // KinyarwandaMenuItem
            // 
            this.KinyarwandaMenuItem.Name = "KinyarwandaMenuItem";
            this.KinyarwandaMenuItem.Size = new System.Drawing.Size(190, 22);
            this.KinyarwandaMenuItem.Text = "Kinyarwanda";
            // 
            // SinhalaMenuItem
            // 
            this.SinhalaMenuItem.Name = "SinhalaMenuItem";
            this.SinhalaMenuItem.Size = new System.Drawing.Size(190, 22);
            this.SinhalaMenuItem.Text = "Sinhala";
            // 
            // SlovakMenuItem
            // 
            this.SlovakMenuItem.Name = "SlovakMenuItem";
            this.SlovakMenuItem.Size = new System.Drawing.Size(190, 22);
            this.SlovakMenuItem.Text = "Slovak";
            // 
            // SlovenianMenuItem
            // 
            this.SlovenianMenuItem.Name = "SlovenianMenuItem";
            this.SlovenianMenuItem.Size = new System.Drawing.Size(190, 22);
            this.SlovenianMenuItem.Text = "Slovenian";
            // 
            // AlbanianMenuItem
            // 
            this.AlbanianMenuItem.Name = "AlbanianMenuItem";
            this.AlbanianMenuItem.Size = new System.Drawing.Size(190, 22);
            this.AlbanianMenuItem.Text = "Albanian";
            // 
            // SerbianMenuItem
            // 
            this.SerbianMenuItem.Name = "SerbianMenuItem";
            this.SerbianMenuItem.Size = new System.Drawing.Size(190, 22);
            this.SerbianMenuItem.Text = "Serbian";
            // 
            // SwedishMenuItem
            // 
            this.SwedishMenuItem.Name = "SwedishMenuItem";
            this.SwedishMenuItem.Size = new System.Drawing.Size(190, 22);
            this.SwedishMenuItem.Text = "Swedish";
            // 
            // SwahiliMenuItem
            // 
            this.SwahiliMenuItem.Name = "SwahiliMenuItem";
            this.SwahiliMenuItem.Size = new System.Drawing.Size(190, 22);
            this.SwahiliMenuItem.Text = "Swahili";
            // 
            // TamilMenuItem
            // 
            this.TamilMenuItem.Name = "TamilMenuItem";
            this.TamilMenuItem.Size = new System.Drawing.Size(190, 22);
            this.TamilMenuItem.Text = "Tamil";
            // 
            // TeluguMenuItem
            // 
            this.TeluguMenuItem.Name = "TeluguMenuItem";
            this.TeluguMenuItem.Size = new System.Drawing.Size(190, 22);
            this.TeluguMenuItem.Text = "Telugu";
            // 
            // TajikMenuItem
            // 
            this.TajikMenuItem.Name = "TajikMenuItem";
            this.TajikMenuItem.Size = new System.Drawing.Size(190, 22);
            this.TajikMenuItem.Text = "Tajik";
            // 
            // ThaiMenuItem
            // 
            this.ThaiMenuItem.Name = "ThaiMenuItem";
            this.ThaiMenuItem.Size = new System.Drawing.Size(190, 22);
            this.ThaiMenuItem.Text = "Thai";
            // 
            // TurkmenMenuItem
            // 
            this.TurkmenMenuItem.Name = "TurkmenMenuItem";
            this.TurkmenMenuItem.Size = new System.Drawing.Size(190, 22);
            this.TurkmenMenuItem.Text = "Turkmen";
            // 
            // SetswanaMenuItem
            // 
            this.SetswanaMenuItem.Name = "SetswanaMenuItem";
            this.SetswanaMenuItem.Size = new System.Drawing.Size(190, 22);
            this.SetswanaMenuItem.Text = "Setswana";
            // 
            // TurkishMenuItem
            // 
            this.TurkishMenuItem.Name = "TurkishMenuItem";
            this.TurkishMenuItem.Size = new System.Drawing.Size(190, 22);
            this.TurkishMenuItem.Text = "Turkish";
            // 
            // TatarMenuItem
            // 
            this.TatarMenuItem.Name = "TatarMenuItem";
            this.TatarMenuItem.Size = new System.Drawing.Size(190, 22);
            this.TatarMenuItem.Text = "Tatar";
            // 
            // UyghurMenuItem
            // 
            this.UyghurMenuItem.Name = "UyghurMenuItem";
            this.UyghurMenuItem.Size = new System.Drawing.Size(190, 22);
            this.UyghurMenuItem.Text = "Uyghur";
            // 
            // UkrainianMenuItem
            // 
            this.UkrainianMenuItem.Name = "UkrainianMenuItem";
            this.UkrainianMenuItem.Size = new System.Drawing.Size(190, 22);
            this.UkrainianMenuItem.Text = "Ukrainian";
            // 
            // UrduMenuItem
            // 
            this.UrduMenuItem.Name = "UrduMenuItem";
            this.UrduMenuItem.Size = new System.Drawing.Size(190, 22);
            this.UrduMenuItem.Text = "Urdu";
            // 
            // UzbekMenuItem
            // 
            this.UzbekMenuItem.Name = "UzbekMenuItem";
            this.UzbekMenuItem.Size = new System.Drawing.Size(190, 22);
            this.UzbekMenuItem.Text = "Uzbek";
            // 
            // VietnameseMenuItem
            // 
            this.VietnameseMenuItem.Name = "VietnameseMenuItem";
            this.VietnameseMenuItem.Size = new System.Drawing.Size(190, 22);
            this.VietnameseMenuItem.Text = "Vietnamese";
            // 
            // WolofMenuItem
            // 
            this.WolofMenuItem.Name = "WolofMenuItem";
            this.WolofMenuItem.Size = new System.Drawing.Size(190, 22);
            this.WolofMenuItem.Text = "Wolof";
            // 
            // XhosaMenuItem
            // 
            this.XhosaMenuItem.Name = "XhosaMenuItem";
            this.XhosaMenuItem.Size = new System.Drawing.Size(190, 22);
            this.XhosaMenuItem.Text = "Xhosa";
            // 
            // YorubaMenuItem
            // 
            this.YorubaMenuItem.Name = "YorubaMenuItem";
            this.YorubaMenuItem.Size = new System.Drawing.Size(190, 22);
            this.YorubaMenuItem.Text = "Yoruba";
            // 
            // ChineseSimplifiedMenuItem
            // 
            this.ChineseSimplifiedMenuItem.Name = "ChineseSimplifiedMenuItem";
            this.ChineseSimplifiedMenuItem.Size = new System.Drawing.Size(190, 22);
            this.ChineseSimplifiedMenuItem.Text = "Chinese (Simplified)";
            // 
            // ChineseTraditionalMenuItem
            // 
            this.ChineseTraditionalMenuItem.Name = "ChineseTraditionalMenuItem";
            this.ChineseTraditionalMenuItem.Size = new System.Drawing.Size(190, 22);
            this.ChineseTraditionalMenuItem.Text = "Chinese (Traditional)";
            // 
            // ZuluMenuItem
            // 
            this.ZuluMenuItem.Name = "ZuluMenuItem";
            this.ZuluMenuItem.Size = new System.Drawing.Size(190, 22);
            this.ZuluMenuItem.Text = "Zulu";
            // 
            // Keyboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.Controls.Add(this.tableLayoutPanel);
            this.Name = "Keyboard";
            this.Size = new System.Drawing.Size(926, 413);
            this.Load += new System.EventHandler(this.Keyboard_Load);
            this.tableLayoutPanel.ResumeLayout(false);
            this.langMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);

        }
        #endregion
        private System.Windows.Forms.Button c7;
        private System.Windows.Forms.Button c8;
        private System.Windows.Forms.Button c9;
        private System.Windows.Forms.Button c10;
        private System.Windows.Forms.Button d1;
        private System.Windows.Forms.Button d2;
        private System.Windows.Forms.Button d3;
        private System.Windows.Forms.Button d4;
        private System.Windows.Forms.Button d5;
        private System.Windows.Forms.Button d6;
        private System.Windows.Forms.Button d7;
        private System.Windows.Forms.Button d8;
        private System.Windows.Forms.Button d9;
        private System.Windows.Forms.Button e3;
        private System.Windows.Forms.Button e4;
        private System.Windows.Forms.Button e5;
        private System.Windows.Forms.Button e6;
        private System.Windows.Forms.Button e7;
        private System.Windows.Forms.Button e8;
        private System.Windows.Forms.Button e9;
        private System.Windows.Forms.Button btn_space;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button c1;
        private System.Windows.Forms.Button c2;
        private System.Windows.Forms.Button c3;
        private System.Windows.Forms.Button c4;
        private System.Windows.Forms.Button c5;
        private System.Windows.Forms.Button c6;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.Button btn_OK;
        private System.Windows.Forms.CheckBox chk_shift;
        private System.Windows.Forms.Button e11;
        private System.Windows.Forms.Button e1;
        private System.Windows.Forms.Button d10;
        private System.Windows.Forms.Button e10;
        private System.Windows.Forms.Button b6;
        private System.Windows.Forms.Button b5;
        private System.Windows.Forms.Button b4;
        private System.Windows.Forms.Button b3;
        private System.Windows.Forms.Button b2;
        private System.Windows.Forms.Button b1;
        private System.Windows.Forms.Button b10;
        private System.Windows.Forms.Button b9;
        private System.Windows.Forms.Button b8;
        private System.Windows.Forms.Button b7;
        private System.Windows.Forms.Button b11;
        private System.Windows.Forms.Button e12;
        private System.Windows.Forms.Button e2;
        private System.Windows.Forms.Button btnApos;
        private System.Windows.Forms.Button c11;
        private System.Windows.Forms.Button c12;
        private System.Windows.Forms.Button b12;
        private System.Windows.Forms.Button d11;
        private System.Windows.Forms.Button d12;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel;
        private System.Windows.Forms.Button btn_backspace;
        private System.Windows.Forms.Button a11;
        private System.Windows.Forms.Button a5;
        private System.Windows.Forms.Button a10;
        private System.Windows.Forms.Button a7;
        private System.Windows.Forms.Button a9;
        private System.Windows.Forms.Button a8;
        private System.Windows.Forms.Button a4;
        private System.Windows.Forms.Button a2;
        private System.Windows.Forms.Button a1;
        private System.Windows.Forms.Button a3;
        private System.Windows.Forms.Button a6;
        private System.Windows.Forms.Button btn_lang;
        private ContextMenuStrip langMenuStrip;
        

        private Button e13;
        private Button d14;
        private Button c14;
        private Button c13;
        private Button b14;
        private Button b13;
        private Button a13;
        private Button a12;
        private Button d13;
        private Button e14;



        private ToolStripMenuItem AfrikaansMenuItem;
        private ToolStripMenuItem AmharicMenuItem;
        private ToolStripMenuItem ArabicMenuItem;
        private ToolStripMenuItem AssameseMenuItem;
        private ToolStripMenuItem AzerbaijaniMenuItem;
        private ToolStripMenuItem BelarusianMenuItem;
        private ToolStripMenuItem BulgarianMenuItem;
        private ToolStripMenuItem BengaliMenuItem;
        private ToolStripMenuItem BosnianMenuItem;
        private ToolStripMenuItem CatalanMenuItem;
        private ToolStripMenuItem CzechMenuItem;
        private ToolStripMenuItem WelshMenuItem;
        private ToolStripMenuItem DanishMenuItem;
        private ToolStripMenuItem GermanMenuItem;
        private ToolStripMenuItem GreekMenuItem;
        private ToolStripMenuItem EnglishMenuItem;
        private ToolStripMenuItem SpanishMenuItem;
        private ToolStripMenuItem EstonianMenuItem;
        private ToolStripMenuItem BasqueMenuItem;
        private ToolStripMenuItem PersianMenuItem;
        private ToolStripMenuItem FinnishMenuItem;
        private ToolStripMenuItem FilipinoMenuItem;
        private ToolStripMenuItem FrenchMenuItem;
        private ToolStripMenuItem IrishMenuItem;
        private ToolStripMenuItem ScottishGaelicMenuItem;
        private ToolStripMenuItem GalicianMenuItem;
        private ToolStripMenuItem GujaratiMenuItem;
        private ToolStripMenuItem HausaMenuItem;
        private ToolStripMenuItem HebrewMenuItem;
        private ToolStripMenuItem HindiMenuItem;
        private ToolStripMenuItem CroatianMenuItem;
        private ToolStripMenuItem HungarianMenuItem;
        private ToolStripMenuItem ArmenianMenuItem;
        private ToolStripMenuItem IndonesianMenuItem;
        private ToolStripMenuItem IgboMenuItem;
        private ToolStripMenuItem IcelandicMenuItem;
        private ToolStripMenuItem ItalianMenuItem;
        private ToolStripMenuItem JapaneseMenuItem;
        private ToolStripMenuItem GeorgianMenuItem;
        private ToolStripMenuItem KazakhMenuItem;
        private ToolStripMenuItem KhmerMenuItem;
        private ToolStripMenuItem KannadaMenuItem;
        private ToolStripMenuItem KoreanMenuItem;
        private ToolStripMenuItem KonkaniMenuItem;
        private ToolStripMenuItem KurdishMenuItem;
        private ToolStripMenuItem KyrgyzMenuItem;
        private ToolStripMenuItem LuxembourgishMenuItem;
        private ToolStripMenuItem LaoMenuItem;
        private ToolStripMenuItem LithuanianMenuItem;
        private ToolStripMenuItem LatvianMenuItem;
        private ToolStripMenuItem MaoriMenuItem;
        private ToolStripMenuItem MacedonianMenuItem;
        private ToolStripMenuItem MalayalamMenuItem;
        private ToolStripMenuItem MongolianMenuItem;
        private ToolStripMenuItem MarathiMenuItem;
        private ToolStripMenuItem MalayMenuItem;
        private ToolStripMenuItem MalteseMenuItem;
        private ToolStripMenuItem BurmeseMenuItem;
        private ToolStripMenuItem NorwegianBokmalMenuItem;
        private ToolStripMenuItem NepaliMenuItem;
        private ToolStripMenuItem DutchMenuItem;
        private ToolStripMenuItem NorwegianNynorskMenuItem;
        private ToolStripMenuItem SesothoSaLeboaMenuItem;
        private ToolStripMenuItem OdiaMenuItem;
        private ToolStripMenuItem PunjabiMenuItem;
        private ToolStripMenuItem PolishMenuItem;
        private ToolStripMenuItem PashtoMenuItem;
        private ToolStripMenuItem PortugueseMenuItem;
        private ToolStripMenuItem QuechuaMenuItem;
        private ToolStripMenuItem RomanianMenuItem;
        private ToolStripMenuItem RussianMenuItem;
        private ToolStripMenuItem KinyarwandaMenuItem;
        private ToolStripMenuItem SinhalaMenuItem;
        private ToolStripMenuItem SlovakMenuItem;
        private ToolStripMenuItem SlovenianMenuItem;
        private ToolStripMenuItem AlbanianMenuItem;
        private ToolStripMenuItem SerbianMenuItem;
        private ToolStripMenuItem SwedishMenuItem;
        private ToolStripMenuItem SwahiliMenuItem;
        private ToolStripMenuItem TamilMenuItem;
        private ToolStripMenuItem TeluguMenuItem;
        private ToolStripMenuItem TajikMenuItem;
        private ToolStripMenuItem ThaiMenuItem;
        private ToolStripMenuItem TurkmenMenuItem;
        private ToolStripMenuItem SetswanaMenuItem;
        private ToolStripMenuItem TurkishMenuItem;
        private ToolStripMenuItem TatarMenuItem;
        private ToolStripMenuItem UyghurMenuItem;
        private ToolStripMenuItem UkrainianMenuItem;
        private ToolStripMenuItem UrduMenuItem;
        private ToolStripMenuItem UzbekMenuItem;
        private ToolStripMenuItem VietnameseMenuItem;
        private ToolStripMenuItem WolofMenuItem;
        private ToolStripMenuItem XhosaMenuItem;
        private ToolStripMenuItem YorubaMenuItem;
        private ToolStripMenuItem ChineseSimplifiedMenuItem;
        private ToolStripMenuItem ChineseTraditionalMenuItem;
        private ToolStripMenuItem ZuluMenuItem;





    }
}
