﻿using System;
using System.Windows.Forms;
using System.Globalization;
using System.Drawing;
using Microsoft.Win32;
using System.IO;
using System.Collections.Generic;
using System.Linq;



/* 
 * 
 * 
 * Special thanks to Ray Bear for pounding out the original program
 * for keys.
 * 
 */
namespace Keypad
{
    public partial class Keyboard : GenericKeypad
    {
        private string currentLanguage = "en"; // Default to English




        private static readonly List<string[]> LanguageAbbreviations = new List<string[]>
{
    new[] {"af", "AF", "Afrikaans"},
    new[] {"am", "AM", "Amharic"},
    new[] {"ar", "AR", "Arabic"},
    new[] {"as", "AS", "Assamese"},
    new[] {"az", "AZ", "Azerbaijani"},
    new[] {"be", "BE", "Belarusian"},
    new[] {"bg", "BG", "Bulgarian"},
    new[] {"bn", "BN", "Bengali"},
    new[] {"bs", "BS", "Bosnian"},
    new[] {"ca", "CA", "Catalan"},
    new[] {"cs", "CS", "Czech"},
    new[] {"cy", "CY", "Welsh"},
    new[] {"da", "DA", "Danish"},
    new[] {"de", "DE", "German"},
    new[] {"el", "EL", "Greek"},
    new[] {"en", "EN", "English"},
    new[] {"es", "ES", "Spanish"},
    new[] {"et", "ET", "Estonian"},
    new[] {"eu", "EU", "Basque"},
    new[] {"fa", "FA", "Persian"},
    new[] {"fi", "FI", "Finnish"},
    new[] {"fil", "FIL", "Filipino"},
    new[] {"fr", "FR", "French"},
    new[] {"ga", "GA", "Irish"},
    new[] {"gd", "GD", "Scottish Gaelic"},
    new[] {"gl", "GL", "Galician"},
    new[] {"gu", "GU", "Gujarati"},
    new[] {"ha", "HA", "Hausa"},
    new[] {"he", "HE", "Hebrew"},
    new[] {"hi", "HI", "Hindi"},
    new[] {"hr", "HR", "Croatian"},
    new[] {"hu", "HU", "Hungarian"},
    new[] {"hy", "HY", "Armenian"},
    new[] {"id", "ID", "Indonesian"},
    new[] {"ig", "IG", "Igbo"},
    new[] {"is", "IS", "Icelandic"},
    new[] {"it", "IT", "Italian"},
    new[] {"ja", "JA", "Japanese"},
    new[] {"ka", "KA", "Georgian"},
    new[] {"kk", "KK", "Kazakh"},
    new[] {"km", "KM", "Khmer"},
    new[] {"kn", "KN", "Kannada"},
    new[] {"ko", "KO", "Korean"},
    new[] {"kok", "KOK", "Konkani"},
    new[] {"ku", "KU", "Kurdish"},
    new[] {"ky", "KY", "Kyrgyz"},
    new[] {"lb", "LB", "Luxembourgish"},
    new[] {"lo", "LO", "Lao"},
    new[] {"lt", "LT", "Lithuanian"},
    new[] {"lv", "LV", "Latvian"},
    new[] {"mi", "MI", "Maori"},
    new[] {"mk", "MK", "Macedonian"},
    new[] {"ml", "ML", "Malayalam"},
    new[] {"mn", "MN", "Mongolian"},
    new[] {"mr", "MR", "Marathi"},
    new[] {"ms", "MS", "Malay"},
    new[] {"mt", "MT", "Maltese"},
    new[] {"my", "MY", "Burmese"},
    new[] {"nb", "NB", "Norwegian Bokmål"},
    new[] {"ne", "NE", "Nepali"},
    new[] {"nl", "NL", "Dutch"},
    new[] {"nn", "NN", "Norwegian Nynorsk"},
    new[] {"nso", "NSO", "Sesotho sa Leboa"},
    new[] {"or", "OR", "Odia"},
    new[] {"pa", "PA", "Punjabi"},
    new[] {"pl", "PL", "Polish"},
    new[] {"ps", "PS", "Pashto"},
    new[] {"pt", "PT", "Portuguese"},
    new[] {"quz", "QUZ", "Quechua"},
    new[] {"ro", "RO", "Romanian"},
    new[] {"ru", "RU", "Russian"},
    new[] {"rw", "RW", "Kinyarwanda"},
    new[] {"si", "SI", "Sinhala"},
    new[] {"sk", "SK", "Slovak"},
    new[] {"sl", "SL", "Slovenian"},
    new[] {"sq", "SQ", "Albanian"},
    new[] {"sr", "SR", "Serbian"},
    new[] {"sv", "SV", "Swedish"},
    new[] {"sw", "SW", "Swahili"},
    new[] {"ta", "TA", "Tamil"},
    new[] {"te", "TE", "Telugu"},
    new[] {"tg", "TG", "Tajik"},
    new[] {"th", "TH", "Thai"},
    new[] {"tk", "TK", "Turkmen"},
    new[] {"tn", "TN", "Setswana"},
    new[] {"tr", "TR", "Turkish"},
    new[] {"tt", "TT", "Tatar"},
    new[] {"ug", "UG", "Uyghur"},
    new[] {"uk", "UK", "Ukrainian"},
    new[] {"ur", "UR", "Urdu"},
    new[] {"uz", "UZ", "Uzbek"},
    new[] {"vi", "VI", "Vietnamese"},
    new[] {"wo", "WO", "Wolof"},
    new[] {"xh", "XH", "Xhosa"},
    new[] {"yo", "YO", "Yoruba"},
    new[] {"zh-CHS", "CHS", "Chinese (Simplified)"},
    new[] {"zh-CHT", "CHT", "Chinese (Traditional)"},
    new[] {"zu", "ZU", "Zulu"}
};



        // Get abbreviation from language code
        public static string GetAbbreviation(string languageCode)
        {
            var language = LanguageAbbreviations
                .FirstOrDefault(lang => lang[0].Equals(languageCode, StringComparison.OrdinalIgnoreCase));
            return language != null ? language[1] : "EN"; // Default to English if not found
        }

        // Get language code from abbreviation
        public static string GetLanguageCode(string abbreviation)
        {
            var language = LanguageAbbreviations
                .FirstOrDefault(lang => lang[1].Equals(abbreviation, StringComparison.OrdinalIgnoreCase));
            return language != null ? language[0] : "en"; // Default to English if not found
        }

        // Get all available language options
        public static List<(string LanguageCode, string Abbreviation, string LanguageName)> GetAllLanguages()
        {
            return LanguageAbbreviations
                .Select(lang => (LanguageCode: lang[0], Abbreviation: lang[1], LanguageName: lang[2]))
                .ToList();
        }


        // 定義設置文件路徑
        private readonly string settingsFilePath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "KeypadSettings.json");

        // 新增常量用於保存設定
        private const string RegistryKeyPath = @"Software\YourCompany\Keypad";
        private const string LanguageValueName = "SelectedLanguage";

        // 保存語言設置到文件
        private void SaveLanguageSetting(string language)
        {
            try
            {
                // 確保目錄存在
                Directory.CreateDirectory(Path.GetDirectoryName(settingsFilePath));

                // 寫入文件
                File.WriteAllText(settingsFilePath, language);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"保存語言設置時出錯: {ex.Message}");
            }
        }



        // 從文件讀取語言設置
        private string LoadLanguageSetting()
        {
            try
            {
                if (File.Exists(settingsFilePath))
                {
                    return File.ReadAllText(settingsFilePath);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"讀取語言設置時出錯: {ex.Message}");
            }
            return "en"; // 默認值
        }




        // 或者使用註冊表（需要管理員權限）
        private void SaveLanguageToRegistry(string language)
        {
            try
            {
                RegistryKey key = Registry.CurrentUser.CreateSubKey(RegistryKeyPath);
                key.SetValue(LanguageValueName, language);
                key.Close();
            }
            catch (Exception ex)
            {
                // 處理錯誤，例如寫入日誌
                Console.WriteLine($"無法保存到註冊表: {ex.Message}");
            }
        }

        private string LoadLanguageFromRegistry()
        {
            try
            {
                RegistryKey key = Registry.CurrentUser.OpenSubKey(RegistryKeyPath);
                if (key != null)
                {
                    object value = key.GetValue(LanguageValueName);
                    key.Close();
                    return value?.ToString() ?? "en";
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"無法讀取註冊表: {ex.Message}");
            }
            return "en";
        }


        private void SaveLanguageToFile(string language)
        {
            try
            {
                File.WriteAllText(settingsFilePath, language);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"無法保存到文件: {ex.Message}");
            }
        }

        private string LoadLanguageFromFile()
        {
            try
            {
                if (File.Exists(settingsFilePath))
                {
                    return File.ReadAllText(settingsFilePath);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"無法讀取文件: {ex.Message}");
            }
            return "en";
        }


        public Keyboard()
        {
            InitializeComponent();
        }



        private void Keyboard_Load(object sender, EventArgs e)
        {
            currentLanguage = LoadLanguageSetting(); // 或使用其他讀取方法
            CultureInfo.CurrentCulture = new CultureInfo(currentLanguage);
            btn_lang.Text =  GetAbbreviation(currentLanguage);
            chk_shift.Checked = false;
            changeCase();
            tableLayoutPanel.Invalidate(); // 強制重繪佈局
            this.Invalidate(); // 強制重繪表單
            this.Refresh();
        }



        private void UpdateLanguageMenuCheckState()
        {


            AfrikaansMenuItem.Checked = currentLanguage == "af";
            AmharicMenuItem.Checked = currentLanguage == "am";
            ArabicMenuItem.Checked = currentLanguage == "ar";
            AssameseMenuItem.Checked = currentLanguage == "as";
            AzerbaijaniMenuItem.Checked = currentLanguage == "az";
            BelarusianMenuItem.Checked = currentLanguage == "be";
            BulgarianMenuItem.Checked = currentLanguage == "bg";
            BengaliMenuItem.Checked = currentLanguage == "bn"; // 涵蓋 bn-BD 和 bn-IN
            BosnianMenuItem.Checked = currentLanguage == "bs";
            CatalanMenuItem.Checked = currentLanguage == "ca";
            CzechMenuItem.Checked = currentLanguage == "cs";
            WelshMenuItem.Checked = currentLanguage == "cy";
            DanishMenuItem.Checked = currentLanguage == "da";
            GermanMenuItem.Checked = currentLanguage == "de";
            GreekMenuItem.Checked = currentLanguage == "el";
            EnglishMenuItem.Checked = currentLanguage == "en";
            SpanishMenuItem.Checked = currentLanguage == "es";
            EstonianMenuItem.Checked = currentLanguage == "et";
            BasqueMenuItem.Checked = currentLanguage == "eu";
            PersianMenuItem.Checked = currentLanguage == "fa";
            FinnishMenuItem.Checked = currentLanguage == "fi";
            FilipinoMenuItem.Checked = currentLanguage == "fil";
            FrenchMenuItem.Checked = currentLanguage == "fr";
            IrishMenuItem.Checked = currentLanguage == "ga";
            ScottishGaelicMenuItem.Checked = currentLanguage == "gd";
            GalicianMenuItem.Checked = currentLanguage == "gl";
            GujaratiMenuItem.Checked = currentLanguage == "gu";
            HausaMenuItem.Checked = currentLanguage == "ha";
            HebrewMenuItem.Checked = currentLanguage == "he";
            HindiMenuItem.Checked = currentLanguage == "hi";
            CroatianMenuItem.Checked = currentLanguage == "hr";
            HungarianMenuItem.Checked = currentLanguage == "hu";
            ArmenianMenuItem.Checked = currentLanguage == "hy";
            IndonesianMenuItem.Checked = currentLanguage == "id";
            IgboMenuItem.Checked = currentLanguage == "ig";
            IcelandicMenuItem.Checked = currentLanguage == "is";
            ItalianMenuItem.Checked = currentLanguage == "it";
            JapaneseMenuItem.Checked = currentLanguage == "ja";
            GeorgianMenuItem.Checked = currentLanguage == "ka";
            KazakhMenuItem.Checked = currentLanguage == "kk";
            KhmerMenuItem.Checked = currentLanguage == "km";
            KannadaMenuItem.Checked = currentLanguage == "kn";
            KoreanMenuItem.Checked = currentLanguage == "ko";
            KonkaniMenuItem.Checked = currentLanguage == "kok";
            KurdishMenuItem.Checked = currentLanguage == "ku";
            KyrgyzMenuItem.Checked = currentLanguage == "ky";
            LuxembourgishMenuItem.Checked = currentLanguage == "lb";
            LaoMenuItem.Checked = currentLanguage == "lo";
            LithuanianMenuItem.Checked = currentLanguage == "lt";
            LatvianMenuItem.Checked = currentLanguage == "lv";
            MaoriMenuItem.Checked = currentLanguage == "mi";
            MacedonianMenuItem.Checked = currentLanguage == "mk";
            MalayalamMenuItem.Checked = currentLanguage == "ml";
            MongolianMenuItem.Checked = currentLanguage == "mn";
            MarathiMenuItem.Checked = currentLanguage == "mr";
            MalayMenuItem.Checked = currentLanguage == "ms";
            MalteseMenuItem.Checked = currentLanguage == "mt";
            BurmeseMenuItem.Checked = currentLanguage == "my";
            NorwegianBokmalMenuItem.Checked = currentLanguage == "nb";
            NepaliMenuItem.Checked = currentLanguage == "ne";
            DutchMenuItem.Checked = currentLanguage == "nl";
            NorwegianNynorskMenuItem.Checked = currentLanguage == "nn";
            SesothoSaLeboaMenuItem.Checked = currentLanguage == "nso";
            OdiaMenuItem.Checked = currentLanguage == "or";
            PunjabiMenuItem.Checked = currentLanguage == "pa";
            PolishMenuItem.Checked = currentLanguage == "pl";
            PashtoMenuItem.Checked = currentLanguage == "ps";
            PortugueseMenuItem.Checked = currentLanguage == "pt";
            QuechuaMenuItem.Checked = currentLanguage == "quz";
            RomanianMenuItem.Checked = currentLanguage == "ro";
            RussianMenuItem.Checked = currentLanguage == "ru";
            KinyarwandaMenuItem.Checked = currentLanguage == "rw";
            SinhalaMenuItem.Checked = currentLanguage == "si";
            SlovakMenuItem.Checked = currentLanguage == "sk";
            SlovenianMenuItem.Checked = currentLanguage == "sl";
            AlbanianMenuItem.Checked = currentLanguage == "sq";
            SerbianMenuItem.Checked = currentLanguage == "sr";
            SwedishMenuItem.Checked = currentLanguage == "sv";
            SwahiliMenuItem.Checked = currentLanguage == "sw";
            TamilMenuItem.Checked = currentLanguage == "ta";
            TeluguMenuItem.Checked = currentLanguage == "te";
            TajikMenuItem.Checked = currentLanguage == "tg";
            ThaiMenuItem.Checked = currentLanguage == "th";
            TurkmenMenuItem.Checked = currentLanguage == "tk";
            SetswanaMenuItem.Checked = currentLanguage == "tn";
            TurkishMenuItem.Checked = currentLanguage == "tr";
            TatarMenuItem.Checked = currentLanguage == "tt";
            UyghurMenuItem.Checked = currentLanguage == "ug";
            UkrainianMenuItem.Checked = currentLanguage == "uk";
            UrduMenuItem.Checked = currentLanguage == "ur";
            UzbekMenuItem.Checked = currentLanguage == "uz";
            VietnameseMenuItem.Checked = currentLanguage == "vi";
            WolofMenuItem.Checked = currentLanguage == "wo";
            XhosaMenuItem.Checked = currentLanguage == "xh";
            YorubaMenuItem.Checked = currentLanguage == "yo";
            ChineseSimplifiedMenuItem.Checked = currentLanguage == "zh-CHS";
            ChineseTraditionalMenuItem.Checked = currentLanguage == "zh-CHT";
            ZuluMenuItem.Checked = currentLanguage == "zu";




            SaveLanguageSetting(currentLanguage);
        }



        private void AfrikaansMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "af";
            btn_lang.Text = "AF";
            CultureInfo.CurrentCulture = new CultureInfo("af");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void AmharicMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "am";
            btn_lang.Text = "AM";
            CultureInfo.CurrentCulture = new CultureInfo("am");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void ArabicMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "ar";
            btn_lang.Text = "AR";
            CultureInfo.CurrentCulture = new CultureInfo("ar");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void AssameseMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "as";
            btn_lang.Text = "AS";
            CultureInfo.CurrentCulture = new CultureInfo("as");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void AzerbaijaniMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "az";
            btn_lang.Text = "AZ";
            CultureInfo.CurrentCulture = new CultureInfo("az");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void BelarusianMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "be";
            btn_lang.Text = "BE";
            CultureInfo.CurrentCulture = new CultureInfo("be");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void BulgarianMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "bg";
            btn_lang.Text = "BG";
            CultureInfo.CurrentCulture = new CultureInfo("bg");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void BengaliMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "bn";
            btn_lang.Text = "BN";
            CultureInfo.CurrentCulture = new CultureInfo("bn");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void BosnianMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "bs";
            btn_lang.Text = "BS";
            CultureInfo.CurrentCulture = new CultureInfo("bs");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void CatalanMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "ca";
            btn_lang.Text = "CA";
            CultureInfo.CurrentCulture = new CultureInfo("ca");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void CzechMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "cs";
            btn_lang.Text = "CS";
            CultureInfo.CurrentCulture = new CultureInfo("cs");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void WelshMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "cy";
            btn_lang.Text = "CY";
            CultureInfo.CurrentCulture = new CultureInfo("cy");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void DanishMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "da";
            btn_lang.Text = "DA";
            CultureInfo.CurrentCulture = new CultureInfo("da");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void GermanMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "de";
            btn_lang.Text = "DE";
            CultureInfo.CurrentCulture = new CultureInfo("de");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void GreekMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "el";
            btn_lang.Text = "EL";
            CultureInfo.CurrentCulture = new CultureInfo("el");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void EnglishMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "en";
            btn_lang.Text = "EN";
            CultureInfo.CurrentCulture = new CultureInfo("en");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void SpanishMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "es";
            btn_lang.Text = "ES";
            CultureInfo.CurrentCulture = new CultureInfo("es");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void EstonianMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "et";
            btn_lang.Text = "ET";
            CultureInfo.CurrentCulture = new CultureInfo("et");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void BasqueMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "eu";
            btn_lang.Text = "EU";
            CultureInfo.CurrentCulture = new CultureInfo("eu");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void PersianMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "fa";
            btn_lang.Text = "FA";
            CultureInfo.CurrentCulture = new CultureInfo("fa");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void FinnishMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "fi";
            btn_lang.Text = "FI";
            CultureInfo.CurrentCulture = new CultureInfo("fi");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void FilipinoMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "fil";
            btn_lang.Text = "FIL";
            CultureInfo.CurrentCulture = new CultureInfo("fil");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void FrenchMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "fr";
            btn_lang.Text = "FR";
            CultureInfo.CurrentCulture = new CultureInfo("fr");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void IrishMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "ga";
            btn_lang.Text = "GA";
            CultureInfo.CurrentCulture = new CultureInfo("ga");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void ScottishGaelicMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "gd";
            btn_lang.Text = "GD";
            CultureInfo.CurrentCulture = new CultureInfo("gd");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void GalicianMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "gl";
            btn_lang.Text = "GL";
            CultureInfo.CurrentCulture = new CultureInfo("gl");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void GujaratiMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "gu";
            btn_lang.Text = "GU";
            CultureInfo.CurrentCulture = new CultureInfo("gu");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void HausaMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "ha";
            btn_lang.Text = "HA";
            CultureInfo.CurrentCulture = new CultureInfo("ha");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void HebrewMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "he";
            btn_lang.Text = "HE";
            CultureInfo.CurrentCulture = new CultureInfo("he");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void HindiMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "hi";
            btn_lang.Text = "HI";
            CultureInfo.CurrentCulture = new CultureInfo("hi");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void CroatianMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "hr";
            btn_lang.Text = "HR";
            CultureInfo.CurrentCulture = new CultureInfo("hr");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void HungarianMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "hu";
            btn_lang.Text = "HU";
            CultureInfo.CurrentCulture = new CultureInfo("hu");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void ArmenianMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "hy";
            btn_lang.Text = "HY";
            CultureInfo.CurrentCulture = new CultureInfo("hy");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void IndonesianMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "id";
            btn_lang.Text = "ID";
            CultureInfo.CurrentCulture = new CultureInfo("id");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void IgboMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "ig";
            btn_lang.Text = "IG";
            CultureInfo.CurrentCulture = new CultureInfo("ig");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void IcelandicMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "is";
            btn_lang.Text = "IS";
            CultureInfo.CurrentCulture = new CultureInfo("is");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void ItalianMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "it";
            btn_lang.Text = "IT";
            CultureInfo.CurrentCulture = new CultureInfo("it");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void JapaneseMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "ja";
            btn_lang.Text = "JA";
            CultureInfo.CurrentCulture = new CultureInfo("ja");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void GeorgianMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "ka";
            btn_lang.Text = "KA";
            CultureInfo.CurrentCulture = new CultureInfo("ka");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void KazakhMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "kk";
            btn_lang.Text = "KK";
            CultureInfo.CurrentCulture = new CultureInfo("kk");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void KhmerMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "km";
            btn_lang.Text = "KM";
            CultureInfo.CurrentCulture = new CultureInfo("km");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void KannadaMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "kn";
            btn_lang.Text = "KN";
            CultureInfo.CurrentCulture = new CultureInfo("kn");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void KoreanMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "ko";
            btn_lang.Text = "KO";
            CultureInfo.CurrentCulture = new CultureInfo("ko");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void KonkaniMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "kok";
            btn_lang.Text = "KOK";
            CultureInfo.CurrentCulture = new CultureInfo("kok");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void KurdishMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "ku";
            btn_lang.Text = "KU";
            CultureInfo.CurrentCulture = new CultureInfo("ku");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void KyrgyzMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "ky";
            btn_lang.Text = "KY";
            CultureInfo.CurrentCulture = new CultureInfo("ky");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void LuxembourgishMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "lb";
            btn_lang.Text = "LB";
            CultureInfo.CurrentCulture = new CultureInfo("lb");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void LaoMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "lo";
            btn_lang.Text = "LO";
            CultureInfo.CurrentCulture = new CultureInfo("lo");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void LithuanianMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "lt";
            btn_lang.Text = "LT";
            CultureInfo.CurrentCulture = new CultureInfo("lt");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void LatvianMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "lv";
            btn_lang.Text = "LV";
            CultureInfo.CurrentCulture = new CultureInfo("lv");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void MaoriMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "mi";
            btn_lang.Text = "MI";
            CultureInfo.CurrentCulture = new CultureInfo("mi");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void MacedonianMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "mk";
            btn_lang.Text = "MK";
            CultureInfo.CurrentCulture = new CultureInfo("mk");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void MalayalamMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "ml";
            btn_lang.Text = "ML";
            CultureInfo.CurrentCulture = new CultureInfo("ml");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void MongolianMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "mn";
            btn_lang.Text = "MN";
            CultureInfo.CurrentCulture = new CultureInfo("mn");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void MarathiMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "mr";
            btn_lang.Text = "MR";
            CultureInfo.CurrentCulture = new CultureInfo("mr");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void MalayMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "ms";
            btn_lang.Text = "MS";
            CultureInfo.CurrentCulture = new CultureInfo("ms");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void MalteseMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "mt";
            btn_lang.Text = "MT";
            CultureInfo.CurrentCulture = new CultureInfo("mt");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void BurmeseMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "my";
            btn_lang.Text = "MY";
            CultureInfo.CurrentCulture = new CultureInfo("my");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void NorwegianBokmalMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "nb";
            btn_lang.Text = "NB";
            CultureInfo.CurrentCulture = new CultureInfo("nb");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void NepaliMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "ne";
            btn_lang.Text = "NE";
            CultureInfo.CurrentCulture = new CultureInfo("ne");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void DutchMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "nl";
            btn_lang.Text = "NL";
            CultureInfo.CurrentCulture = new CultureInfo("nl");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void NorwegianNynorskMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "nn";
            btn_lang.Text = "NN";
            CultureInfo.CurrentCulture = new CultureInfo("nn");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void SesothoSaLeboaMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "nso";
            btn_lang.Text = "NSO";
            CultureInfo.CurrentCulture = new CultureInfo("nso");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void OdiaMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "or";
            btn_lang.Text = "OR";
            CultureInfo.CurrentCulture = new CultureInfo("or");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void PunjabiMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "pa";
            btn_lang.Text = "PA";
            CultureInfo.CurrentCulture = new CultureInfo("pa");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void PolishMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "pl";
            btn_lang.Text = "PL";
            CultureInfo.CurrentCulture = new CultureInfo("pl");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void PashtoMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "ps";
            btn_lang.Text = "PS";
            CultureInfo.CurrentCulture = new CultureInfo("ps");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void PortugueseMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "pt";
            btn_lang.Text = "PT";
            CultureInfo.CurrentCulture = new CultureInfo("pt");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void QuechuaMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "quz";
            btn_lang.Text = "QUZ";
            CultureInfo.CurrentCulture = new CultureInfo("quz");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void RomanianMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "ro";
            btn_lang.Text = "RO";
            CultureInfo.CurrentCulture = new CultureInfo("ro");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void RussianMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "ru";
            btn_lang.Text = "RU";
            CultureInfo.CurrentCulture = new CultureInfo("ru");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void KinyarwandaMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "rw";
            btn_lang.Text = "RW";
            CultureInfo.CurrentCulture = new CultureInfo("rw");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void SinhalaMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "si";
            btn_lang.Text = "SI";
            CultureInfo.CurrentCulture = new CultureInfo("si");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void SlovakMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "sk";
            btn_lang.Text = "SK";
            CultureInfo.CurrentCulture = new CultureInfo("sk");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void SlovenianMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "sl";
            btn_lang.Text = "SL";
            CultureInfo.CurrentCulture = new CultureInfo("sl");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void AlbanianMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "sq";
            btn_lang.Text = "SQ";
            CultureInfo.CurrentCulture = new CultureInfo("sq");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void SerbianMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "sr";
            btn_lang.Text = "SR";
            CultureInfo.CurrentCulture = new CultureInfo("sr");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void SwedishMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "sv";
            btn_lang.Text = "SV";
            CultureInfo.CurrentCulture = new CultureInfo("sv");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void SwahiliMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "sw";
            btn_lang.Text = "SW";
            CultureInfo.CurrentCulture = new CultureInfo("sw");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void TamilMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "ta";
            btn_lang.Text = "TA";
            CultureInfo.CurrentCulture = new CultureInfo("ta");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void TeluguMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "te";
            btn_lang.Text = "TE";
            CultureInfo.CurrentCulture = new CultureInfo("te");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void TajikMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "tg";
            btn_lang.Text = "TG";
            CultureInfo.CurrentCulture = new CultureInfo("tg");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void ThaiMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "th";
            btn_lang.Text = "TH";
            CultureInfo.CurrentCulture = new CultureInfo("th");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void TurkmenMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "tk";
            btn_lang.Text = "TK";
            CultureInfo.CurrentCulture = new CultureInfo("tk");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void SetswanaMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "tn";
            btn_lang.Text = "TN";
            CultureInfo.CurrentCulture = new CultureInfo("tn");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void TurkishMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "tr";
            btn_lang.Text = "TR";
            CultureInfo.CurrentCulture = new CultureInfo("tr");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void TatarMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "tt";
            btn_lang.Text = "TT";
            CultureInfo.CurrentCulture = new CultureInfo("tt");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void UyghurMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "ug";
            btn_lang.Text = "UG";
            CultureInfo.CurrentCulture = new CultureInfo("ug");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void UkrainianMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "uk";
            btn_lang.Text = "UK";
            CultureInfo.CurrentCulture = new CultureInfo("uk");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void UrduMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "ur";
            btn_lang.Text = "UR";
            CultureInfo.CurrentCulture = new CultureInfo("ur");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void UzbekMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "uz";
            btn_lang.Text = "UZ";
            CultureInfo.CurrentCulture = new CultureInfo("uz");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void VietnameseMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "vi";
            btn_lang.Text = "VI";
            CultureInfo.CurrentCulture = new CultureInfo("vi");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void WolofMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "wo";
            btn_lang.Text = "WO";
            CultureInfo.CurrentCulture = new CultureInfo("wo");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void XhosaMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "xh";
            btn_lang.Text = "XH";
            CultureInfo.CurrentCulture = new CultureInfo("xh");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void YorubaMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "yo";
            btn_lang.Text = "YO";
            CultureInfo.CurrentCulture = new CultureInfo("yo");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void ChineseSimplifiedMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "zh-CHS";
            btn_lang.Text = "zh-CHS";
            CultureInfo.CurrentCulture = new CultureInfo("zh-CHS");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void ChineseTraditionalMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "zh-CHT";
            btn_lang.Text = "zh-CHT";
            CultureInfo.CurrentCulture = new CultureInfo("zh-CHT");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void ZuluMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "zu";
            btn_lang.Text = "ZU";
            CultureInfo.CurrentCulture = new CultureInfo("zu");
            changeCase();
            UpdateLanguageMenuCheckState();
        }




        private void Chk_shift_CheckedChanged(object sender, EventArgs e)
        {
            changeCase();
        }



        private void Btn_lang_Click(object sender, EventArgs e)
        {
            langMenuStrip.Show(btn_lang, new System.Drawing.Point(0, btn_lang.Height));

            AfrikaansMenuItem.Click -= AfrikaansMenuItem_Click; AfrikaansMenuItem.Click += AfrikaansMenuItem_Click;
            AmharicMenuItem.Click -= AmharicMenuItem_Click; AmharicMenuItem.Click += AmharicMenuItem_Click;
            ArabicMenuItem.Click -= ArabicMenuItem_Click; ArabicMenuItem.Click += ArabicMenuItem_Click;
            AssameseMenuItem.Click -= AssameseMenuItem_Click; AssameseMenuItem.Click += AssameseMenuItem_Click;
            AzerbaijaniMenuItem.Click -= AzerbaijaniMenuItem_Click; AzerbaijaniMenuItem.Click += AzerbaijaniMenuItem_Click;
            BelarusianMenuItem.Click -= BelarusianMenuItem_Click; BelarusianMenuItem.Click += BelarusianMenuItem_Click;
            BulgarianMenuItem.Click -= BulgarianMenuItem_Click; BulgarianMenuItem.Click += BulgarianMenuItem_Click;
            BengaliMenuItem.Click -= BengaliMenuItem_Click; BengaliMenuItem.Click += BengaliMenuItem_Click;
            BosnianMenuItem.Click -= BosnianMenuItem_Click; BosnianMenuItem.Click += BosnianMenuItem_Click;
            CatalanMenuItem.Click -= CatalanMenuItem_Click; CatalanMenuItem.Click += CatalanMenuItem_Click;
            CzechMenuItem.Click -= CzechMenuItem_Click; CzechMenuItem.Click += CzechMenuItem_Click;
            WelshMenuItem.Click -= WelshMenuItem_Click; WelshMenuItem.Click += WelshMenuItem_Click;
            DanishMenuItem.Click -= DanishMenuItem_Click; DanishMenuItem.Click += DanishMenuItem_Click;
            GermanMenuItem.Click -= GermanMenuItem_Click; GermanMenuItem.Click += GermanMenuItem_Click;
            GreekMenuItem.Click -= GreekMenuItem_Click; GreekMenuItem.Click += GreekMenuItem_Click;
            EnglishMenuItem.Click -= EnglishMenuItem_Click; EnglishMenuItem.Click += EnglishMenuItem_Click;
            SpanishMenuItem.Click -= SpanishMenuItem_Click; SpanishMenuItem.Click += SpanishMenuItem_Click;
            EstonianMenuItem.Click -= EstonianMenuItem_Click; EstonianMenuItem.Click += EstonianMenuItem_Click;
            BasqueMenuItem.Click -= BasqueMenuItem_Click; BasqueMenuItem.Click += BasqueMenuItem_Click;
            PersianMenuItem.Click -= PersianMenuItem_Click; PersianMenuItem.Click += PersianMenuItem_Click;
            FinnishMenuItem.Click -= FinnishMenuItem_Click; FinnishMenuItem.Click += FinnishMenuItem_Click;
            FilipinoMenuItem.Click -= FilipinoMenuItem_Click; FilipinoMenuItem.Click += FilipinoMenuItem_Click;
            FrenchMenuItem.Click -= FrenchMenuItem_Click; FrenchMenuItem.Click += FrenchMenuItem_Click;
            IrishMenuItem.Click -= IrishMenuItem_Click; IrishMenuItem.Click += IrishMenuItem_Click;
            ScottishGaelicMenuItem.Click -= ScottishGaelicMenuItem_Click; ScottishGaelicMenuItem.Click += ScottishGaelicMenuItem_Click;
            GalicianMenuItem.Click -= GalicianMenuItem_Click; GalicianMenuItem.Click += GalicianMenuItem_Click;
            GujaratiMenuItem.Click -= GujaratiMenuItem_Click; GujaratiMenuItem.Click += GujaratiMenuItem_Click;
            HausaMenuItem.Click -= HausaMenuItem_Click; HausaMenuItem.Click += HausaMenuItem_Click;
            HebrewMenuItem.Click -= HebrewMenuItem_Click; HebrewMenuItem.Click += HebrewMenuItem_Click;
            HindiMenuItem.Click -= HindiMenuItem_Click; HindiMenuItem.Click += HindiMenuItem_Click;
            CroatianMenuItem.Click -= CroatianMenuItem_Click; CroatianMenuItem.Click += CroatianMenuItem_Click;
            HungarianMenuItem.Click -= HungarianMenuItem_Click; HungarianMenuItem.Click += HungarianMenuItem_Click;
            ArmenianMenuItem.Click -= ArmenianMenuItem_Click; ArmenianMenuItem.Click += ArmenianMenuItem_Click;
            IndonesianMenuItem.Click -= IndonesianMenuItem_Click; IndonesianMenuItem.Click += IndonesianMenuItem_Click;
            IgboMenuItem.Click -= IgboMenuItem_Click; IgboMenuItem.Click += IgboMenuItem_Click;
            IcelandicMenuItem.Click -= IcelandicMenuItem_Click; IcelandicMenuItem.Click += IcelandicMenuItem_Click;
            ItalianMenuItem.Click -= ItalianMenuItem_Click; ItalianMenuItem.Click += ItalianMenuItem_Click;
            JapaneseMenuItem.Click -= JapaneseMenuItem_Click; JapaneseMenuItem.Click += JapaneseMenuItem_Click;
            GeorgianMenuItem.Click -= GeorgianMenuItem_Click; GeorgianMenuItem.Click += GeorgianMenuItem_Click;
            KazakhMenuItem.Click -= KazakhMenuItem_Click; KazakhMenuItem.Click += KazakhMenuItem_Click;
            KhmerMenuItem.Click -= KhmerMenuItem_Click; KhmerMenuItem.Click += KhmerMenuItem_Click;
            KannadaMenuItem.Click -= KannadaMenuItem_Click; KannadaMenuItem.Click += KannadaMenuItem_Click;
            KoreanMenuItem.Click -= KoreanMenuItem_Click; KoreanMenuItem.Click += KoreanMenuItem_Click;
            KonkaniMenuItem.Click -= KonkaniMenuItem_Click; KonkaniMenuItem.Click += KonkaniMenuItem_Click;
            KurdishMenuItem.Click -= KurdishMenuItem_Click; KurdishMenuItem.Click += KurdishMenuItem_Click;
            KyrgyzMenuItem.Click -= KyrgyzMenuItem_Click; KyrgyzMenuItem.Click += KyrgyzMenuItem_Click;
            LuxembourgishMenuItem.Click -= LuxembourgishMenuItem_Click; LuxembourgishMenuItem.Click += LuxembourgishMenuItem_Click;
            LaoMenuItem.Click -= LaoMenuItem_Click; LaoMenuItem.Click += LaoMenuItem_Click;
            LithuanianMenuItem.Click -= LithuanianMenuItem_Click; LithuanianMenuItem.Click += LithuanianMenuItem_Click;
            LatvianMenuItem.Click -= LatvianMenuItem_Click; LatvianMenuItem.Click += LatvianMenuItem_Click;
            MaoriMenuItem.Click -= MaoriMenuItem_Click; MaoriMenuItem.Click += MaoriMenuItem_Click;
            MacedonianMenuItem.Click -= MacedonianMenuItem_Click; MacedonianMenuItem.Click += MacedonianMenuItem_Click;
            MalayalamMenuItem.Click -= MalayalamMenuItem_Click; MalayalamMenuItem.Click += MalayalamMenuItem_Click;
            MongolianMenuItem.Click -= MongolianMenuItem_Click; MongolianMenuItem.Click += MongolianMenuItem_Click;
            MarathiMenuItem.Click -= MarathiMenuItem_Click; MarathiMenuItem.Click += MarathiMenuItem_Click;
            MalayMenuItem.Click -= MalayMenuItem_Click; MalayMenuItem.Click += MalayMenuItem_Click;
            MalteseMenuItem.Click -= MalteseMenuItem_Click; MalteseMenuItem.Click += MalteseMenuItem_Click;
            BurmeseMenuItem.Click -= BurmeseMenuItem_Click; BurmeseMenuItem.Click += BurmeseMenuItem_Click;
            NorwegianBokmalMenuItem.Click -= NorwegianBokmalMenuItem_Click; NorwegianBokmalMenuItem.Click += NorwegianBokmalMenuItem_Click;
            NepaliMenuItem.Click -= NepaliMenuItem_Click; NepaliMenuItem.Click += NepaliMenuItem_Click;
            DutchMenuItem.Click -= DutchMenuItem_Click; DutchMenuItem.Click += DutchMenuItem_Click;
            NorwegianNynorskMenuItem.Click -= NorwegianNynorskMenuItem_Click; NorwegianNynorskMenuItem.Click += NorwegianNynorskMenuItem_Click;
            SesothoSaLeboaMenuItem.Click -= SesothoSaLeboaMenuItem_Click; SesothoSaLeboaMenuItem.Click += SesothoSaLeboaMenuItem_Click;
            OdiaMenuItem.Click -= OdiaMenuItem_Click; OdiaMenuItem.Click += OdiaMenuItem_Click;
            PunjabiMenuItem.Click -= PunjabiMenuItem_Click; PunjabiMenuItem.Click += PunjabiMenuItem_Click;
            PolishMenuItem.Click -= PolishMenuItem_Click; PolishMenuItem.Click += PolishMenuItem_Click;
            PashtoMenuItem.Click -= PashtoMenuItem_Click; PashtoMenuItem.Click += PashtoMenuItem_Click;
            PortugueseMenuItem.Click -= PortugueseMenuItem_Click; PortugueseMenuItem.Click += PortugueseMenuItem_Click;
            QuechuaMenuItem.Click -= QuechuaMenuItem_Click; QuechuaMenuItem.Click += QuechuaMenuItem_Click;
            RomanianMenuItem.Click -= RomanianMenuItem_Click; RomanianMenuItem.Click += RomanianMenuItem_Click;
            RussianMenuItem.Click -= RussianMenuItem_Click; RussianMenuItem.Click += RussianMenuItem_Click;
            KinyarwandaMenuItem.Click -= KinyarwandaMenuItem_Click; KinyarwandaMenuItem.Click += KinyarwandaMenuItem_Click;
            SinhalaMenuItem.Click -= SinhalaMenuItem_Click; SinhalaMenuItem.Click += SinhalaMenuItem_Click;
            SlovakMenuItem.Click -= SlovakMenuItem_Click; SlovakMenuItem.Click += SlovakMenuItem_Click;
            SlovenianMenuItem.Click -= SlovenianMenuItem_Click; SlovenianMenuItem.Click += SlovenianMenuItem_Click;
            AlbanianMenuItem.Click -= AlbanianMenuItem_Click; AlbanianMenuItem.Click += AlbanianMenuItem_Click;
            SerbianMenuItem.Click -= SerbianMenuItem_Click; SerbianMenuItem.Click += SerbianMenuItem_Click;
            SwedishMenuItem.Click -= SwedishMenuItem_Click; SwedishMenuItem.Click += SwedishMenuItem_Click;
            SwahiliMenuItem.Click -= SwahiliMenuItem_Click; SwahiliMenuItem.Click += SwahiliMenuItem_Click;
            TamilMenuItem.Click -= TamilMenuItem_Click; TamilMenuItem.Click += TamilMenuItem_Click;
            TeluguMenuItem.Click -= TeluguMenuItem_Click; TeluguMenuItem.Click += TeluguMenuItem_Click;
            TajikMenuItem.Click -= TajikMenuItem_Click; TajikMenuItem.Click += TajikMenuItem_Click;
            ThaiMenuItem.Click -= ThaiMenuItem_Click; ThaiMenuItem.Click += ThaiMenuItem_Click;
            TurkmenMenuItem.Click -= TurkmenMenuItem_Click; TurkmenMenuItem.Click += TurkmenMenuItem_Click;
            SetswanaMenuItem.Click -= SetswanaMenuItem_Click; SetswanaMenuItem.Click += SetswanaMenuItem_Click;
            TurkishMenuItem.Click -= TurkishMenuItem_Click; TurkishMenuItem.Click += TurkishMenuItem_Click;
            TatarMenuItem.Click -= TatarMenuItem_Click; TatarMenuItem.Click += TatarMenuItem_Click;
            UyghurMenuItem.Click -= UyghurMenuItem_Click; UyghurMenuItem.Click += UyghurMenuItem_Click;
            UkrainianMenuItem.Click -= UkrainianMenuItem_Click; UkrainianMenuItem.Click += UkrainianMenuItem_Click;
            UrduMenuItem.Click -= UrduMenuItem_Click; UrduMenuItem.Click += UrduMenuItem_Click;
            UzbekMenuItem.Click -= UzbekMenuItem_Click; UzbekMenuItem.Click += UzbekMenuItem_Click;
            VietnameseMenuItem.Click -= VietnameseMenuItem_Click; VietnameseMenuItem.Click += VietnameseMenuItem_Click;
            WolofMenuItem.Click -= WolofMenuItem_Click; WolofMenuItem.Click += WolofMenuItem_Click;
            XhosaMenuItem.Click -= XhosaMenuItem_Click; XhosaMenuItem.Click += XhosaMenuItem_Click;
            YorubaMenuItem.Click -= YorubaMenuItem_Click; YorubaMenuItem.Click += YorubaMenuItem_Click;
            ChineseSimplifiedMenuItem.Click -= ChineseSimplifiedMenuItem_Click; ChineseSimplifiedMenuItem.Click += ChineseSimplifiedMenuItem_Click;
            ChineseTraditionalMenuItem.Click -= ChineseTraditionalMenuItem_Click; ChineseTraditionalMenuItem.Click += ChineseTraditionalMenuItem_Click;
            ZuluMenuItem.Click -= ZuluMenuItem_Click; ZuluMenuItem.Click += ZuluMenuItem_Click;


            UpdateLanguageMenuCheckState();
        }



        private void UpdateButtonFont(string language)
        {
            Font newFont;

            // 提取基礎語言代碼（去除地區代碼，例如 "zh-CN" -> "zh"）
            string baseLanguage = language.Split('-')[0];

            switch (baseLanguage)
            {
                // 東亞語言
                case "ja": // 日文
                    newFont = FontExists("Meiryo") ? new Font("Meiryo", 24F, FontStyle.Bold)
                                                  : new Font("Segoe UI", 24F, FontStyle.Bold);
                    break;
                case "ko": // 韓文
                    newFont = FontExists("Malgun Gothic") ? new Font("Malgun Gothic", 24F, FontStyle.Bold)
                                                         : new Font("Segoe UI", 24F, FontStyle.Bold);
                    break;
                case "zh-CHS": // 中文（簡體/繁體）
                case "zh-CHT": // 中文（簡體/繁體）
                    if (language == "zh-CHS") // 簡體中文
                    {
                        newFont = FontExists("Microsoft YaHei") ? new Font("Microsoft YaHei", 24F, FontStyle.Bold)
                                                               : new Font("Segoe UI", 24F, FontStyle.Bold);
                    }
                    else if (language == "zh-CHT") // 繁體中文
                    {
                        newFont = FontExists("Microsoft JhengHei") ? new Font("Microsoft JhengHei", 24F, FontStyle.Bold)
                                                                   : new Font("Segoe UI", 24F, FontStyle.Bold);
                    }
                    else // 其他中文變體
                    {
                        newFont = new Font("Segoe UI", 24F, FontStyle.Bold);
                    }
                    break;

                // 中東和南亞語言
                case "ar": // 阿拉伯文
                case "fa": // 波斯文
                case "ur": // 烏爾都文
                    newFont = new Font("Segoe UI", 24F, FontStyle.Bold); // 使用系統默認支持的字體
                    break;
                case "he": // 希伯來文
                    newFont = FontExists("Levenim MT") ? new Font("Levenim MT", 24F, FontStyle.Bold)
                                                      : new Font("Segoe UI", 24F, FontStyle.Bold);
                    break;
                case "hi": // 印地文
                case "ta": // 泰米爾文
                case "te": // 泰盧固文
                case "kn": // 卡納達文
                case "ml": // 馬拉雅拉姆文
                    newFont = FontExists("Nirmala UI") ? new Font("Nirmala UI", 24F, FontStyle.Bold)
                                                      : new Font("Segoe UI", 24F, FontStyle.Bold);
                    break;

                // 歐洲語言（西里爾字母）
                case "ru": // 俄文
                case "uk": // 烏克蘭文
                case "sr": // 塞爾維亞文
                case "bg": // 保加利亞文
                    newFont = new Font("Segoe UI", 24F, FontStyle.Bold); // Segoe UI 支持西里爾字母
                    break;

                // 預設情況（拉丁字母語言，如英文、法文、德文等）
                default:
                    newFont = FontExists("Segoe UI") ? new Font("Segoe UI", 24F, FontStyle.Bold)
                                                   : new Font("Arial", 24F, FontStyle.Bold);
                    break;
            }

            // 更新所有按鈕的字型
            foreach (Control control in tableLayoutPanel.Controls)
            {
                if (control is Button btn)
                {
                    btn.Font = newFont;
                    btn.UseMnemonic = false; // 禁用助記符（避免字體問題）
                }
            }
        }

        // 檢查字型是否存在的輔助方法
        private bool FontExists(string fontName)
        {
            return FontFamily.Families.Any(f => f.Name == fontName);
        }



        private void SendChar(Button senderb)
        {
            Button btn = (Button)senderb;
            RaiseButtonPressed(btn.Text[0]);
            //if (chk_shift.Checked) chk_shift.Checked = false;
        }
        private void BtnClick(object sender, EventArgs e)
        {
            SendChar((Button)sender);
        }



        private void changeCase()
        {
            // Update font and visibility based on current culture
            UpdateButtonFont(CultureInfo.CurrentCulture.Name);
            UpdateButtonVisibility(CultureInfo.CurrentCulture.Name);

            switch (CultureInfo.CurrentCulture.Name)
            {



                case "en": // English (United States)
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = ":"; c12.Text = "\""; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = ";"; c12.Text = "'"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;



                case "vi": // Vietnamese
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Ă"; c12.Text = "Â"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = "Đ"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "ă"; c12.Text = "â"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = "đ"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;



                case "de": // German
                    if (chk_shift.Checked)
                    {
                        a1.Text = "^"; a2.Text = "!"; a3.Text = "\""; a4.Text = "§"; a5.Text = "$"; a6.Text = "%"; a7.Text = "&"; a8.Text = "/"; a9.Text = "("; a10.Text = ")"; a11.Text = "="; a12.Text = "?"; a13.Text = "`";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Z"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "Ü"; b13.Text = "*"; b14.Text = "";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Ö"; c12.Text = "Ä"; c13.Text = "#"; c14.Text = "Enter";
                        d1.Text = "Shift"; d2.Text = "<"; d3.Text = "Y"; d4.Text = "X"; d5.Text = "C"; d6.Text = "V"; d7.Text = "B"; d8.Text = "N"; d9.Text = "M"; d10.Text = ","; d11.Text = "."; d12.Text = "-"; d13.Text = "Shift"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "°"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "ß"; a13.Text = "´";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "z"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "ü"; b13.Text = "+"; b14.Text = "";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "ö"; c12.Text = "ä"; c13.Text = "'"; c14.Text = "Enter";
                        d1.Text = "Shift"; d2.Text = ">"; d3.Text = "y"; d4.Text = "x"; d5.Text = "c"; d6.Text = "v"; d7.Text = "b"; d8.Text = "n"; d9.Text = "m"; d10.Text = ","; d11.Text = "."; d12.Text = "-"; d13.Text = "Shift"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;



                case "ar": // Arabic (Saudi Arabia)
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = ")"; a11.Text = "("; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "ض"; b3.Text = "ص"; b4.Text = "ث"; b5.Text = "ق"; b6.Text = "ف"; b7.Text = "غ"; b8.Text = "ع"; b9.Text = "ه"; b10.Text = "خ"; b11.Text = "ح"; b12.Text = "}"; b13.Text = "{"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "ش"; c3.Text = "س"; c4.Text = "ي"; c5.Text = "ب"; c6.Text = "ل"; c7.Text = "ا"; c8.Text = "ت"; c9.Text = "ن"; c10.Text = "م"; c11.Text = "ك"; c12.Text = ">"; c13.Text = "<"; c14.Text = "Enter";
                        d1.Text = "Shift"; d2.Text = "Shift"; d3.Text = "ظ"; d4.Text = "ط"; d5.Text = "ذ"; d10.Text = "Enter"; d6.Text = "ز"; d7.Text = "ر"; d8.Text = "و"; d9.Text = "ة"; d11.Text = "ى"; d12.Text = "لا"; d13.Text = "?"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "١"; a3.Text = "٢"; a4.Text = "٣"; a5.Text = "٤"; a6.Text = "٥"; a7.Text = "٦"; a8.Text = "٧"; a9.Text = "٨"; a10.Text = "٩"; a11.Text = "٠"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "ض"; b3.Text = "ص"; b4.Text = "ث"; b5.Text = "ق"; b6.Text = "ف"; b7.Text = "غ"; b8.Text = "ع"; b9.Text = "ه"; b10.Text = "خ"; b11.Text = "ح"; b12.Text = "]"; b13.Text = "["; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "ش"; c3.Text = "س"; c4.Text = "ي"; c5.Text = "ب"; c6.Text = "ل"; c7.Text = "ا"; c8.Text = "ت"; c9.Text = "ن"; c10.Text = "م"; c11.Text = "ك"; c12.Text = "ط"; c13.Text = "'"; c14.Text = "Enter";
                        d1.Text = "Shift"; d2.Text = "ظ"; d3.Text = "ط"; d4.Text = "ذ"; d5.Text = "د"; d6.Text = "ز"; d7.Text = "ر"; d8.Text = "و"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;



                case "zh-CHS": // Chinese (Simplified, Pinyin input assumed with QWERTY base)
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = ":"; c12.Text = "\""; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = ";"; c12.Text = "'"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;

                case "fr": // French (France, AZERTY layout)
                    if (chk_shift.Checked)
                    {
                        a1.Text = "²"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "°"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "A"; b3.Text = "Z"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "^"; b13.Text = "$"; b14.Text = "";
                        c1.Text = "Caps"; c2.Text = "Q"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "M"; c12.Text = "Ù"; c13.Text = "*"; c14.Text = "Enter";
                        d1.Text = "Shift"; d2.Text = ">"; d3.Text = "W"; d4.Text = "X"; d5.Text = "C"; d6.Text = "V"; d7.Text = "B"; d8.Text = "N"; d9.Text = "?"; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "²"; a2.Text = "&"; a3.Text = "é"; a4.Text = "\""; a5.Text = "'"; a6.Text = "("; a7.Text = "-"; a8.Text = "è"; a9.Text = "_"; a10.Text = "ç"; a11.Text = "à"; a12.Text = ")"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "a"; b3.Text = "z"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "^"; b13.Text = "$"; b14.Text = "";
                        c1.Text = "Caps"; c2.Text = "q"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "m"; c12.Text = "ù"; c13.Text = "*"; c14.Text = "Enter";
                        d1.Text = "Shift"; d2.Text = "<"; d3.Text = "w"; d4.Text = "x"; d5.Text = "c"; d6.Text = "v"; d7.Text = "b"; d8.Text = "n"; d9.Text = ","; d10.Text = ";"; d11.Text = ":"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;

                case "ru": // Russian
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Й"; b3.Text = "Ц"; b4.Text = "У"; b5.Text = "К"; b6.Text = "Е"; b7.Text = "Н"; b8.Text = "Г"; b9.Text = "Ш"; b10.Text = "Щ"; b11.Text = "З"; b12.Text = "Х"; b13.Text = "Ъ"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "Ф"; c3.Text = "Ы"; c4.Text = "В"; c5.Text = "А"; c6.Text = "П"; c7.Text = "Р"; c8.Text = "О"; c9.Text = "Л"; c10.Text = "Д"; c11.Text = "Ж"; c12.Text = "Э"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "Я"; d3.Text = "Ч"; d4.Text = "С"; d5.Text = "М"; d6.Text = "И"; d7.Text = "Т"; d8.Text = "Ь"; d9.Text = "Б"; d10.Text = "Ю"; d11.Text = ","; d12.Text = "Shift"; d13.Text = "?"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "й"; b3.Text = "ц"; b4.Text = "у"; b5.Text = "к"; b6.Text = "е"; b7.Text = "н"; b8.Text = "г"; b9.Text = "ш"; b10.Text = "щ"; b11.Text = "з"; b12.Text = "х"; b13.Text = "ъ"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "ф"; c3.Text = "ы"; c4.Text = "в"; c5.Text = "а"; c6.Text = "п"; c7.Text = "р"; c8.Text = "о"; c9.Text = "л"; c10.Text = "д"; c11.Text = "ж"; c12.Text = "э"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "я"; d3.Text = "ч"; d4.Text = "с"; d5.Text = "м"; d6.Text = "и"; d7.Text = "т"; d8.Text = "ь"; d9.Text = "б"; d10.Text = "ю"; d11.Text = "."; d12.Text = "Shift"; d13.Text = "/"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;

                case "ja": // Japanese (Romaji input assumed with QWERTY base)
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = ":"; c12.Text = "\""; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = ";"; c12.Text = "'"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;

                case "es": // Spanish (Spain)
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Ñ"; c12.Text = "\""; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "ñ"; c12.Text = "'"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;



                case "it": // Italian
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "È"; b13.Text = "+"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Ò"; c12.Text = "À"; c13.Text = "Ù"; c14.Text = "Enter";
                        d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "\\"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "è"; b13.Text = "é"; b14.Text = "]";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "ò"; c12.Text = "à"; c13.Text = "ù"; c14.Text = "Enter";
                        d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;



                case "ko": // Korean (Hangul input assumed with QWERTY base)
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "ㅃ"; b3.Text = "ㅉ"; b4.Text = "ㄸ"; b5.Text = "ㄲ"; b6.Text = "ㅆ"; b7.Text = "ㅛ"; b8.Text = "ㅕ"; b9.Text = "ㅑ"; b10.Text = "ㅐ"; b11.Text = "ㅔ"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "ㅁ"; c3.Text = "ㄴ"; c4.Text = "ㅇ"; c5.Text = "ㄹ"; c6.Text = "ㅎ"; c7.Text = "ㅗ"; c8.Text = "ㅓ"; c9.Text = "ㅏ"; c10.Text = "ㅣ"; c11.Text = ":"; c12.Text = "\""; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ㅋ"; d3.Text = "ㅌ"; d4.Text = "ㅊ"; d5.Text = "ㅍ"; d6.Text = "ㅠ"; d7.Text = "ㅜ"; d8.Text = "ㅡ"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "ㅂ"; b3.Text = "ㅈ"; b4.Text = "ㄷ"; b5.Text = "ㄱ"; b6.Text = "ㅅ"; b7.Text = "ㅛ"; b8.Text = "ㅕ"; b9.Text = "ㅑ"; b10.Text = "ㅐ"; b11.Text = "ㅔ"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "ㅁ"; c3.Text = "ㄴ"; c4.Text = "ㅇ"; c5.Text = "ㄹ"; c6.Text = "ㅎ"; c7.Text = "ㅗ"; c8.Text = "ㅓ"; c9.Text = "ㅏ"; c10.Text = "ㅣ"; c11.Text = ";"; c12.Text = "'"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ㅋ"; d3.Text = "ㅌ"; d4.Text = "ㅊ"; d5.Text = "ㅍ"; d6.Text = "ㅠ"; d7.Text = "ㅜ"; d8.Text = "ㅡ"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;



                case "pt": // Portuguese (Portugal)
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Ç"; c12.Text = "º"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "\\"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "'";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "ç"; c12.Text = "ª"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;




                case "pl": // Polish
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Z"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Ł"; c12.Text = "\""; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "Y"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "z"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "ł"; c12.Text = "'"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "y"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;



                case "tr": // Turkish (Turkish Q Keyboard)
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "\""; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "&"; a8.Text = "'"; a9.Text = "("; a10.Text = ")"; a11.Text = "*"; a12.Text = "-"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "Ğ"; b13.Text = "Ü"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Ş"; c12.Text = "İ"; c13.Text = ","; c14.Text = "Enter";
                        d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "Ö"; d10.Text = "Ç"; d11.Text = "."; d12.Text = "Shift"; d13.Text = "?"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "*"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "ı"; b10.Text = "o"; b11.Text = "p"; b12.Text = "ğ"; b13.Text = "ü"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "ş"; c12.Text = "i"; c13.Text = ","; c14.Text = "Enter";
                        d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = "ö"; d10.Text = "ç"; d11.Text = "."; d12.Text = "Shift"; d13.Text = "/"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;



                case "th": // Thai (Kedmanee Layout)
                    if (chk_shift.Checked)
                    {
                        a1.Text = "%"; a2.Text = "+"; a3.Text = "๑"; a4.Text = "๒"; a5.Text = "๓"; a6.Text = "๔"; a7.Text = "๕"; a8.Text = "๖"; a9.Text = "๗"; a10.Text = "๘"; a11.Text = "๙"; a12.Text = "๐"; a13.Text = "\"";
                        b1.Text = "Tab"; b2.Text = "๏"; b3.Text = "๛"; b4.Text = "ฃ"; b5.Text = "ฅ"; b6.Text = "ณ"; b7.Text = "ฎ"; b8.Text = "ฏ"; b9.Text = "โ"; b10.Text = "ฌ"; b11.Text = "ษ"; b12.Text = "ศ"; b13.Text = "ซ"; b14.Text = "(";
                        c1.Text = "Caps"; c2.Text = "ฟ"; c3.Text = "ห"; c4.Text = "ก"; c5.Text = "ด"; c6.Text = "เ"; c7.Text = "้"; c8.Text = "่"; c9.Text = "า"; c10.Text = "ส"; c11.Text = "ว"; c12.Text = "ง"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ผ"; d3.Text = "ป"; d4.Text = "แ"; d5.Text = "อ"; d6.Text = "ิ"; d7.Text = "ี"; d8.Text = "ร"; d9.Text = "น"; d10.Text = "ย"; d11.Text = "บ"; d12.Text = "Shift"; d13.Text = "ล"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "_"; a2.Text = "ๅ"; a3.Text = "/"; a4.Text = "-"; a5.Text = "ภ"; a6.Text = "ถ"; a7.Text = "ุ"; a8.Text = "ึ"; a9.Text = "ค"; a10.Text = "ต"; a11.Text = "จ"; a12.Text = "ข"; a13.Text = "ช";
                        b1.Text = "Tab"; b2.Text = "ๆ"; b3.Text = "ไ"; b4.Text = "ำ"; b5.Text = "พ"; b6.Text = "ะ"; b7.Text = "ั"; b8.Text = "ี"; b9.Text = "ร"; b10.Text = "น"; b11.Text = "ย"; b12.Text = "บ"; b13.Text = "ล"; b14.Text = ")";
                        c1.Text = "Caps"; c2.Text = "ฟ"; c3.Text = "ห"; c4.Text = "ก"; c5.Text = "ด"; c6.Text = "เ"; c7.Text = "้"; c8.Text = "่"; c9.Text = "า"; c10.Text = "ส"; c11.Text = "ว"; c12.Text = "ง"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ผ"; d3.Text = "ป"; d4.Text = "แ"; d5.Text = "อ"; d6.Text = "ิ"; d7.Text = "ื"; d8.Text = "ท"; d9.Text = "ม"; d10.Text = "ใ"; d11.Text = "ฝ"; d12.Text = "Shift"; d13.Text = "."; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;



                case "hi": // Hindi (Devanagari - InScript Layout)
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "१"; a3.Text = "२"; a4.Text = "३"; a5.Text = "४"; a6.Text = "५"; a7.Text = "६"; a8.Text = "७"; a9.Text = "८"; a10.Text = "९"; a11.Text = "०"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "औ"; b3.Text = "ऐ"; b4.Text = "आ"; b5.Text = "ई"; b6.Text = "ऊ"; b7.Text = "भ"; b8.Text = "ङ"; b9.Text = "घ"; b10.Text = "ध"; b11.Text = "झ"; b12.Text = "ढ"; b13.Text = "ञ"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "ओ"; c3.Text = "ए"; c4.Text = "अ"; c5.Text = "इ"; c6.Text = "उ"; c7.Text = "फ"; c8.Text = "ऱ"; c9.Text = "ख"; c10.Text = "थ"; c11.Text = "छ"; c12.Text = "ठ"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ऍ"; d3.Text = "ँ"; d4.Text = "ं"; d5.Text = "म"; d6.Text = "न"; d7.Text = "ण"; d8.Text = "व"; d9.Text = "ल"; d10.Text = "स"; d11.Text = "श"; d12.Text = "Shift"; d13.Text = "ष"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "ौ"; b3.Text = "ै"; b4.Text = "ा"; b5.Text = "ी"; b6.Text = "ू"; b7.Text = "ब"; b8.Text = "ह"; b9.Text = "ग"; b10.Text = "द"; b11.Text = "ज"; b12.Text = "ड"; b13.Text = "़"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "ो"; c3.Text = "े"; c4.Text = "्"; c5.Text = "ि"; c6.Text = "ु"; c7.Text = "प"; c8.Text = "र"; c9.Text = "क"; c10.Text = "त"; c11.Text = "च"; c12.Text = "ट"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ॅ"; d3.Text = "ं"; d4.Text = "म"; d5.Text = "न"; d6.Text = "्"; d7.Text = "व"; d8.Text = "ल"; d9.Text = "स"; d10.Text = ","; d11.Text = "."; d12.Text = "Shift"; d13.Text = "य"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;





                case "nl": // Dutch (Netherlands)
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = ":"; c12.Text = "\""; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = ";"; c12.Text = "'"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;

                case "sv": // Swedish
                    if (chk_shift.Checked)
                    {
                        a1.Text = "§"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "Å"; b13.Text = "¨"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Ö"; c12.Text = "Ä"; c13.Text = "'"; c14.Text = "Enter";
                        d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "½"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "+"; a13.Text = "´";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "å"; b13.Text = "^"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "ö"; c12.Text = "ä"; c13.Text = "´"; c14.Text = "Enter";
                        d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "-"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;

                case "uk": // Ukrainian
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Й"; b3.Text = "Ц"; b4.Text = "У"; b5.Text = "К"; b6.Text = "Е"; b7.Text = "Н"; b8.Text = "Г"; b9.Text = "Ш"; b10.Text = "Щ"; b11.Text = "З"; b12.Text = "Х"; b13.Text = "Ї"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "Ф"; c3.Text = "І"; c4.Text = "В"; c5.Text = "А"; c6.Text = "П"; c7.Text = "Р"; c8.Text = "О"; c9.Text = "Л"; c10.Text = "Д"; c11.Text = "Ж"; c12.Text = "Є"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "Я"; d3.Text = "Ч"; d4.Text = "С"; d5.Text = "М"; d6.Text = "И"; d7.Text = "Т"; d8.Text = "Ь"; d9.Text = "Б"; d10.Text = "Ю"; d11.Text = ","; d12.Text = "Shift"; d13.Text = "?"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "й"; b3.Text = "ц"; b4.Text = "у"; b5.Text = "к"; b6.Text = "е"; b7.Text = "н"; b8.Text = "г"; b9.Text = "ш"; b10.Text = "щ"; b11.Text = "з"; b12.Text = "х"; b13.Text = "ї"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "ф"; c3.Text = "і"; c4.Text = "в"; c5.Text = "а"; c6.Text = "п"; c7.Text = "р"; c8.Text = "о"; c9.Text = "л"; c10.Text = "д"; c11.Text = "ж"; c12.Text = "є"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "я"; d3.Text = "ч"; d4.Text = "с"; d5.Text = "м"; d6.Text = "и"; d7.Text = "т"; d8.Text = "ь"; d9.Text = "б"; d10.Text = "ю"; d11.Text = "."; d12.Text = "Shift"; d13.Text = "/"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;

                case "el": // Greek
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = ":"; c12.Text = "\""; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = ";"; b3.Text = "ς"; b4.Text = "ε"; b5.Text = "ρ"; b6.Text = "τ"; b7.Text = "υ"; b8.Text = "θ"; b9.Text = "ι"; b10.Text = "ο"; b11.Text = "π"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "α"; c3.Text = "σ"; c4.Text = "δ"; c5.Text = "φ"; c6.Text = "γ"; c7.Text = "η"; c8.Text = "ξ"; c9.Text = "κ"; c10.Text = "λ"; c11.Text = "΄"; c12.Text = "'"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ζ"; d3.Text = "χ"; d4.Text = "ψ"; d5.Text = "ω"; d6.Text = "β"; d7.Text = "ν"; d8.Text = "μ"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;



                case "cs": // Czech
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Z"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "Ú"; b13.Text = ")"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Ů"; c12.Text = "¨"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "Y"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = ";"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "+"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "z"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "ú"; b13.Text = "("; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "ů"; c12.Text = "ˇ"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "y"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "-"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;

                case "hu": // Hungarian
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Z"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "Ő"; b13.Text = "Ú"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "É"; c12.Text = "Á"; c13.Text = "Ü"; c14.Text = "Enter";
                        d1.Text = "Shift"; d2.Text = "Y"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "0"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "ö"; a12.Text = "ü"; a13.Text = "ó";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "z"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "ő"; b13.Text = "ú"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "é"; c12.Text = "á"; c13.Text = "ű"; c14.Text = "Enter";
                        d1.Text = "Shift"; d2.Text = "y"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "-"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;

                case "he": // Hebrew
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = ":"; c12.Text = "\""; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "/"; b3.Text = "׳"; b4.Text = "ק"; b5.Text = "ר"; b6.Text = "א"; b7.Text = "ט"; b8.Text = "ו"; b9.Text = "ן"; b10.Text = "ם"; b11.Text = "פ"; b12.Text = "]"; b13.Text = "["; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "ש"; c3.Text = "ד"; c4.Text = "ג"; c5.Text = "כ"; c6.Text = "ע"; c7.Text = "י"; c8.Text = "ח"; c9.Text = "ל"; c10.Text = "ך"; c11.Text = "ף"; c12.Text = ","; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ז"; d3.Text = "ס"; d4.Text = "ב"; d5.Text = "ה"; d6.Text = "נ"; d7.Text = "מ"; d8.Text = "צ"; d9.Text = "ת"; d10.Text = "ץ"; d11.Text = "."; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;

                case "ro": // Romanian
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Z"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "Î"; b13.Text = "Â"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Ș"; c12.Text = "Ț"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "Y"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "z"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "î"; b13.Text = "â"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "ș"; c12.Text = "ț"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "y"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;


                case "bg": // Bulgarian
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Я"; b3.Text = "В"; b4.Text = "Е"; b5.Text = "Р"; b6.Text = "Т"; b7.Text = "Ъ"; b8.Text = "У"; b9.Text = "И"; b10.Text = "О"; b11.Text = "П"; b12.Text = "Ю"; b13.Text = "Щ"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "А"; c3.Text = "С"; c4.Text = "Д"; c5.Text = "Ф"; c6.Text = "Г"; c7.Text = "Х"; c8.Text = "Й"; c9.Text = "К"; c10.Text = "Л"; c11.Text = "Ш"; c12.Text = "Ч"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "З"; d3.Text = "Ь"; d4.Text = "Ц"; d5.Text = "Ж"; d6.Text = "Б"; d7.Text = "Н"; d8.Text = "М"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "я"; b3.Text = "в"; b4.Text = "е"; b5.Text = "р"; b6.Text = "т"; b7.Text = "ъ"; b8.Text = "у"; b9.Text = "и"; b10.Text = "о"; b11.Text = "п"; b12.Text = "ю"; b13.Text = "щ"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "а"; c3.Text = "с"; c4.Text = "д"; c5.Text = "ф"; c6.Text = "г"; c7.Text = "х"; c8.Text = "й"; c9.Text = "к"; c10.Text = "л"; c11.Text = "ш"; c12.Text = "ч"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "з"; d3.Text = "ь"; d4.Text = "ц"; d5.Text = "ж"; d6.Text = "б"; d7.Text = "н"; d8.Text = "м"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;

                case "fi": // Finnish
                    if (chk_shift.Checked)
                    {
                        a1.Text = "§"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "Å"; b13.Text = "¨"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Ö"; c12.Text = "Ä"; c13.Text = "'"; c14.Text = "Enter";
                        d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "½"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "+"; a13.Text = "´";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "å"; b13.Text = "^"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "ö"; c12.Text = "ä"; c13.Text = "´"; c14.Text = "Enter";
                        d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "-"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;

                case "no": // Norwegian (Bokmål)
                    if (chk_shift.Checked)
                    {
                        a1.Text = "§"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "Å"; b13.Text = "¨"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Ø"; c12.Text = "Æ"; c13.Text = "'"; c14.Text = "Enter";
                        d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; c5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "|"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "+"; a13.Text = "\\";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "å"; b13.Text = "´"; b14.Text = "";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "ø"; c12.Text = "æ"; c13.Text = "`"; c14.Text = "Enter";
                        d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "-"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;

                case "id": // Indonesian
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = ":"; c12.Text = "\""; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = ";"; c12.Text = "'"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;




                case "sk": // Slovak
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Z"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "Ú"; b13.Text = "Ä"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Ľ"; c12.Text = "Ô"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "Y"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = ";"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "ľ"; a13.Text = "´";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "z"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "ú"; b13.Text = "ä"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "š"; c12.Text = "ô"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "y"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "-"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;

                case "sl": // Slovenian
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Z"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "Š"; b13.Text = "Đ"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Č"; c12.Text = "Ć"; c13.Text = "Ž"; c14.Text = "Enter";
                        d1.Text = "Shift"; d2.Text = "Y"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "z"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "š"; b13.Text = "đ"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "č"; c12.Text = "ć"; c13.Text = "ž"; c14.Text = "Enter";
                        d1.Text = "Shift"; d2.Text = "y"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;

                case "ms": // Malay (Malaysia)
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = ":"; c12.Text = "\""; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = ";"; c12.Text = "'"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;

                case "bn": // Bengali (Bangladesh)
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "১"; a3.Text = "২"; a4.Text = "৩"; a5.Text = "৪"; a6.Text = "৫"; a7.Text = "৬"; a8.Text = "৭"; a9.Text = "৮"; a10.Text = "৯"; a11.Text = "০"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "ঔ"; b3.Text = "ঐ"; b4.Text = "আ"; b5.Text = "ঈ"; b6.Text = "ঊ"; b7.Text = "ভ"; b8.Text = "ঙ"; b9.Text = "ঘ"; b10.Text = "ধ"; b11.Text = "ঝ"; b12.Text = "ঢ"; b13.Text = "ঞ"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "ও"; c3.Text = "এ"; c4.Text = "অ"; c5.Text = "ই"; c6.Text = "উ"; c7.Text = "ফ"; c8.Text = "ড়"; c9.Text = "খ"; c10.Text = "থ"; c11.Text = "ছ"; c12.Text = "ঠ"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ঁ"; c3.Text = "ং"; d4.Text = "ঃ"; d5.Text = "ম"; d6.Text = "ন"; d7.Text = "ণ"; d8.Text = "ব"; d9.Text = "ল"; d10.Text = "শ"; d11.Text = "ষ"; d12.Text = "Shift"; d13.Text = "ৃ"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "ৌ"; b3.Text = "ৈ"; b4.Text = "া"; b5.Text = "ী"; b6.Text = "ূ"; b7.Text = "ব"; b8.Text = "হ"; b9.Text = "গ"; b10.Text = "দ"; b11.Text = "জ"; b12.Text = "ড"; b13.Text = "়"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "ো"; c3.Text = "ে"; c4.Text = "্"; c5.Text = "ি"; c6.Text = "ু"; c7.Text = "প"; c8.Text = "র"; c9.Text = "ক"; c10.Text = "ত"; c11.Text = "চ"; c12.Text = "ট"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "য"; d3.Text = "ঙ"; d4.Text = "ং"; d5.Text = "ম"; d6.Text = "ন"; d7.Text = "ব"; d8.Text = "ল"; d9.Text = "স"; d10.Text = ","; d11.Text = "."; d12.Text = "Shift"; d13.Text = "য়"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;




                case "ta": // Tamil
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "௧"; a3.Text = "௨"; a4.Text = "௩"; a5.Text = "௪"; a6.Text = "௫"; a7.Text = "௬"; a8.Text = "௭"; a9.Text = "௮"; a10.Text = "௯"; a11.Text = "௦"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "ஔ"; b3.Text = "ஐ"; b4.Text = "ஆ"; b5.Text = "ஈ"; b6.Text = "ஊ"; b7.Text = "ப"; b8.Text = "ங"; b9.Text = "க"; b10.Text = "த"; b11.Text = "ஜ"; b12.Text = "ட"; b13.Text = "ஞ"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "ஓ"; c3.Text = "ஏ"; c4.Text = "அ"; c5.Text = "இ"; c6.Text = "உ"; c7.Text = "ப"; c8.Text = "ற"; c9.Text = "க"; c10.Text = "த"; c11.Text = "ச"; c12.Text = "ட"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "எ"; d3.Text = "்"; d4.Text = "ஹ"; d5.Text = "ம"; d6.Text = "ன"; d7.Text = "ண"; d8.Text = "வ"; d9.Text = "ல"; d10.Text = "ஸ"; d11.Text = "ஷ"; d12.Text = "Shift"; d13.Text = "ள"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "ௌ"; b3.Text = "ை"; b4.Text = "ா"; b5.Text = "ீ"; b6.Text = "ூ"; b7.Text = "ப"; b8.Text = "ங"; b9.Text = "க"; b10.Text = "த"; b11.Text = "ஜ"; b12.Text = "ட"; b13.Text = "ஞ"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "ோ"; c3.Text = "ே"; c4.Text = "்"; c5.Text = "ி"; c6.Text = "ு"; c7.Text = "ப"; c8.Text = "ர"; c9.Text = "க"; c10.Text = "த"; c11.Text = "ச"; c12.Text = "ட"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ெ"; d3.Text = "்"; d4.Text = "ஹ"; d5.Text = "ம"; d6.Text = "ன"; d7.Text = "ண"; d8.Text = "வ"; d9.Text = "ல"; d10.Text = "ஸ"; d11.Text = "ஷ"; d12.Text = "Shift"; d13.Text = "ள"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;

                case "te": // Telugu
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "౧"; a3.Text = "౨"; a4.Text = "౩"; a5.Text = "౪"; a6.Text = "౫"; a7.Text = "౬"; a8.Text = "౭"; a9.Text = "౮"; a10.Text = "౯"; a11.Text = "౦"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "ఔ"; b3.Text = "ఐ"; b4.Text = "ఆ"; b5.Text = "ఈ"; b6.Text = "ఊ"; b7.Text = "భ"; b8.Text = "ఙ"; b9.Text = "ఘ"; b10.Text = "ధ"; b11.Text = "ఝ"; b12.Text = "ఢ"; b13.Text = "ఞ"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "ఓ"; c3.Text = "ఏ"; c4.Text = "అ"; c5.Text = "ఇ"; c6.Text = "ఉ"; c7.Text = "ఫ"; c8.Text = "ఱ"; c9.Text = "ఖ"; c10.Text = "థ"; c11.Text = "ఛ"; c12.Text = "ఠ"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ఎ"; d3.Text = "ం"; d4.Text = "ః"; d5.Text = "మ"; d6.Text = "న"; d7.Text = "ణ"; d8.Text = "వ"; d9.Text = "ల"; d10.Text = "శ"; d11.Text = "ష"; d12.Text = "Shift"; d13.Text = "ళ"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "ౌ"; b3.Text = "ై"; b4.Text = "ా"; b5.Text = "ీ"; b6.Text = "ూ"; b7.Text = "బ"; b8.Text = "హ"; b9.Text = "గ"; b10.Text = "ద"; b11.Text = "జ"; b12.Text = "డ"; b13.Text = "ృ"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "ో"; c3.Text = "ే"; c4.Text = "్"; c5.Text = "ి"; c6.Text = "ు"; c7.Text = "ప"; c8.Text = "ర"; c9.Text = "క"; c10.Text = "త"; c11.Text = "చ"; c12.Text = "ట"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ె"; d3.Text = "ం"; d4.Text = "స"; d5.Text = "మ"; d6.Text = "న"; d7.Text = "వ"; d8.Text = "ల"; d9.Text = "స"; d10.Text = ","; d11.Text = "."; d12.Text = "Shift"; d13.Text = "య"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;

                case "ur": // Urdu (Pakistan)
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = ")"; a11.Text = "("; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "ض"; b3.Text = "ص"; b4.Text = "ث"; b5.Text = "ق"; b6.Text = "ف"; b7.Text = "غ"; b8.Text = "ع"; b9.Text = "ہ"; b10.Text = "خ"; b11.Text = "ح"; b12.Text = "ج"; b13.Text = "چ"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "ش"; c3.Text = "س"; c4.Text = "ی"; c5.Text = "ب"; c6.Text = "ل"; c7.Text = "ا"; c8.Text = "ت"; c9.Text = "ن"; c10.Text = "م"; c11.Text = "ک"; c12.Text = "گ"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ظ"; d3.Text = "ط"; d4.Text = "ز"; d5.Text = "ر"; d6.Text = "ذ"; d7.Text = "د"; d8.Text = "پ"; d9.Text = "و"; d10.Text = "ٹ"; d11.Text = "ڈ"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "ق"; b3.Text = "و"; b4.Text = "ع"; b5.Text = "ر"; b6.Text = "ت"; b7.Text = "ے"; b8.Text = "ء"; b9.Text = "ی"; b10.Text = "ہ"; b11.Text = "پ"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "ا"; c3.Text = "س"; c4.Text = "د"; c5.Text = "ف"; c6.Text = "گ"; c7.Text = "ھ"; c8.Text = "ج"; c9.Text = "ک"; c10.Text = "ل"; c11.Text = "؛"; c12.Text = "'"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ز"; d3.Text = "ش"; d4.Text = "چ"; d5.Text = "ط"; d6.Text = "ب"; d7.Text = "ن"; d8.Text = "م"; d9.Text = "،"; d10.Text = "۔"; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;

                case "gu": // Gujarati
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "૧"; a3.Text = "૨"; a4.Text = "૩"; a5.Text = "૪"; a6.Text = "૫"; a7.Text = "૬"; a8.Text = "૭"; a9.Text = "૮"; a10.Text = "૯"; a11.Text = "૦"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "ઔ"; b3.Text = "ઐ"; b4.Text = "આ"; b5.Text = "ઈ"; b6.Text = "ઊ"; b7.Text = "ભ"; b8.Text = "ઙ"; b9.Text = "ઘ"; b10.Text = "ધ"; b11.Text = "ઝ"; b12.Text = "ઢ"; b13.Text = "ઞ"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "ઓ"; c3.Text = "એ"; c4.Text = "અ"; c5.Text = "ઇ"; c6.Text = "ઉ"; c7.Text = "ફ"; c8.Text = "઱"; c9.Text = "ખ"; c10.Text = "થ"; c11.Text = "છ"; c12.Text = "ઠ"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ઍ"; d3.Text = "ં"; d4.Text = "ઃ"; d5.Text = "મ"; d6.Text = "ન"; d7.Text = "ણ"; d8.Text = "વ"; d9.Text = "લ"; d10.Text = "શ"; d11.Text = "ષ"; d12.Text = "Shift"; d13.Text = "ૃ"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "ૌ"; b3.Text = "ૈ"; b4.Text = "ા"; b5.Text = "ી"; b6.Text = "ૂ"; b7.Text = "બ"; b8.Text = "હ"; b9.Text = "ગ"; b10.Text = "દ"; b11.Text = "જ"; b12.Text = "ડ"; b13.Text = "ૉ"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "ો"; c3.Text = "ે"; c4.Text = "્"; c5.Text = "િ"; c6.Text = "ુ"; c7.Text = "પ"; c8.Text = "ર"; c9.Text = "ક"; c10.Text = "ત"; c11.Text = "ચ"; c12.Text = "ટ"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ૅ"; d3.Text = "ં"; d4.Text = "હ"; d5.Text = "મ"; d6.Text = "ન"; d7.Text = "વ"; d8.Text = "લ"; d9.Text = "સ"; d10.Text = ","; d11.Text = "."; d12.Text = "Shift"; d13.Text = "ય"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;





                case "kn": // Kannada
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "೧"; a3.Text = "೨"; a4.Text = "೩"; a5.Text = "೪"; a6.Text = "೫"; a7.Text = "೬"; a8.Text = "೭"; a9.Text = "೮"; a10.Text = "೯"; a11.Text = "೦"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "ಔ"; b3.Text = "ಐ"; b4.Text = "ಆ"; b5.Text = "ಈ"; b6.Text = "ಊ"; b7.Text = "ಭ"; b8.Text = "ಙ"; b9.Text = "ಘ"; b10.Text = "ಧ"; b11.Text = "ಝ"; b12.Text = "ಢ"; b13.Text = "ಞ"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "ಓ"; c3.Text = "ಏ"; c4.Text = "ಅ"; c5.Text = "ಇ"; c6.Text = "ಉ"; c7.Text = "ಫ"; c8.Text = "ಱ"; c9.Text = "ಖ"; c10.Text = "ಥ"; c11.Text = "ಛ"; c12.Text = "ಠ"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ಎ"; d3.Text = "ಂ"; d4.Text = "ಃ"; d5.Text = "ಮ"; d6.Text = "ನ"; d7.Text = "ಣ"; d8.Text = "ವ"; d9.Text = "ಲ"; d10.Text = "ಶ"; d11.Text = "ಷ"; d12.Text = "Shift"; d13.Text = "ಳ"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "ೌ"; b3.Text = "ೈ"; b4.Text = "ಾ"; b5.Text = "ೀ"; b6.Text = "ೂ"; b7.Text = "ಬ"; b8.Text = "ಹ"; b9.Text = "ಗ"; b10.Text = "ದ"; b11.Text = "ಜ"; b12.Text = "ಡ"; b13.Text = "ೃ"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "ೋ"; c3.Text = "ೇ"; c4.Text = "್"; c5.Text = "ಿ"; c6.Text = "ು"; c7.Text = "ಪ"; c8.Text = "ರ"; c9.Text = "ಕ"; c10.Text = "ತ"; c11.Text = "ಚ"; c12.Text = "ಟ"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ೆ"; d3.Text = "ಂ"; d4.Text = "ಸ"; d5.Text = "ಮ"; d6.Text = "ನ"; d7.Text = "ವ"; d8.Text = "ಲ"; d9.Text = "ಸ"; d10.Text = ","; d11.Text = "."; d12.Text = "Shift"; d13.Text = "ಯ"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;

                case "ml": // Malayalam
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "൧"; a3.Text = "൨"; a4.Text = "൩"; a5.Text = "൪"; a6.Text = "൫"; a7.Text = "൬"; a8.Text = "൭"; a9.Text = "൮"; a10.Text = "൯"; a11.Text = "൦"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "ഔ"; b3.Text = "ഐ"; b4.Text = "ആ"; b5.Text = "ഈ"; b6.Text = "ഊ"; b7.Text = "ഭ"; b8.Text = "ങ"; b9.Text = "ഘ"; b10.Text = "ധ"; b11.Text = "ഝ"; b12.Text = "ഢ"; b13.Text = "ഞ"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "ഓ"; c3.Text = "ഏ"; c4.Text = "അ"; c5.Text = "ഇ"; c6.Text = "ഉ"; c7.Text = "ഫ"; c8.Text = "റ"; c9.Text = "ഖ"; c10.Text = "ഥ"; c11.Text = "ഛ"; c12.Text = "ഠ"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "എ"; d3.Text = "ം"; d4.Text = "ഃ"; d5.Text = "മ"; d6.Text = "ന"; d7.Text = "ണ"; d8.Text = "വ"; d9.Text = "ല"; d10.Text = "ശ"; d11.Text = "ഷ"; d12.Text = "Shift"; d13.Text = "ള"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "ൌ"; b3.Text = "ൈ"; b4.Text = "ാ"; b5.Text = "ീ"; b6.Text = "ൂ"; b7.Text = "ബ"; b8.Text = "ഹ"; b9.Text = "ഗ"; b10.Text = "ദ"; b11.Text = "ജ"; b12.Text = "ഡ"; b13.Text = "ൃ"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "ോ"; c3.Text = "േ"; c4.Text = "്"; c5.Text = "ി"; c6.Text = "ു"; c7.Text = "പ"; c8.Text = "ര"; c9.Text = "ക"; c10.Text = "ത"; c11.Text = "ച"; c12.Text = "ട"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "െ"; d3.Text = "ം"; d4.Text = "സ"; d5.Text = "മ"; d6.Text = "ന"; d7.Text = "വ"; d8.Text = "ല"; d9.Text = "സ"; d10.Text = ","; d11.Text = "."; d12.Text = "Shift"; d13.Text = "യ"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;

                case "pa": // Punjabi (Gurmukhi)
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "੧"; a3.Text = "੨"; a4.Text = "੩"; a5.Text = "੪"; a6.Text = "੫"; a7.Text = "੬"; a8.Text = "੭"; a9.Text = "੮"; a10.Text = "੯"; a11.Text = "੦"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "ਔ"; b3.Text = "ਐ"; b4.Text = "ਆ"; b5.Text = "ਈ"; b6.Text = "ਊ"; b7.Text = "ਭ"; b8.Text = "ਙ"; b9.Text = "ਘ"; b10.Text = "ਧ"; b11.Text = "ਝ"; b12.Text = "ਢ"; b13.Text = "ਞ"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "ਓ"; c3.Text = "ਏ"; c4.Text = "ਅ"; c5.Text = "ਇ"; c6.Text = "ਉ"; c7.Text = "ਫ"; c8.Text = "ੜ"; c9.Text = "ਖ"; c10.Text = "ਥ"; c11.Text = "ਛ"; c12.Text = "ਠ"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "਍"; d3.Text = "ਂ"; d4.Text = "ਃ"; d5.Text = "ਮ"; d6.Text = "ਨ"; d7.Text = "ਣ"; d8.Text = "ਵ"; d9.Text = "ਲ"; d10.Text = "ਸ਼"; d11.Text = "਷"; d12.Text = "Shift"; d13.Text = "ਲ਼"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "ੌ"; b3.Text = "ੈ"; b4.Text = "ਾ"; b5.Text = "ੀ"; b6.Text = "ੂ"; b7.Text = "ਬ"; b8.Text = "ਹ"; b9.Text = "ਗ"; b10.Text = "ਦ"; b11.Text = "ਜ"; b12.Text = "ਡ"; b13.Text = "੃"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "ੋ"; c3.Text = "ੇ"; c4.Text = "्"; c5.Text = "ਿ"; c6.Text = "ੁ"; c7.Text = "ਪ"; c8.Text = "ਰ"; c9.Text = "ਕ"; c10.Text = "ਤ"; c11.Text = "ਚ"; c12.Text = "ਟ"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ੈ"; d3.Text = "ਂ"; d4.Text = "ਸ"; d5.Text = "ਮ"; d6.Text = "ਨ"; d7.Text = "ਵ"; d8.Text = "ਲ"; d9.Text = "ਸ"; d10.Text = ","; d11.Text = "."; d12.Text = "Shift"; d13.Text = "ਯ"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;


                case "mr": // Marathi
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "१"; a3.Text = "२"; a4.Text = "३"; a5.Text = "४"; a6.Text = "५"; a7.Text = "६"; a8.Text = "७"; a9.Text = "८"; a10.Text = "९"; a11.Text = "०"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "औ"; b3.Text = "ऐ"; b4.Text = "आ"; b5.Text = "ई"; b6.Text = "ऊ"; b7.Text = "भ"; b8.Text = "ङ"; b9.Text = "घ"; b10.Text = "ध"; b11.Text = "झ"; b12.Text = "ढ"; b13.Text = "ञ"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "ओ"; c3.Text = "ए"; c4.Text = "अ"; c5.Text = "इ"; c6.Text = "उ"; c7.Text = "फ"; c8.Text = "ऱ"; c9.Text = "ख"; c10.Text = "थ"; c11.Text = "छ"; c12.Text = "ठ"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ऍ"; d3.Text = "ं"; d4.Text = "ः"; d5.Text = "म"; d6.Text = "न"; d7.Text = "ण"; d8.Text = "व"; d9.Text = "ल"; d10.Text = "श"; d11.Text = "ष"; d12.Text = "Shift"; d13.Text = "ळ"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "ौ"; b3.Text = "ै"; b4.Text = "ा"; b5.Text = "ी"; b6.Text = "ू"; b7.Text = "ब"; b8.Text = "ह"; b9.Text = "ग"; b10.Text = "द"; b11.Text = "ज"; b12.Text = "ड"; b13.Text = "ृ"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "ो"; c3.Text = "े"; c4.Text = "्"; c5.Text = "ि"; c6.Text = "ु"; c7.Text = "प"; c8.Text = "र"; c9.Text = "क"; c10.Text = "त"; c11.Text = "च"; c12.Text = "ट"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ॅ"; d3.Text = "ं"; d4.Text = "स"; d5.Text = "म"; d6.Text = "न"; d7.Text = "व"; d8.Text = "ल"; d9.Text = "स"; d10.Text = ","; d11.Text = "."; d12.Text = "Shift"; d13.Text = "य"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;




                case "fa": // Persian
                    if (chk_shift.Checked)
                    {
                        a1.Text = "÷"; a2.Text = "۱"; a3.Text = "۲"; a4.Text = "۳"; a5.Text = "۴"; a6.Text = "۵"; a7.Text = "۶"; a8.Text = "۷"; a9.Text = "۸"; a10.Text = "۹"; a11.Text = "۰"; a12.Text = "×"; a13.Text = "٪";
                        b1.Text = "Tab"; b2.Text = "ض"; b3.Text = "ص"; b4.Text = "ث"; b5.Text = "ق"; b6.Text = "ف"; b7.Text = "غ"; b8.Text = "ع"; b9.Text = "ه"; b10.Text = "خ"; b11.Text = "ح"; b12.Text = "ج"; b13.Text = "چ"; b14.Text = "‌";
                        c1.Text = "Caps"; c2.Text = "ش"; c3.Text = "س"; c4.Text = "ی"; c5.Text = "ب"; c6.Text = "ل"; c7.Text = "ا"; c8.Text = "ت"; c9.Text = "ن"; c10.Text = "م"; c11.Text = "ک"; c12.Text = "گ"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ظ"; d3.Text = "ط"; d4.Text = "ز"; d5.Text = "ر"; d6.Text = "ذ"; d7.Text = "د"; d8.Text = "پ"; d9.Text = "و"; d10.Text = "؟"; d11.Text = "!"; d12.Text = "Shift"; d13.Text = "؛"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = e7.Text = e8.Text = e9.Text = e10.Text = e11.Text = e12.Text = e13.Text = e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "‍"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "ق"; b3.Text = "و"; b4.Text = "ه"; b5.Text = "ر"; b6.Text = "ت"; b7.Text = "ی"; b8.Text = "ش"; b9.Text = "س"; b10.Text = "ب"; b11.Text = "ل"; b12.Text = "ا"; b13.Text = "پ"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "ف"; c3.Text = "غ"; c4.Text = "ع"; c5.Text = "ظ"; c6.Text = "ط"; c7.Text = "ز"; c8.Text = "د"; c9.Text = "ذ"; c10.Text = "خ"; c11.Text = "ج"; c12.Text = "چ"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ث"; d3.Text = "ص"; d4.Text = "ض"; d5.Text = "ن"; d6.Text = "م"; d7.Text = "ک"; d8.Text = "گ"; d9.Text = "ت"; d10.Text = ","; d11.Text = "."; d12.Text = "Shift"; d13.Text = "/"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = e7.Text = e8.Text = e9.Text = e10.Text = e11.Text = e12.Text = e13.Text = e14.Text = "";
                    }
                    break;

                case "lt": // Lithuanian
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "Į"; b13.Text = "Č"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Ų"; c12.Text = "Ū"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = "Ė"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = e7.Text = e8.Text = e9.Text = e10.Text = e11.Text = e12.Text = e13.Text = e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "į"; b13.Text = "č"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "ų"; c12.Text = "ū"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = "ė"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = e7.Text = e8.Text = e9.Text = e10.Text = e11.Text = e12.Text = e13.Text = e14.Text = "";
                    }
                    break;

                case "et": // Estonian
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "Ü"; b13.Text = "Õ"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Ö"; c12.Text = "Ä"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = "Ž"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = e7.Text = e8.Text = e9.Text = e10.Text = e11.Text = e12.Text = e13.Text = e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "ü"; b13.Text = "õ"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "ö"; c12.Text = "ä"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = "ž"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = e7.Text = e8.Text = e9.Text = e10.Text = e11.Text = e12.Text = e13.Text = e14.Text = "";
                    }
                    break;


                case "ka": // Georgian
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "ღ"; b3.Text = "ჯ"; b4.Text = "უ"; b5.Text = "კ"; b6.Text = "ე"; b7.Text = "ნ"; b8.Text = "გ"; b9.Text = "შ"; b10.Text = "წ"; b11.Text = "ზ"; b12.Text = "ხ"; b13.Text = "ჩ"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "ფ"; c3.Text = "ვ"; c4.Text = "დ"; c5.Text = "ა"; c6.Text = "პ"; c7.Text = "რ"; c8.Text = "ო"; c9.Text = "ლ"; c10.Text = "ყ"; c11.Text = "ს"; c12.Text = "ტ"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ჭ"; d3.Text = "ც"; d4.Text = "ძ"; d5.Text = "თ"; d6.Text = "ი"; d7.Text = "ბ"; d8.Text = "ჰ"; d9.Text = "მ"; d10.Text = "<"; d11.Text = ">"; d12.Text = "Shift"; d13.Text = "ჟ"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = e7.Text = e8.Text = e9.Text = e10.Text = e11.Text = e12.Text = e13.Text = e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "ქ"; b3.Text = "ჭ"; b4.Text = "უ"; b5.Text = "თ"; b6.Text = "ე"; b7.Text = "ნ"; b8.Text = "გ"; b9.Text = "შ"; b10.Text = "წ"; b11.Text = "ზ"; b12.Text = "ხ"; b13.Text = "ჩ"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "ა"; c3.Text = "ს"; c4.Text = "დ"; c5.Text = "ფ"; c6.Text = "გ"; c7.Text = "ჰ"; c8.Text = "ო"; c9.Text = "ლ"; c10.Text = "ყ"; c11.Text = "ვ"; c12.Text = "ტ"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ჯ"; d3.Text = "ც"; d4.Text = "ძ"; d5.Text = "რ"; d6.Text = "ი"; d7.Text = "ბ"; d8.Text = "მ"; d9.Text = "პ"; d10.Text = ","; d11.Text = "."; d12.Text = "Shift"; d13.Text = "ჟ"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = e7.Text = e8.Text = e9.Text = e10.Text = e11.Text = e12.Text = e13.Text = e14.Text = "";
                    }
                    break;

                case "am": // Amharic
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "፩"; a3.Text = "፪"; a4.Text = "፫"; a5.Text = "፬"; a6.Text = "፭"; a7.Text = "፮"; a8.Text = "፯"; a9.Text = "፰"; a10.Text = "፱"; a11.Text = "፲"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "ቀ"; b3.Text = "ወ"; b4.Text = "አ"; b5.Text = "ረ"; b6.Text = "ተ"; b7.Text = "የ"; b8.Text = "ኡ"; b9.Text = "ኢ"; b10.Text = "ኦ"; b11.Text = "ፐ"; b12.Text = "ጸ"; b13.Text = "፡"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "ኤ"; c3.Text = "ሰ"; c4.Text = "ደ"; c5.Text = "ፈ"; c6.Text = "ገ"; c7.Text = "ሀ"; c8.Text = "ጀ"; c9.Text = "ከ"; c10.Text = "ለ"; c11.Text = "መ"; c12.Text = "ጠ"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ዘ"; d3.Text = "ጨ"; c4.Text = "ቸ"; d5.Text = "በ"; d6.Text = "ነ"; d7.Text = "ዐ"; d8.Text = "ሸ"; d9.Text = "ዸ"; d10.Text = "፣"; d11.Text = "።"; d12.Text = "Shift"; d13.Text = "ፀ"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = e7.Text = e8.Text = e9.Text = e10.Text = e11.Text = e12.Text = e13.Text = e14.Text = "";
                    }


                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "ሀ"; b3.Text = "ለ"; b4.Text = "ሐ"; b5.Text = "መ"; b6.Text = "ረ"; b7.Text = "ሰ"; b8.Text = "ሸ"; b9.Text = "ቀ"; b10.Text = "በ"; b11.Text = "ተ"; b12.Text = "ቸ"; b13.Text = "ኀ"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "ነ"; c3.Text = "ኘ"; c4.Text = "አ"; c5.Text = "ከ"; c6.Text = "ኰ"; c7.Text = "ወ"; c8.Text = "ዐ"; c9.Text = "ዘ"; c10.Text = "የ"; c11.Text = "ደ"; c12.Text = "ዸ"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "ገ"; d3.Text = "ጠ"; d4.Text = "ጰ"; d5.Text = "ጸ"; d6.Text = "ፈ"; d7.Text = "ፐ"; d8.Text = "ፀ"; d9.Text = "፡"; d10.Text = ","; d11.Text = "."; d12.Text = "Shift"; d13.Text = "።"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = e7.Text = e8.Text = e9.Text = e10.Text = e11.Text = e12.Text = e13.Text = e14.Text = "";
                    }
                    break;

                case "lv": // Latvian
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "Ū"; b13.Text = "Ī"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Ķ"; c12.Text = "Ļ"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "Ņ"; d10.Text = "Ģ"; d11.Text = "Č"; d12.Text = "Shift"; d13.Text = "Š"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = e7.Text = e8.Text = e9.Text = e10.Text = e11.Text = e12.Text = e13.Text = e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "ū"; b13.Text = "ī"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "ķ"; c12.Text = "ļ"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = "ņ"; d10.Text = "ģ"; d11.Text = "č"; d12.Text = "Shift"; d13.Text = "š"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = e7.Text = e8.Text = e9.Text = e10.Text = e11.Text = e12.Text = e13.Text = e14.Text = "";
                    }
                    break;


                case "sw": // Swahili (Kenya)
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = ":"; c12.Text = "\""; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = "~"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = e7.Text = e8.Text = e9.Text = e10.Text = e11.Text = e12.Text = e13.Text = e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = ";"; c12.Text = "'"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = "`"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = e7.Text = e8.Text = e9.Text = e10.Text = e11.Text = e12.Text = e13.Text = e14.Text = "";
                    }
                    break;

                case "is": // Icelandic
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "Ð"; b13.Text = "Þ"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Æ"; c12.Text = "Ö"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = "´"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = e7.Text = e8.Text = e9.Text = e10.Text = e11.Text = e12.Text = e13.Text = e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "ð"; b13.Text = "þ"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "æ"; c12.Text = "ö"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = "´"; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = e7.Text = e8.Text = e9.Text = e10.Text = e11.Text = e12.Text = e13.Text = e14.Text = "";
                    }
                    break;



                case "af": // Afrikaans (Latin, based on US QWERTY)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = ":"; c12.Text = "\""; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = ";"; c12.Text = "'"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "as": // Assamese (InScript layout, Devanagari-like, adapted to QWERTY)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "১"; a3.Text = "২"; a4.Text = "৩"; a5.Text = "৪"; a6.Text = "৫"; a7.Text = "৬"; a8.Text = "৭"; a9.Text = "৮"; a10.Text = "৯"; a11.Text = "০"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "ঔ"; b3.Text = "ঐ"; b4.Text = "আ"; b5.Text = "ঈ"; b6.Text = "ঊ"; b7.Text = "ভ"; b8.Text = "ঙ"; b9.Text = "ঘ"; b10.Text = "ধ"; b11.Text = "ঝ"; b12.Text = "ঢ"; b13.Text = "ঞ"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "ও"; c3.Text = "এ"; c4.Text = "অ"; c5.Text = "ই"; c6.Text = "উ"; c7.Text = "ফ"; c8.Text = "ৰ"; c9.Text = "খ"; c10.Text = "থ"; c11.Text = "ছ"; c12.Text = "ঠ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "ঁ"; d3.Text = "ং"; d4.Text = "ঃ"; d5.Text = "ম"; d6.Text = "ন"; d7.Text = "ণ"; d8.Text = "ৱ"; d9.Text = "ল"; d10.Text = "শ"; d11.Text = "ষ"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "ৌ"; b3.Text = "ৈ"; b4.Text = "া"; b5.Text = "ী"; b6.Text = "ূ"; b7.Text = "ব"; b8.Text = "হ"; b9.Text = "গ"; b10.Text = "দ"; b11.Text = "জ"; b12.Text = "ড"; b13.Text = "ৃ"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "ো"; c3.Text = "ে"; c4.Text = "্"; c5.Text = "ি"; c6.Text = "ু"; c7.Text = "প"; c8.Text = "র"; c9.Text = "ক"; c10.Text = "ত"; c11.Text = "চ"; c12.Text = "ট"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "৺"; d3.Text = "ং"; d4.Text = "স"; d5.Text = "ম"; d6.Text = "ন"; d7.Text = "ৱ"; d8.Text = "ল"; d9.Text = "স"; d10.Text = ","; d11.Text = "."; d12.Text = "Shift"; d13.Text = "য"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "az": // Azerbaijani (Latin, QÜERTY variant)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "Ü"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "İ"; b10.Text = "O"; b11.Text = "P"; b12.Text = "Ğ"; b13.Text = "Ə"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Ş"; c12.Text = "Ç"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "ü"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "ğ"; b13.Text = "ə"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "ş"; c12.Text = "ç"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "be": // Belarusian (Cyrillic)
                    if (chk_shift.Checked) { a1.Text = "Ё"; a2.Text = "!"; a3.Text = "\""; a4.Text = "№"; a5.Text = ";"; a6.Text = "%"; a7.Text = ":"; a8.Text = "?"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Й"; b3.Text = "Ц"; b4.Text = "У"; b5.Text = "К"; b6.Text = "Е"; b7.Text = "Н"; b8.Text = "Г"; b9.Text = "Ш"; b10.Text = "Ў"; b11.Text = "З"; b12.Text = "Х"; b13.Text = "’"; b14.Text = "/"; c1.Text = "Caps"; c2.Text = "Ф"; c3.Text = "Ы"; c4.Text = "В"; c5.Text = "А"; c6.Text = "П"; c7.Text = "Р"; c8.Text = "О"; c9.Text = "Л"; c10.Text = "Д"; c11.Text = "Ж"; c12.Text = "Э"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Я"; d3.Text = "Ч"; d4.Text = "С"; d5.Text = "М"; d6.Text = "І"; d7.Text = "Т"; d8.Text = "Ь"; d9.Text = "Б"; d10.Text = "Ю"; d11.Text = "."; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "ё"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "й"; b3.Text = "ц"; b4.Text = "у"; b5.Text = "к"; b6.Text = "е"; b7.Text = "н"; b8.Text = "г"; b9.Text = "ш"; b10.Text = "ў"; b11.Text = "з"; b12.Text = "х"; b13.Text = "’"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "ф"; c3.Text = "ы"; c4.Text = "в"; c5.Text = "а"; c6.Text = "п"; c7.Text = "р"; c8.Text = "о"; c9.Text = "л"; c10.Text = "д"; c11.Text = "ж"; c12.Text = "э"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "я"; d3.Text = "ч"; d4.Text = "с"; d5.Text = "м"; d6.Text = "і"; d7.Text = "т"; d8.Text = "ь"; d9.Text = "б"; d10.Text = "ю"; d11.Text = ","; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;



                case "bs": // Bosnian (Latin, QWERTY variant)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Z"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "Š"; b13.Text = "Đ"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Č"; c12.Text = "Ć"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Y"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = "Ž"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "z"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "š"; b13.Text = "đ"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "č"; c12.Text = "ć"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "y"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = "ž"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "ca": // Catalan (Spanish QWERTY variant)
                    if (chk_shift.Checked) { a1.Text = "¬"; a2.Text = "!"; a3.Text = "\""; a4.Text = "·"; a5.Text = "$"; a6.Text = "%"; a7.Text = "&"; a8.Text = "/"; a9.Text = "("; a10.Text = ")"; a11.Text = "="; a12.Text = "?"; a13.Text = "¿"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "`"; b13.Text = "^"; b14.Text = "*"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Ç"; c12.Text = "´"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = ";"; d10.Text = "."; d11.Text = "-"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "|"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "'"; a13.Text = "¡"; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "¨"; b13.Text = "["; b14.Text = "]"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "ç"; c12.Text = "¸"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "-"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "cy": // Welsh (UK QWERTY variant)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "!"; a3.Text = "\""; a4.Text = "£"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = ":"; c12.Text = "@"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = ";"; c12.Text = "'"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "da": // Danish (Danish QWERTY)
                    if (chk_shift.Checked) { a1.Text = "½"; a2.Text = "!"; a3.Text = "\""; a4.Text = "#"; a5.Text = "¤"; a6.Text = "%"; a7.Text = "&"; a8.Text = "/"; a9.Text = "("; a10.Text = ")"; a11.Text = "="; a12.Text = "?"; a13.Text = "*"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "Å"; b13.Text = "^"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Æ"; c12.Text = "Ø"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = ";"; d10.Text = ":"; d11.Text = "_"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "§"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "+"; a13.Text = "´"; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "å"; b13.Text = "¨"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "æ"; c12.Text = "ø"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "-"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;




                case "eu": // Basque (Spanish QWERTY variant)
                    if (chk_shift.Checked) { a1.Text = "¬"; a2.Text = "!"; a3.Text = "\""; a4.Text = "·"; a5.Text = "$"; a6.Text = "%"; a7.Text = "&"; a8.Text = "/"; a9.Text = "("; a10.Text = ")"; a11.Text = "="; a12.Text = "?"; a13.Text = "¿"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "`"; b13.Text = "^"; b14.Text = "*"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Ç"; c12.Text = "´"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = ";"; d10.Text = "."; d11.Text = "-"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "|"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "'"; a13.Text = "¡"; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "¨"; b13.Text = "["; b14.Text = "]"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "ç"; c12.Text = "¸"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "-"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;


                case "fil": // Filipino (US QWERTY)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = ":"; c12.Text = "\""; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = ";"; c12.Text = "'"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "ga": // Irish (UK QWERTY variant)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "!"; a3.Text = "\""; a4.Text = "£"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = ":"; c12.Text = "@"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = ";"; c12.Text = "'"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;


                case "gd": // Scottish Gaelic (UK QWERTY variant)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "!"; a3.Text = "\""; a4.Text = "£"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = ":"; c12.Text = "@"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = ";"; c12.Text = "'"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "gl": // Galician (Spanish QWERTY variant)
                    if (chk_shift.Checked) { a1.Text = "¬"; a2.Text = "!"; a3.Text = "\""; a4.Text = "·"; a5.Text = "$"; a6.Text = "%"; a7.Text = "&"; a8.Text = "/"; a9.Text = "("; a10.Text = ")"; a11.Text = "="; a12.Text = "?"; a13.Text = "¿"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "`"; b13.Text = "^"; b14.Text = "*"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Ç"; c12.Text = "´"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = ";"; d10.Text = "."; d11.Text = "-"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "|"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "'"; a13.Text = "¡"; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "¨"; b13.Text = "["; b14.Text = "]"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "ç"; c12.Text = "¸"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "-"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "ha": // Hausa (Latin, US QWERTY variant)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = ":"; c12.Text = "\""; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = ";"; c12.Text = "'"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;



                case "hr": // Croatian (QWERTY variant)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Z"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "Š"; b13.Text = "Đ"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Č"; c12.Text = "Ć"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Y"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = "Ž"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "z"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "š"; b13.Text = "đ"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "č"; c12.Text = "ć"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "y"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = "ž"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;




                case "hy": // Armenian (Eastern Armenian layout)
                    if (chk_shift.Checked) { a1.Text = "՜"; a2.Text = "Ձ"; a3.Text = "Ղ"; a4.Text = "Ճ"; a5.Text = "Մ"; a6.Text = "Յ"; a7.Text = "Ն"; a8.Text = "Շ"; a9.Text = "Ո"; a10.Text = "Չ"; a11.Text = "Պ"; a12.Text = "Ջ"; a13.Text = "Ր"; b1.Text = "Tab"; b2.Text = "Ք"; b3.Text = "Ե"; b4.Text = "Ֆ"; b5.Text = "Ռ"; b6.Text = "Ս"; b7.Text = "Վ"; b8.Text = "Դ"; b9.Text = "Ւ"; b10.Text = "Օ"; b11.Text = "Է"; b12.Text = "Ը"; b13.Text = "Թ"; b14.Text = "Ժ"; c1.Text = "Caps"; c2.Text = "Ա"; c3.Text = "Բ"; c4.Text = "Գ"; c5.Text = "Հ"; c6.Text = "Ի"; c7.Text = "Լ"; c8.Text = "Խ"; c9.Text = "Ծ"; c10.Text = "Կ"; c11.Text = "։"; c12.Text = "Փ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Զ"; d3.Text = "Է"; d4.Text = "Չ"; d5.Text = "Տ"; d6.Text = "Ց"; d7.Text = "Ո"; d8.Text = "Ե"; d9.Text = "Ք"; d10.Text = "Ո"; d11.Text = "՞"; d12.Text = "Shift"; d13.Text = "Ի"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "՝"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "ք"; b3.Text = "ե"; b4.Text = "ր"; b5.Text = "տ"; b6.Text = "ը"; b7.Text = "թ"; b8.Text = "փ"; b9.Text = "ջ"; b10.Text = "օ"; b11.Text = "է"; b12.Text = "ը"; b13.Text = "թ"; b14.Text = "ժ"; c1.Text = "Caps"; c2.Text = "ա"; c3.Text = "բ"; c4.Text = "գ"; c5.Text = "դ"; c6.Text = "ի"; c7.Text = "լ"; c8.Text = "խ"; c9.Text = "ծ"; c10.Text = "կ"; c11.Text = "հ"; c12.Text = "ձ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "զ"; d3.Text = "է"; d4.Text = "չ"; d5.Text = "պ"; d6.Text = "ջ"; d7.Text = "ռ"; d8.Text = "ս"; d9.Text = "վ"; d10.Text = "տ"; d11.Text = "."; d12.Text = "Shift"; d13.Text = "ե"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "ig": // Igbo (US QWERTY variant)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = ":"; c12.Text = "\""; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = ";"; c12.Text = "'"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "kk": // Kazakh (Cyrillic layout)
                    if (chk_shift.Checked) { a1.Text = "Ё"; a2.Text = "!"; a3.Text = "\""; a4.Text = "№"; a5.Text = ";"; a6.Text = "%"; a7.Text = ":"; a8.Text = "?"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Й"; b3.Text = "Ц"; b4.Text = "У"; b5.Text = "К"; b6.Text = "Е"; b7.Text = "Н"; b8.Text = "Г"; b9.Text = "Ш"; b10.Text = "Щ"; b11.Text = "З"; b12.Text = "Х"; b13.Text = "Ъ"; b14.Text = "/"; c1.Text = "Caps"; c2.Text = "Ф"; c3.Text = "Ы"; c4.Text = "В"; c5.Text = "А"; c6.Text = "П"; c7.Text = "Р"; c8.Text = "О"; c9.Text = "Л"; c10.Text = "Д"; c11.Text = "Ж"; c12.Text = "Э"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Я"; d3.Text = "Ч"; d4.Text = "С"; d5.Text = "М"; d6.Text = "И"; d7.Text = "Т"; d8.Text = "Ь"; d9.Text = "Б"; d10.Text = "Ю"; d11.Text = "Ң"; d12.Text = "Shift"; d13.Text = "Ғ"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "ё"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "й"; b3.Text = "ц"; b4.Text = "у"; b5.Text = "к"; b6.Text = "е"; b7.Text = "н"; b8.Text = "г"; b9.Text = "ш"; b10.Text = "щ"; b11.Text = "з"; b12.Text = "х"; b13.Text = "ъ"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "ф"; c3.Text = "ы"; c4.Text = "в"; c5.Text = "а"; c6.Text = "п"; c7.Text = "р"; c8.Text = "о"; c9.Text = "л"; c10.Text = "д"; c11.Text = "ж"; c12.Text = "э"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "я"; d3.Text = "ч"; d4.Text = "с"; d5.Text = "м"; d6.Text = "и"; d7.Text = "т"; d8.Text = "ь"; d9.Text = "б"; d10.Text = "ю"; d11.Text = "ң"; d12.Text = "Shift"; d13.Text = "ғ"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "km": // Khmer (Khmer layout)
                    if (chk_shift.Checked) { a1.Text = "«"; a2.Text = "១"; a3.Text = "២"; a4.Text = "៣"; a5.Text = "៤"; a6.Text = "៥"; a7.Text = "៦"; a8.Text = "៧"; a9.Text = "៨"; a10.Text = "៩"; a11.Text = "០"; a12.Text = "ឥ"; a13.Text = "ឲ"; b1.Text = "Tab"; b2.Text = "ឆ"; b3.Text = "ឹ"; b4.Text = "ឺ"; b5.Text = "រ"; b6.Text = "ត"; b7.Text = "យ"; b8.Text = "ុ"; b9.Text = "ិ"; b10.Text = "ោ"; b11.Text = "ផ"; b12.Text = "ឈ"; b13.Text = "ឍ"; b14.Text = "ឭ"; c1.Text = "Caps"; c2.Text = "អ"; c3.Text = "ស"; c4.Text = "ដ"; c5.Text = "ថ"; c6.Text = "ង"; c7.Text = "ហ"; c8.Text = "្"; c9.Text = "ក"; c10.Text = "ល"; c11.Text = "ើ"; c12.Text = "ៀ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "ឋ"; d3.Text = "ឯ"; d4.Text = "ច"; d5.Text = "វ"; d6.Text = "ប"; d7.Text = "ន"; d8.Text = "ម"; d9.Text = "ុំ"; d10.Text = "ាំ"; d11.Text = "ញ"; d12.Text = "Shift"; d13.Text = "ឮ"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "»"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "ឆ"; b3.Text = "េ"; b4.Text = "ែ"; b5.Text = "រ"; b6.Text = "ត"; b7.Text = "យ"; b8.Text = "ុ"; b9.Text = "ិ"; b10.Text = "ោ"; b11.Text = "ផ"; b12.Text = "ឈ"; b13.Text = "ឍ"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "អ"; c3.Text = "ស"; c4.Text = "ដ"; c5.Text = "ថ"; c6.Text = "ង"; c7.Text = "ហ"; c8.Text = "្"; c9.Text = "ក"; c10.Text = "ល"; c11.Text = "ឹ"; c12.Text = "ៀ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "ឋ"; d3.Text = "ឯ"; d4.Text = "ច"; d5.Text = "វ"; d6.Text = "ប"; d7.Text = "ន"; d8.Text = "ម"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = "ញ"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "kok": // Konkani (InScript Devanagari layout)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "१"; a3.Text = "२"; a4.Text = "३"; a5.Text = "४"; a6.Text = "५"; a7.Text = "६"; a8.Text = "७"; a9.Text = "८"; a10.Text = "९"; a11.Text = "०"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "औ"; b3.Text = "ऐ"; b4.Text = "आ"; b5.Text = "ई"; b6.Text = "ऊ"; b7.Text = "भ"; b8.Text = "ङ"; b9.Text = "घ"; b10.Text = "ध"; b11.Text = "झ"; b12.Text = "ढ"; b13.Text = "ञ"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "ओ"; c3.Text = "ए"; c4.Text = "अ"; c5.Text = "इ"; c6.Text = "उ"; c7.Text = "फ"; c8.Text = "ड़"; c9.Text = "ख"; c10.Text = "थ"; c11.Text = "छ"; c12.Text = "ठ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "ऍ"; d3.Text = "ं"; d4.Text = "ः"; d5.Text = "म"; d6.Text = "न"; d7.Text = "ण"; d8.Text = "व"; d9.Text = "ल"; d10.Text = "श"; d11.Text = "ष"; d12.Text = "Shift"; d13.Text = "ळ"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "ौ"; b3.Text = "ै"; b4.Text = "ा"; b5.Text = "ी"; b6.Text = "ू"; b7.Text = "ब"; b8.Text = "ह"; b9.Text = "ग"; b10.Text = "द"; b11.Text = "ज"; b12.Text = "ड"; b13.Text = "ृ"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "ो"; c3.Text = "े"; c4.Text = "्"; c5.Text = "ि"; c6.Text = "ु"; c7.Text = "प"; c8.Text = "र"; c9.Text = "क"; c10.Text = "त"; c11.Text = "च"; c12.Text = "ट"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "ॅ"; d3.Text = "ं"; d4.Text = "स"; d5.Text = "म"; d6.Text = "न"; d7.Text = "व"; d8.Text = "ल"; d9.Text = "स"; d10.Text = ","; d11.Text = "."; d12.Text = "Shift"; d13.Text = "य"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;







                case "ku": // Kurdish (Arabic script, Arabic layout)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = ")"; a11.Text = "("; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "ض"; b3.Text = "ص"; b4.Text = "ث"; b5.Text = "ق"; b6.Text = "ف"; b7.Text = "غ"; b8.Text = "ع"; b9.Text = "ه"; b10.Text = "خ"; b11.Text = "ح"; b12.Text = "ج"; b13.Text = "چ"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "ش"; c3.Text = "س"; c4.Text = "ي"; c5.Text = "ب"; c6.Text = "ل"; c7.Text = "ا"; c8.Text = "ت"; c9.Text = "ن"; c10.Text = "م"; c11.Text = "ك"; c12.Text = "گ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "ظ"; d3.Text = "ط"; d4.Text = "ذ"; d5.Text = "د"; d6.Text = "ز"; d7.Text = "ر"; d8.Text = "و"; d9.Text = "،"; d10.Text = "."; d11.Text = "?"; d12.Text = "Shift"; d13.Text = "پ"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "١"; a3.Text = "٢"; a4.Text = "٣"; a5.Text = "٤"; a6.Text = "٥"; a7.Text = "٦"; a8.Text = "٧"; a9.Text = "٨"; a10.Text = "٩"; a11.Text = "٠"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "ض"; b3.Text = "ص"; b4.Text = "ث"; b5.Text = "ق"; b6.Text = "ف"; b7.Text = "غ"; b8.Text = "ع"; b9.Text = "ه"; b10.Text = "خ"; b11.Text = "ح"; b12.Text = "ج"; b13.Text = "چ"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "ش"; c3.Text = "س"; c4.Text = "ي"; c5.Text = "ب"; c6.Text = "ل"; c7.Text = "ا"; c8.Text = "ت"; c9.Text = "ن"; c10.Text = "م"; c11.Text = "ك"; c12.Text = "گ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "ظ"; d3.Text = "ط"; d4.Text = "ذ"; d5.Text = "د"; d6.Text = "ز"; d7.Text = "ر"; d8.Text = "و"; d9.Text = "،"; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = "پ"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "ky": // Kyrgyz (Cyrillic layout)
                    if (chk_shift.Checked) { a1.Text = "Ё"; a2.Text = "!"; a3.Text = "\""; a4.Text = "№"; a5.Text = ";"; a6.Text = "%"; a7.Text = ":"; a8.Text = "?"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Й"; b3.Text = "Ц"; b4.Text = "У"; b5.Text = "К"; b6.Text = "Е"; b7.Text = "Н"; b8.Text = "Г"; b9.Text = "Ш"; b10.Text = "Щ"; b11.Text = "З"; b12.Text = "Х"; b13.Text = "Ъ"; b14.Text = "/"; c1.Text = "Caps"; c2.Text = "Ф"; c3.Text = "Ы"; c4.Text = "В"; c5.Text = "А"; c6.Text = "П"; c7.Text = "Р"; c8.Text = "О"; c9.Text = "Л"; c10.Text = "Д"; c11.Text = "Ж"; c12.Text = "Э"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Я"; d3.Text = "Ч"; d4.Text = "С"; d5.Text = "М"; d6.Text = "И"; d7.Text = "Т"; d8.Text = "Ь"; d9.Text = "Б"; d10.Text = "Ю"; d11.Text = "Ң"; d12.Text = "Shift"; d13.Text = "Ү"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "ё"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "й"; b3.Text = "ц"; b4.Text = "у"; b5.Text = "к"; b6.Text = "е"; b7.Text = "н"; b8.Text = "г"; b9.Text = "ш"; b10.Text = "щ"; b11.Text = "з"; b12.Text = "х"; b13.Text = "ъ"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "ф"; c3.Text = "ы"; c4.Text = "в"; c5.Text = "а"; c6.Text = "п"; c7.Text = "р"; c8.Text = "о"; c9.Text = "л"; c10.Text = "д"; c11.Text = "ж"; c12.Text = "э"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "я"; d3.Text = "ч"; d4.Text = "с"; d5.Text = "м"; d6.Text = "и"; d7.Text = "т"; d8.Text = "ь"; d9.Text = "б"; d10.Text = "ю"; d11.Text = "ң"; d12.Text = "Shift"; d13.Text = "ү"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "lb": // Luxembourgish (German QWERTY variant)
                    if (chk_shift.Checked) { a1.Text = "§"; a2.Text = "!"; a3.Text = "\""; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "&"; a8.Text = "/"; a9.Text = "("; a10.Text = ")"; a11.Text = "="; a12.Text = "?"; a13.Text = "`"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Z"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "Ü"; b13.Text = "*"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Ö"; c12.Text = "Ä"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Y"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = ";"; d10.Text = ":"; d11.Text = "_"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "°"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "ß"; a13.Text = "´"; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "z"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "ü"; b13.Text = "+"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "ö"; c12.Text = "ä"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "y"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "-"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "lo": // Lao (Lao layout)
                    if (chk_shift.Checked) { a1.Text = "ໆ"; a2.Text = "ຢ"; a3.Text = "ຟ"; a4.Text = "ໂ"; a5.Text = "ຖ"; a6.Text = "ຸ"; a7.Text = "ູ"; a8.Text = "ຄ"; a9.Text = "ຕ"; a10.Text = "ຈ"; a11.Text = "ຂ"; a12.Text = "ຊ"; a13.Text = "ຼ"; b1.Text = "Tab"; b2.Text = "ພ"; b3.Text = "ະ"; b4.Text = "ຳ"; b5.Text = "ຣ"; b6.Text = "ນ"; b7.Text = "ຍ"; b8.Text = "ບ"; b9.Text = "ລ"; b10.Text = "່"; b11.Text = "້"; b12.Text = "ຫ"; b13.Text = "ກ"; b14.Text = "ດ"; c1.Text = "Caps"; c2.Text = "ສ"; c3.Text = "ຫ"; c4.Text = "ຜ"; c5.Text = "ປ"; c6.Text = "ແ"; b7.Text = "ອ"; b8.Text = "ຮ"; b9.Text = "ຄ"; b10.Text = "ທ"; b11.Text = "ມ"; b12.Text = "ງ"; b13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "ຝ"; d3.Text = "ົ"; d4.Text = "ວ"; d5.Text = "ຶ"; d6.Text = "ື"; d7.Text = "ຕ"; d8.Text = "ຖ"; d9.Text = "ຯ"; d10.Text = "ໍ"; d11.Text = "ຽ"; d12.Text = "Shift"; d13.Text = "ຈ"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "໌"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "ພ"; b3.Text = "ະ"; b4.Text = "ຳ"; b5.Text = "ຣ"; b6.Text = "ນ"; b7.Text = "ຍ"; b8.Text = "ບ"; b9.Text = "ລ"; b10.Text = "່"; b11.Text = "້"; b12.Text = "ຫ"; b13.Text = "ກ"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "ສ"; c3.Text = "ຫ"; c4.Text = "ຜ"; c5.Text = "ປ"; c6.Text = "ແ"; c7.Text = "ອ"; c8.Text = "ຮ"; c9.Text = "ຄ"; c10.Text = "ທ"; c11.Text = "ມ"; c12.Text = "ງ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "ຝ"; d3.Text = "ົ"; d4.Text = "ວ"; d5.Text = "ຶ"; d6.Text = "ື"; d7.Text = "ຕ"; d8.Text = "ຖ"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = "ຈ"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "mi": // Māori (US QWERTY variant)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = ":"; c12.Text = "\""; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = ";"; c12.Text = "'"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;



                case "mk": // Macedonian (Cyrillic layout)
                    if (chk_shift.Checked) { a1.Text = "Љ"; a2.Text = "!"; a3.Text = "\""; a4.Text = "№"; a5.Text = ";"; a6.Text = "%"; a7.Text = ":"; a8.Text = "?"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Њ"; b3.Text = "Е"; b4.Text = "Р"; b5.Text = "Т"; b6.Text = "Ѕ"; b7.Text = "У"; b8.Text = "И"; b9.Text = "О"; b10.Text = "П"; b11.Text = "Ш"; b12.Text = "Ѓ"; b13.Text = "Ж"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "А"; c3.Text = "С"; c4.Text = "Д"; c5.Text = "Ф"; c6.Text = "Г"; c7.Text = "Х"; c8.Text = "Ј"; c9.Text = "К"; c10.Text = "Л"; c11.Text = "Ч"; c12.Text = "Ќ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "З"; d3.Text = "Џ"; c4.Text = "Ц"; d5.Text = "В"; d6.Text = "Б"; d7.Text = "Н"; d8.Text = "М"; d9.Text = "<"; d10.Text = ">"; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "љ"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "њ"; b3.Text = "е"; b4.Text = "р"; b5.Text = "т"; b6.Text = "ѕ"; b7.Text = "у"; b8.Text = "и"; b9.Text = "о"; b10.Text = "п"; b11.Text = "ш"; b12.Text = "ѓ"; b13.Text = "ж"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "а"; c3.Text = "с"; c4.Text = "д"; c5.Text = "ф"; c6.Text = "г"; c7.Text = "х"; c8.Text = "ј"; c9.Text = "к"; c10.Text = "л"; c11.Text = "ч"; c12.Text = "ќ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "з"; d3.Text = "џ"; d4.Text = "ц"; d5.Text = "в"; d6.Text = "б"; d7.Text = "н"; d8.Text = "м"; d9.Text = ","; d10.Text = "."; d11.Text = "."; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "mn": // Mongolian (Cyrillic layout)
                    if (chk_shift.Checked) { a1.Text = "Ё"; a2.Text = "!"; a3.Text = "\""; a4.Text = "№"; a5.Text = ";"; a6.Text = "%"; a7.Text = ":"; a8.Text = "?"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Ф"; b3.Text = "Ц"; b4.Text = "У"; b5.Text = "Ж"; b6.Text = "Э"; b7.Text = "Н"; b8.Text = "Г"; b9.Text = "Ш"; b10.Text = "Ү"; b11.Text = "З"; b12.Text = "К"; b13.Text = "Ъ"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "Й"; c3.Text = "Ы"; c4.Text = "Б"; c5.Text = "Ө"; c6.Text = "А"; c7.Text = "Х"; c8.Text = "Р"; c9.Text = "О"; c10.Text = "Л"; c11.Text = "Д"; c12.Text = "П"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Я"; d3.Text = "Ч"; c4.Text = "Е"; d5.Text = "М"; d6.Text = "И"; d7.Text = "Т"; d8.Text = "Ь"; d9.Text = "В"; d10.Text = "Ю"; d11.Text = "."; d12.Text = "Shift"; d13.Text = "С"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "ё"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "ф"; b3.Text = "ц"; b4.Text = "у"; b5.Text = "ж"; b6.Text = "э"; b7.Text = "н"; b8.Text = "г"; b9.Text = "ш"; b10.Text = "ү"; b11.Text = "з"; b12.Text = "к"; b13.Text = "ъ"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "й"; c3.Text = "ы"; c4.Text = "б"; c5.Text = "ө"; c6.Text = "а"; c7.Text = "х"; c8.Text = "р"; c9.Text = "о"; c10.Text = "л"; c11.Text = "д"; c12.Text = "п"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "я"; d3.Text = "ч"; d4.Text = "е"; d5.Text = "м"; d6.Text = "и"; d7.Text = "т"; d8.Text = "ь"; d9.Text = "в"; d10.Text = "ю"; d11.Text = ","; d12.Text = "Shift"; d13.Text = "с"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "mt": // Maltese (Maltese 48-key layout)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "Ġ"; b13.Text = "Ħ"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Ż"; c12.Text = "Č"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "ġ"; b13.Text = "ħ"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "ż"; c12.Text = "č"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "my": // Burmese (Myanmar layout)
                    if (chk_shift.Checked) { a1.Text = "ဍ"; a2.Text = "၁"; a3.Text = "၂"; a4.Text = "၃"; a5.Text = "၄"; a6.Text = "၅"; a7.Text = "၆"; a8.Text = "၇"; a9.Text = "၈"; a10.Text = "၉"; a11.Text = "၀"; a12.Text = "ဣ"; a13.Text = "ဤ"; b1.Text = "Tab"; b2.Text = "ဆ"; b3.Text = "တ"; b4.Text = "ထ"; b5.Text = "ဖ"; b6.Text = "ဗ"; b7.Text = "မ"; b8.Text = "အ"; b9.Text = "ဢ"; b10.Text = "ဩ"; b11.Text = "ဪ"; b12.Text = "ဥ"; b13.Text = "ဦ"; b14.Text = "ဧ"; c1.Text = "Caps"; c2.Text = "စ"; c3.Text = "တ�"; c4.Text = "ဌ"; c5.Text = "ဘ"; c6.Text = "ပ"; c7.Text = "န"; c8.Text = "ူ"; c9.Text = "ဳ"; c10.Text = "ဴ"; c11.Text = "ဵ"; c12.Text = "ံ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "ဇ"; d3.Text = "ဋ"; d4.Text = "ဍ"; d5.Text = "ဃ"; d6.Text = "င"; d7.Text = "ယ"; d8.Text = "ဉ"; d9.Text = "ဦ"; d10.Text = "ဲ"; d11.Text = "း"; d12.Text = "Shift"; d13.Text = "၏"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "့"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "း"; b3.Text = "ိ"; b4.Text = "ီ"; b5.Text = "်"; b6.Text = "ွ"; b7.Text = "ျ"; b8.Text = "ု"; b9.Text = "ီ"; b10.Text = "ူ"; b11.Text = "ဲ"; b12.Text = "ံ"; b13.Text = "့"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "စ"; c3.Text = "တ"; c4.Text = "ထ"; c5.Text = "ဖ"; c6.Text = "ဗ"; c7.Text = "မ"; c8.Text = "အ"; c9.Text = "က"; c10.Text = "လ"; c11.Text = "ှ"; c12.Text = "ျ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "ဇ"; d3.Text = "ဋ"; d4.Text = "ဍ"; d5.Text = "ဃ"; d6.Text = "င"; d7.Text = "ယ"; d8.Text = "ဉ"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = "ည"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "ne": // Nepali (InScript Devanagari layout)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "१"; a3.Text = "२"; a4.Text = "३"; a5.Text = "४"; a6.Text = "५"; a7.Text = "६"; a8.Text = "७"; a9.Text = "८"; a10.Text = "९"; a11.Text = "०"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "औ"; b3.Text = "ऐ"; b4.Text = "आ"; b5.Text = "ई"; b6.Text = "ऊ"; b7.Text = "भ"; b8.Text = "ङ"; b9.Text = "घ"; b10.Text = "ध"; b11.Text = "झ"; b12.Text = "ढ"; b13.Text = "ञ"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "ओ"; c3.Text = "ए"; c4.Text = "अ"; c5.Text = "इ"; c6.Text = "उ"; c7.Text = "फ"; c8.Text = "ड़"; c9.Text = "ख"; c10.Text = "थ"; c11.Text = "छ"; c12.Text = "ठ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "ऍ"; d3.Text = "ं"; d4.Text = "ः"; d5.Text = "म"; d6.Text = "न"; d7.Text = "ण"; d8.Text = "व"; d9.Text = "ल"; d10.Text = "श"; d11.Text = "ष"; d12.Text = "Shift"; d13.Text = "ळ"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "ौ"; b3.Text = "ै"; b4.Text = "ा"; b5.Text = "ी"; b6.Text = "ू"; b7.Text = "ब"; b8.Text = "ह"; b9.Text = "ग"; b10.Text = "द"; b11.Text = "ज"; b12.Text = "ड"; b13.Text = "ृ"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "ो"; c3.Text = "े"; c4.Text = "्"; c5.Text = "ि"; c6.Text = "ु"; c7.Text = "प"; c8.Text = "र"; c9.Text = "क"; c10.Text = "त"; c11.Text = "च"; c12.Text = "ट"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "ॅ"; d3.Text = "ं"; d4.Text = "स"; d5.Text = "म"; d6.Text = "न"; d7.Text = "व"; d8.Text = "ल"; d9.Text = "स"; d10.Text = ","; d11.Text = "."; d12.Text = "Shift"; d13.Text = "य"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;



                case "nn": // Norwegian Nynorsk (Norwegian QWERTY)
                    if (chk_shift.Checked) { a1.Text = "½"; a2.Text = "!"; a3.Text = "\""; a4.Text = "#"; a5.Text = "¤"; a6.Text = "%"; a7.Text = "&"; a8.Text = "/"; a9.Text = "("; a10.Text = ")"; a11.Text = "="; a12.Text = "?"; a13.Text = "*"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "Å"; b13.Text = "^"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Ø"; c12.Text = "Æ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = ";"; d10.Text = ":"; d11.Text = "_"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "§"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "+"; a13.Text = "\\"; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "å"; b13.Text = "¨"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "ø"; c12.Text = "æ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "-"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "nso": // Sesotho sa Leboa (US QWERTY variant)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = ":"; c12.Text = "\""; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = ";"; c12.Text = "'"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "or": // Odia (InScript layout)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "୧"; a3.Text = "୨"; a4.Text = "୩"; a5.Text = "୪"; a6.Text = "୫"; a7.Text = "୬"; a8.Text = "୭"; a9.Text = "୮"; a10.Text = "୯"; a11.Text = "୦"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "ଔ"; b3.Text = "ଐ"; b4.Text = "ଆ"; b5.Text = "ଈ"; b6.Text = "ଊ"; b7.Text = "ଭ"; b8.Text = "ଙ"; b9.Text = "ଘ"; b10.Text = "ଧ"; b11.Text = "ଝ"; b12.Text = "ଢ"; b13.Text = "ଞ"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "ଓ"; c3.Text = "ଏ"; c4.Text = "ଅ"; c5.Text = "ଇ"; c6.Text = "ଉ"; c7.Text = "ଫ"; c8.Text = "ର"; c9.Text = "ଖ"; c10.Text = "ଥ"; c11.Text = "ଛ"; c12.Text = "ଠ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "ଁ"; d3.Text = "ଂ"; d4.Text = "ଃ"; d5.Text = "ମ"; d6.Text = "ନ"; d7.Text = "ଣ"; d8.Text = "ବ"; d9.Text = "ଲ"; d10.Text = "ଶ"; d11.Text = "ଷ"; d12.Text = "Shift"; d13.Text = "ଯ"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "ୌ"; b3.Text = "ୈ"; b4.Text = "ା"; b5.Text = "ୀ"; b6.Text = "ୂ"; b7.Text = "ବ"; b8.Text = "ହ"; b9.Text = "ଗ"; b10.Text = "ଦ"; b11.Text = "ଜ"; b12.Text = "ଡ"; b13.Text = "ୃ"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "ୋ"; c3.Text = "େ"; c4.Text = "୍"; c5.Text = "ି"; c6.Text = "ୁ"; c7.Text = "ପ"; c8.Text = "ର"; c9.Text = "କ"; c10.Text = "ତ"; c11.Text = "ଚ"; c12.Text = "ଟ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "ୢ"; d3.Text = "ଂ"; d4.Text = "ସ"; d5.Text = "ମ"; d6.Text = "ନ"; d7.Text = "ଵ"; d8.Text = "ଲ"; d9.Text = "ସ"; d10.Text = ","; d11.Text = "."; d12.Text = "Shift"; d13.Text = "ୟ"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "ps": // Pashto (Arabic script layout)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = ")"; a11.Text = "("; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "ض"; b3.Text = "ص"; b4.Text = "ث"; b5.Text = "ق"; b6.Text = "ف"; b7.Text = "غ"; b8.Text = "ع"; b9.Text = "ه"; b10.Text = "خ"; b11.Text = "ح"; b12.Text = "ج"; b13.Text = "چ"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "ش"; c3.Text = "س"; c4.Text = "ی"; c5.Text = "ب"; c6.Text = "ل"; c7.Text = "ا"; c8.Text = "ت"; c9.Text = "ن"; c10.Text = "م"; c11.Text = "ک"; c12.Text = "ګ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "ظ"; d3.Text = "ط"; d4.Text = "ذ"; d5.Text = "د"; d6.Text = "ز"; d7.Text = "ر"; d8.Text = "و"; d9.Text = "،"; d10.Text = "."; d11.Text = "?"; d12.Text = "Shift"; d13.Text = "پ"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "۱"; a3.Text = "۲"; a4.Text = "۳"; a5.Text = "۴"; a6.Text = "۵"; a7.Text = "۶"; a8.Text = "۷"; a9.Text = "۸"; a10.Text = "۹"; a11.Text = "۰"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "ض"; b3.Text = "ص"; b4.Text = "ث"; b5.Text = "ق"; b6.Text = "ف"; b7.Text = "غ"; b8.Text = "ع"; b9.Text = "ه"; b10.Text = "خ"; b11.Text = "ح"; b12.Text = "ج"; b13.Text = "چ"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "ش"; c3.Text = "س"; c4.Text = "ي"; c5.Text = "ب"; c6.Text = "ل"; c7.Text = "ا"; c8.Text = "ت"; c9.Text = "ن"; c10.Text = "م"; c11.Text = "ک"; c12.Text = "ګ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "ظ"; d3.Text = "ط"; d4.Text = "ذ"; d5.Text = "د"; d6.Text = "ز"; d7.Text = "ر"; d8.Text = "و"; d9.Text = "،"; d10.Text = "٫"; d11.Text = "/"; d12.Text = "Shift"; d13.Text = "پ"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "quz": // Quechua (Spanish QWERTY variant)
                    if (chk_shift.Checked) { a1.Text = "¬"; a2.Text = "!"; a3.Text = "\""; a4.Text = "·"; a5.Text = "$"; a6.Text = "%"; a7.Text = "&"; a8.Text = "/"; a9.Text = "("; a10.Text = ")"; a11.Text = "="; a12.Text = "?"; a13.Text = "¿"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "`"; b13.Text = "^"; b14.Text = "*"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Ñ"; c12.Text = "´"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = ";"; d10.Text = ":"; d11.Text = "_"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "|"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "'"; a13.Text = "¡"; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "¨"; b13.Text = "["; b14.Text = "]"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "ñ"; c12.Text = "´"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "-"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;


                    ;

                case "rw": // Kinyarwanda (US QWERTY variant)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = ":"; c12.Text = "\""; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = ";"; c12.Text = "'"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "si": // Sinhala (Sinhala Wij 9 layout)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "ෲ"; a3.Text = "ෟ"; a4.Text = "෮"; a5.Text = "෯"; a6.Text = "෴"; a7.Text = "෥"; a8.Text = "෭"; a9.Text = "෬"; a10.Text = "෫"; a11.Text = "෪"; a12.Text = "෩"; a13.Text = "෨"; b1.Text = "Tab"; b2.Text = "ඔ"; b3.Text = "එ"; b4.Text = "ඒ"; b5.Text = "ඈ"; b6.Text = "ඌ"; b7.Text = "ඖ"; b8.Text = "අ"; b9.Text = "උ"; b10.Text = "ඍ"; b11.Text = "ඎ"; b12.Text = "ඓ"; b13.Text = "ඕ"; b14.Text = "ඐ"; c1.Text = "Caps"; c2.Text = "ආ"; c3.Text = "ඉ"; c4.Text = "ඊ"; c5.Text = "ඏ"; c6.Text = "ඒ"; c7.Text = "ඓ"; c8.Text = "අ"; c9.Text = "උ"; c10.Text = "ඍ"; c11.Text = "ඎ"; c12.Text = "ඓ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "ඞ"; d3.Text = "ඟ"; d4.Text = "ඦ"; d5.Text = "ඥ"; d6.Text = "ඤ"; d7.Text = "ට"; d8.Text = "ඬ"; d9.Text = "ඳ"; d10.Text = "ථ"; d11.Text = "ශ"; d12.Text = "Shift"; d13.Text = "ෂ"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "ඹ"; b3.Text = "ඡ"; b4.Text = "ජ"; b5.Text = "ර"; b6.Text = "ත"; b7.Text = "ය"; b8.Text = "බ"; b9.Text = "ල"; b10.Text = "ව"; b11.Text = "ශ"; b12.Text = "ෂ"; b13.Text = "ළ"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "ස"; c3.Text = "හ"; c4.Text = "ද"; c5.Text = "ප"; c6.Text = "ග"; c7.Text = "ක"; c8.Text = "ච"; c9.Text = "ට"; c10.Text = "න"; c11.Text = "ම"; c12.Text = "ඩ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "ෆ"; d3.Text = "ඥ"; d4.Text = "ඳ"; d5.Text = "භ"; d6.Text = "ධ"; d7.Text = "ථ"; d8.Text = "ඝ"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = "ඤ"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "sq": // Albanian (Albanian QWERTY)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "Ç"; b13.Text = "Ë"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "X"; c12.Text = "ZH"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "ç"; b13.Text = "ë"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "x"; c12.Text = "zh"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "sr": // Serbian (Cyrillic layout)
                    if (chk_shift.Checked) { a1.Text = "Љ"; a2.Text = "!"; a3.Text = "\""; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Њ"; b3.Text = "Е"; b4.Text = "Р"; b5.Text = "Т"; b6.Text = "З"; b7.Text = "У"; b8.Text = "И"; b9.Text = "О"; b10.Text = "П"; b11.Text = "Ш"; b12.Text = "Ђ"; b13.Text = "Ж"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "А"; c3.Text = "С"; c4.Text = "Д"; c5.Text = "Ф"; c6.Text = "Г"; c7.Text = "Х"; c8.Text = "Ј"; c9.Text = "К"; c10.Text = "Л"; c11.Text = "Ч"; c12.Text = "Ћ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Ѕ"; d3.Text = "Џ"; d4.Text = "Ц"; d5.Text = "В"; d6.Text = "Б"; d7.Text = "Н"; d8.Text = "М"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "љ"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "њ"; b3.Text = "е"; b4.Text = "р"; b5.Text = "т"; b6.Text = "з"; b7.Text = "у"; b8.Text = "и"; b9.Text = "о"; b10.Text = "п"; b11.Text = "ш"; b12.Text = "ђ"; b13.Text = "ж"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "а"; c3.Text = "с"; c4.Text = "д"; c5.Text = "ф"; c6.Text = "г"; c7.Text = "х"; c8.Text = "ј"; c9.Text = "к"; c10.Text = "л"; c11.Text = "ч"; c12.Text = "ћ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "ѕ"; d3.Text = "џ"; d4.Text = "ц"; d5.Text = "в"; d6.Text = "б"; d7.Text = "н"; d8.Text = "м"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;




                case "tg": // Tajik (Cyrillic layout)
                    if (chk_shift.Checked) { a1.Text = "Ё"; a2.Text = "!"; a3.Text = "\""; a4.Text = "№"; a5.Text = ";"; a6.Text = "%"; a7.Text = ":"; a8.Text = "?"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Й"; b3.Text = "Ц"; b4.Text = "У"; b5.Text = "К"; b6.Text = "Е"; b7.Text = "Н"; b8.Text = "Г"; b9.Text = "Ш"; b10.Text = "Щ"; b11.Text = "З"; b12.Text = "Х"; b13.Text = "Ъ"; b14.Text = "Ғ"; c1.Text = "Caps"; c2.Text = "Ф"; c3.Text = "Ы"; c4.Text = "В"; c5.Text = "А"; c6.Text = "П"; c7.Text = "Р"; c8.Text = "О"; c9.Text = "Л"; c10.Text = "Д"; c11.Text = "Ж"; c12.Text = "Э"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Я"; d3.Text = "Ч"; d4.Text = "С"; d5.Text = "М"; d6.Text = "И"; d7.Text = "Т"; d8.Text = "Ь"; d9.Text = "Б"; d10.Text = "Ю"; d11.Text = "Ҳ"; d12.Text = "Shift"; d13.Text = "Қ"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "ё"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "й"; b3.Text = "ц"; b4.Text = "у"; b5.Text = "к"; b6.Text = "е"; b7.Text = "н"; b8.Text = "г"; b9.Text = "ш"; b10.Text = "щ"; b11.Text = "з"; b12.Text = "х"; b13.Text = "ъ"; b14.Text = "ғ"; c1.Text = "Caps"; c2.Text = "ф"; c3.Text = "ы"; c4.Text = "в"; c5.Text = "а"; c6.Text = "п"; c7.Text = "р"; c8.Text = "о"; c9.Text = "л"; c10.Text = "д"; c11.Text = "ж"; c12.Text = "э"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "я"; d3.Text = "ч"; d4.Text = "с"; d5.Text = "м"; d6.Text = "и"; d7.Text = "т"; d8.Text = "ь"; d9.Text = "б"; d10.Text = "ю"; d11.Text = "ҳ"; d12.Text = "Shift"; d13.Text = "қ"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;



                case "tk": // Turkmen (Turkmen QWERTY)
                    if (chk_shift.Checked) { a1.Text = "¨"; a2.Text = "!"; a3.Text = "\""; a4.Text = "№"; a5.Text = ";"; a6.Text = "%"; a7.Text = ":"; a8.Text = "?"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "Ü"; b13.Text = "Ý"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "Ş"; c12.Text = "Ň"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "/"; d12.Text = "Shift"; d13.Text = "Ž"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "ü"; b13.Text = "ý"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "ş"; c12.Text = "ň"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "."; d12.Text = "Shift"; d13.Text = "ž"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "tn": // Setswana (US QWERTY variant)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = ":"; c12.Text = "\""; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = ";"; c12.Text = "'"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "tt": // Tatar (Cyrillic layout)
                    if (chk_shift.Checked) { a1.Text = "Ё"; a2.Text = "!"; a3.Text = "\""; a4.Text = "№"; a5.Text = ";"; a6.Text = "%"; a7.Text = ":"; a8.Text = "?"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Й"; b3.Text = "Ц"; b4.Text = "У"; b5.Text = "К"; b6.Text = "Е"; b7.Text = "Н"; b8.Text = "Г"; b9.Text = "Ш"; b10.Text = "Щ"; b11.Text = "З"; b12.Text = "Х"; b13.Text = "Ъ"; b14.Text = "Ә"; c1.Text = "Caps"; c2.Text = "Ф"; c3.Text = "Ы"; c4.Text = "В"; c5.Text = "А"; c6.Text = "П"; c7.Text = "Р"; c8.Text = "О"; c9.Text = "Л"; c10.Text = "Д"; c11.Text = "Ж"; c12.Text = "Э"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Я"; d3.Text = "Ч"; d4.Text = "С"; d5.Text = "М"; d6.Text = "И"; d7.Text = "Т"; d8.Text = "Ь"; d9.Text = "Б"; d10.Text = "Ю"; d11.Text = "Җ"; d12.Text = "Shift"; d13.Text = "Һ"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "ё"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "й"; b3.Text = "ц"; b4.Text = "у"; b5.Text = "к"; b6.Text = "е"; b7.Text = "н"; b8.Text = "г"; b9.Text = "ш"; b10.Text = "щ"; b11.Text = "з"; b12.Text = "х"; b13.Text = "ъ"; b14.Text = "ә"; c1.Text = "Caps"; c2.Text = "ф"; c3.Text = "ы"; c4.Text = "в"; c5.Text = "а"; c6.Text = "п"; c7.Text = "р"; c8.Text = "о"; c9.Text = "л"; c10.Text = "д"; c11.Text = "ж"; c12.Text = "э"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "я"; d3.Text = "ч"; d4.Text = "с"; d5.Text = "м"; d6.Text = "и"; d7.Text = "т"; d8.Text = "ь"; d9.Text = "б"; d10.Text = "ю"; d11.Text = "җ"; d12.Text = "Shift"; d13.Text = "һ"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;



                case "ug": // Uyghur (Arabic script layout)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = ")"; a11.Text = "("; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "چ"; b3.Text = "ش"; b4.Text = "غ"; b5.Text = "ف"; b6.Text = "ق"; b7.Text = "ك"; b8.Text = "گ"; b9.Text = "ڭ"; b10.Text = "ل"; b11.Text = "ھ"; b12.Text = "ئ"; b13.Text = "ؤ"; b14.Text = "ۇ"; c1.Text = "Caps"; c2.Text = "ا"; c3.Text = "ە"; c4.Text = "ب"; c5.Text = "پ"; c6.Text = "ت"; c7.Text = "ج"; c8.Text = "ھ"; c9.Text = "د"; c10.Text = "ر"; c11.Text = "ز"; c12.Text = "ژ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "س"; d3.Text = "ى"; d4.Text = "ن"; d5.Text = "م"; d6.Text = "و"; d7.Text = "ې"; d8.Text = "ي"; d9.Text = "،"; d10.Text = "."; d11.Text = "?"; d12.Text = "Shift"; d13.Text = "خ"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "١"; a3.Text = "٢"; a4.Text = "٣"; a5.Text = "٤"; a6.Text = "٥"; a7.Text = "٦"; a8.Text = "٧"; a9.Text = "٨"; a10.Text = "٩"; a11.Text = "٠"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "چ"; b3.Text = "ش"; b4.Text = "غ"; b5.Text = "ف"; b6.Text = "ق"; b7.Text = "ك"; b8.Text = "گ"; b9.Text = "ڭ"; b10.Text = "ل"; b11.Text = "ھ"; b12.Text = "ئ"; b13.Text = "ؤ"; b14.Text = "ۇ"; c1.Text = "Caps"; c2.Text = "ا"; c3.Text = "ە"; c4.Text = "ب"; c5.Text = "پ"; c6.Text = "ت"; c7.Text = "ج"; c8.Text = "ھ"; c9.Text = "د"; c10.Text = "ر"; c11.Text = "ز"; c12.Text = "ژ"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "س"; d3.Text = "ى"; d4.Text = "ن"; d5.Text = "م"; d6.Text = "و"; d7.Text = "ې"; d8.Text = "ي"; d9.Text = "،"; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = "خ"; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "uz": // Uzbek (Latin QWERTY)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "SH"; b13.Text = "CH"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "O‘"; c12.Text = "G‘"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "sh"; b13.Text = "ch"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "o‘"; c12.Text = "g‘"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "wo": // Wolof (French QWERTY variant)
                    if (chk_shift.Checked) { a1.Text = "¬"; a2.Text = "!"; a3.Text = "\""; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "A"; b3.Text = "Z"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "¨"; b13.Text = "£"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "Q"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = "M"; c12.Text = "Ù"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "W"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "?"; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "a"; b3.Text = "z"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "^"; b13.Text = "$"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "q"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = "m"; c12.Text = "ù"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "w"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = ";"; d11.Text = ":"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "xh": // Xhosa (US QWERTY variant)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = ":"; c12.Text = "\""; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = ";"; c12.Text = "'"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "yo": // Yoruba (US QWERTY variant)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = ":"; c12.Text = "\""; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = ";"; c12.Text = "'"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;


                case "zh-CHT": // Chinese (Traditional, Taiwan) - US QWERTY base
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = ":"; c12.Text = "\""; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = ";"; c12.Text = "'"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;

                case "zu": // Zulu (US QWERTY variant)
                    if (chk_shift.Checked) { a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+"; b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|"; c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = ":"; c12.Text = "\""; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    else { a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "="; b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\"; c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = ";"; c12.Text = "'"; c13.Text = "Enter"; d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = ""; e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; }
                    break;


                default: // Fallback layout (similar to en-US)
                    if (chk_shift.Checked)
                    {
                        a1.Text = "~"; a2.Text = "!"; a3.Text = "@"; a4.Text = "#"; a5.Text = "$"; a6.Text = "%"; a7.Text = "^"; a8.Text = "&"; a9.Text = "*"; a10.Text = "("; a11.Text = ")"; a12.Text = "_"; a13.Text = "+";
                        b1.Text = "Tab"; b2.Text = "Q"; b3.Text = "W"; b4.Text = "E"; b5.Text = "R"; b6.Text = "T"; b7.Text = "Y"; b8.Text = "U"; b9.Text = "I"; b10.Text = "O"; b11.Text = "P"; b12.Text = "{"; b13.Text = "}"; b14.Text = "|";
                        c1.Text = "Caps"; c2.Text = "A"; c3.Text = "S"; c4.Text = "D"; c5.Text = "F"; c6.Text = "G"; c7.Text = "H"; c8.Text = "J"; c9.Text = "K"; c10.Text = "L"; c11.Text = ":"; c12.Text = "\""; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "Z"; d3.Text = "X"; d4.Text = "C"; d5.Text = "V"; d6.Text = "B"; d7.Text = "N"; d8.Text = "M"; d9.Text = "<"; d10.Text = ">"; d11.Text = "?"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    else
                    {
                        a1.Text = "`"; a2.Text = "1"; a3.Text = "2"; a4.Text = "3"; a5.Text = "4"; a6.Text = "5"; a7.Text = "6"; a8.Text = "7"; a9.Text = "8"; a10.Text = "9"; a11.Text = "0"; a12.Text = "-"; a13.Text = "=";
                        b1.Text = "Tab"; b2.Text = "q"; b3.Text = "w"; b4.Text = "e"; b5.Text = "r"; b6.Text = "t"; b7.Text = "y"; b8.Text = "u"; b9.Text = "i"; b10.Text = "o"; b11.Text = "p"; b12.Text = "["; b13.Text = "]"; b14.Text = "\\";
                        c1.Text = "Caps"; c2.Text = "a"; c3.Text = "s"; c4.Text = "d"; c5.Text = "f"; c6.Text = "g"; c7.Text = "h"; c8.Text = "j"; c9.Text = "k"; c10.Text = "l"; c11.Text = ";"; c12.Text = "'"; c13.Text = "Enter"; c14.Text = "";
                        d1.Text = "Shift"; d2.Text = "z"; d3.Text = "x"; d4.Text = "c"; d5.Text = "v"; d6.Text = "b"; d7.Text = "n"; d8.Text = "m"; d9.Text = ","; d10.Text = "."; d11.Text = "/"; d12.Text = "Shift"; d13.Text = ""; d14.Text = "";
                        e1.Text = "Ctrl"; e2.Text = "Alt"; e3.Text = "Space"; e4.Text = "Alt"; e5.Text = "Ctrl"; e6.Text = ""; e7.Text = ""; e8.Text = ""; e9.Text = ""; e10.Text = ""; e11.Text = ""; e12.Text = ""; e13.Text = ""; e14.Text = "";
                    }
                    break;



            }

            // Force UI refresh
            this.Refresh();
        }


        /*
         * 
         a1 -- a13
        b1 -- b14
        c1 -- c14
        d1 -- d14
        e1 -- e14
         目前有按鍵，如上。
         請依照各語言，完成對照表。參照微軟鍵盤，完成下列方法，可多個指令在同一行，減少行數。
        目前已涵蓋 40 種語言 (en-US, vi-VN, de-DE, ar-SA, zh-CN, fr-FR, ru-RU, ja-JP, es-ES, it-IT, ko-KR, pt-PT, pl-PL, tr-TR, th-TH, hi-IN, nl-NL, sv-SE, uk-UA, el-GR, cs-CZ, hu-HU, he-IL, ro-RO, bg-BG, fi-FI, no-NO, id-ID, sk-SK, sl-SI, ms-MY, bn-BD, ta-IN, te-IN, ur-PK, gu-IN, kn-IN, ml-IN, pa-IN, mr-IN)。

         */

        // 需要更多語言，巳生成的，不需要重覆。








        private void UpdateButtonVisibility(string language)
        {
            foreach (Control control in tableLayoutPanel.Controls)
            {
                if (control is Button btn && btn != btn_space && btn != btn_clear && btn != btn_cancel &&
                    btn != btn_OK && btn != btn_backspace && btn != btn_lang && btn != btnApos)
                {
                    btn.Visible = false; // Hide all buttons by default
                }
            }

            switch (language)
            {
                case "af": // Afrikaans (US QWERTY variant)
                case "en": // English (US QWERTY)
                case "fil": // Filipino
                case "haG": // Hausa (Latin)
                case "id": // Indonesian
                case "ig": // Igbo
                case "ms": // Malay
                case "nso": // Sesotho sa Leboa
                case "rw": // Kinyarwanda
                case "sw": // Swahili
                case "tn": // Setswana
                case "xh": // Xhosa
                case "yo": // Yoruba
                case "zh-CHT": // Chinese (Traditional, Taiwan) - US QWERTY base
                case "zh-CHS": // Chinese (Traditional, Taiwan) - US QWERTY base
                case "zu": // Zulu
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true;
                    break;

                case "am": // Amharic (Ethiopic layout)
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true; d13.Visible = true;
                    break;

                case "ar": // Arabic
                case "ku": // Kurdish (Arabic)
                case "ps": // Pashto
                case "ug": // Uyghur
                case "ur": // Urdu
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true; d13.Visible = true;
                    break;

                case "as": // Assamese (InScript layout)
                case "bn": // Bengali (Bangladesh)
                case "gu": // Gujarati
                case "hi": // Hindi
                case "kn": // Kannada
                case "kok": // Konkani
                case "ml": // Malayalam
                case "mr": // Marathi
                case "ne": // Nepali
                case "or": // Odia
                case "pa": // Punjabi
                case "ta": // Tamil
                case "te": // Telugu
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true; d13.Visible = true;
                    break;

                case "az": // Azerbaijani (Latin)
                case "bs": // Bosnian (Latin)
                case "hr": // Croatian
                case "sl": // Slovenian
                case "tk": // Turkmen
                case "uz": // Uzbek (Latin)
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true; d13.Visible = true;
                    break;

                case "be": // Belarusian
                case "ky": // Kyrgyz
                case "mk": // Macedonian
                case "mn": // Mongolian
                case "sr": // Serbian (Cyrillic)
                case "tg": // Tajik (Cyrillic)
                case "tt": // Tatar
                case "uk": // Ukrainian
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true;
                    break;

                case "bg": // Bulgarian
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true; d13.Visible = true;
                    break;

                case "ca": // Catalan
                case "es": // Spanish (Spain)
                case "eu": // Basque
                case "gl": // Galician
                case "pt": // Portuguese (Portugal)
                case "quz": // Quechua
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true;
                    break;

                case "cs": // Czech
                case "hu": // Hungarian
                case "sk": // Slovak
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true;
                    break;

                case "cy": // Welsh
                case "ga": // Irish
                case "gd": // Scottish Gaelic
                case "mt": // Maltese
                case "sq": // Albanian
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true;
                    break;

                case "da": // Danish
                case "nb": // Norwegian Bokmål
                case "nn": // Norwegian Nynorsk
                case "sv": // Swedish
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true;
                    break;

                case "de": // German
                case "lb": // Luxembourgish
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true;
                    break;

                case "el": // Greek
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true;
                    break;

                case "et": // Estonian
                case "fi": // Finnish
                case "lt": // Lithuanian
                case "lv": // Latvian
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true;
                    break;

                case "fa": // Persian
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true; d13.Visible = true;
                    break;

                case "fr": // French (France)
                case "wo": // Wolof
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true;
                    break;

                case "he": // Hebrew
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true;
                    break;

                case "hy": // Armenian
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true;
                    break;

                case "is": // Icelandic
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true;
                    break;

                case "it": // Italian
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true;
                    break;

                case "ja": // Japanese (US QWERTY base)
                case "ko": // Korean (US QWERTY base)
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true;
                    break;

                case "ka": // Georgian
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true;
                    break;

                case "kk": // Kazakh
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true; d13.Visible = true;
                    break;

                case "km": // Khmer
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true; d13.Visible = true;
                    break;

                case "lo": // Lao
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true; d13.Visible = true;
                    break;

                case "mi": // Maori
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true;
                    break;

                case "my": // Burmese
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true; d13.Visible = true;
                    break;

                case "nl": // Dutch
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true;
                    break;

                case "pl": // Polish
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true; d13.Visible = true;
                    break;

                case "ro": // Romanian
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true; d13.Visible = true;
                    break;

                case "ru": // Russian
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true;
                    break;

                case "si": // Sinhala
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true; d13.Visible = true;
                    break;

                case "th": // Thai
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true; d13.Visible = true;
                    break;

                case "tr": // Turkish
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true; d13.Visible = true;
                    break;

                case "viVN": // Vietnamese
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true;
                    break;

                default: // Fallback for unhandled languages
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; a12.Visible = true; a13.Visible = true; b2.Visible = true; b3.Visible = true;
                    b4.Visible = true; b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true;
                    b9.Visible = true; b10.Visible = true; b11.Visible = true; b12.Visible = true; b13.Visible = true;
                    b14.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true; c5.Visible = true;
                    c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true; c10.Visible = true;
                    c11.Visible = true; c12.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; d11.Visible = true;
                    break;
            }
        }










        private void Btn_space_Click(object sender, EventArgs e)
        {
            RaiseButtonPressed(' ');
        }
        private void Btn_backspace_Click(object sender, EventArgs e)
        {
            RaiseButtonPressed('\u0008');
        }
        private void Btn_clear_Click(object sender, EventArgs e)
        {
            RaiseButtonPressed('\u0005');
        }
        private void Btn_cancel_Click(object sender, EventArgs e)
        {
            RaiseButtonPressed('\u0027');
        }
        private void Btn_OK_Click(object sender, EventArgs e)
        {
            RaiseButtonPressed('\u0004');
        }
        private void button7_Click(object sender, EventArgs e)
        {
        }

        private void tableLayoutPanel_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}