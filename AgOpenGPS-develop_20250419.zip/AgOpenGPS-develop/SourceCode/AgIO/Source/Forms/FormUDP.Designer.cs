﻿namespace AgIO
{
    partial class FormUDP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelCurrentSubnet = new System.Windows.Forms.Label();
            this.lblNetworkHelp = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.labelNewSubnet = new System.Windows.Forms.Label();
            this.nudFirstIP = new System.Windows.Forms.NumericUpDown();
            this.nudSecndIP = new System.Windows.Forms.NumericUpDown();
            this.nudThirdIP = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelSetSubnet = new System.Windows.Forms.Label();
            this.labelModuleScan = new System.Windows.Forms.Label();
            this.tboxNets = new System.Windows.Forms.TextBox();
            this.labelHostName = new System.Windows.Forms.Label();
            this.lblHostname = new System.Windows.Forms.Label();
            this.labelNoAdapter = new System.Windows.Forms.Label();
            this.cboxUp = new System.Windows.Forms.CheckBox();
            this.labelFilter = new System.Windows.Forms.Label();
            this.labelScanning = new System.Windows.Forms.Label();
            this.labelIPAddress = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lblBtnIMU = new System.Windows.Forms.Label();
            this.lblBtnGPS = new System.Windows.Forms.Label();
            this.labelIMU = new System.Windows.Forms.Label();
            this.lblIMU_IP = new System.Windows.Forms.Label();
            this.lblBtnMachine = new System.Windows.Forms.Label();
            this.labelSteer = new System.Windows.Forms.Label();
            this.lblGPSIP = new System.Windows.Forms.Label();
            this.lblSteerIP = new System.Windows.Forms.Label();
            this.lblBtnSteer = new System.Windows.Forms.Label();
            this.labelMachine = new System.Windows.Forms.Label();
            this.lblMachineIP = new System.Windows.Forms.Label();
            this.labelGPS = new System.Windows.Forms.Label();
            this.lblNewSubnet = new System.Windows.Forms.Label();
            this.labelUDPMonitor = new System.Windows.Forms.Label();
            this.btnSerialMonitor = new System.Windows.Forms.Button();
            this.btnNetworkCPL = new System.Windows.Forms.Button();
            this.btnUDPOff = new System.Windows.Forms.Button();
            this.btnSendSubnet = new System.Windows.Forms.Button();
            this.btnSerialCancel = new System.Windows.Forms.Button();
            this.pboxSendSteer = new System.Windows.Forms.PictureBox();
            this.btnAutoSet = new System.Windows.Forms.Button();
            this.labelUDPOff = new System.Windows.Forms.Label();
            this.labelNetworkProp = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nudFirstIP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSecndIP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudThirdIP)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pboxSendSteer)).BeginInit();
            this.SuspendLayout();
            // 
            // labelCurrentSubnet
            // 
            this.labelCurrentSubnet.AutoSize = true;
            this.labelCurrentSubnet.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCurrentSubnet.Location = new System.Drawing.Point(453, 550);
            this.labelCurrentSubnet.Name = "labelCurrentSubnet";
            this.labelCurrentSubnet.Size = new System.Drawing.Size(139, 23);
            this.labelCurrentSubnet.TabIndex = 144;
            this.labelCurrentSubnet.Text = "Current Subnet";
            this.labelCurrentSubnet.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNetworkHelp
            // 
            this.lblNetworkHelp.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblNetworkHelp.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNetworkHelp.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblNetworkHelp.Location = new System.Drawing.Point(376, 500);
            this.lblNetworkHelp.Name = "lblNetworkHelp";
            this.lblNetworkHelp.Size = new System.Drawing.Size(279, 46);
            this.lblNetworkHelp.TabIndex = 143;
            this.lblNetworkHelp.Text = "192 . 168 . 123  .  x";
            this.lblNetworkHelp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // labelNewSubnet
            // 
            this.labelNewSubnet.AutoSize = true;
            this.labelNewSubnet.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNewSubnet.Location = new System.Drawing.Point(395, 370);
            this.labelNewSubnet.Name = "labelNewSubnet";
            this.labelNewSubnet.Size = new System.Drawing.Size(236, 23);
            this.labelNewSubnet.TabIndex = 147;
            this.labelNewSubnet.Text = "Enter New Subnet Address";
            this.labelNewSubnet.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nudFirstIP
            // 
            this.nudFirstIP.BackColor = System.Drawing.Color.White;
            this.nudFirstIP.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudFirstIP.Location = new System.Drawing.Point(338, 398);
            this.nudFirstIP.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudFirstIP.Name = "nudFirstIP";
            this.nudFirstIP.Size = new System.Drawing.Size(102, 40);
            this.nudFirstIP.TabIndex = 148;
            this.nudFirstIP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nudFirstIP.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            this.nudFirstIP.Value = new decimal(new int[] {
            192,
            0,
            0,
            0});
            this.nudFirstIP.Click += new System.EventHandler(this.nudFirstIP_Click);
            // 
            // nudSecndIP
            // 
            this.nudSecndIP.BackColor = System.Drawing.Color.White;
            this.nudSecndIP.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudSecndIP.Location = new System.Drawing.Point(455, 398);
            this.nudSecndIP.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudSecndIP.Name = "nudSecndIP";
            this.nudSecndIP.Size = new System.Drawing.Size(102, 40);
            this.nudSecndIP.TabIndex = 149;
            this.nudSecndIP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nudSecndIP.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            this.nudSecndIP.Value = new decimal(new int[] {
            168,
            0,
            0,
            0});
            this.nudSecndIP.Click += new System.EventHandler(this.nudFirstIP_Click);
            // 
            // nudThirdIP
            // 
            this.nudThirdIP.BackColor = System.Drawing.Color.White;
            this.nudThirdIP.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudThirdIP.Location = new System.Drawing.Point(572, 398);
            this.nudThirdIP.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudThirdIP.Name = "nudThirdIP";
            this.nudThirdIP.Size = new System.Drawing.Size(102, 40);
            this.nudThirdIP.TabIndex = 150;
            this.nudThirdIP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nudThirdIP.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            this.nudThirdIP.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nudThirdIP.Click += new System.EventHandler(this.nudFirstIP_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(438, 392);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 35);
            this.label2.TabIndex = 152;
            this.label2.Text = ".";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(555, 392);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(24, 35);
            this.label3.TabIndex = 153;
            this.label3.Text = ".";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelSetSubnet
            // 
            this.labelSetSubnet.AutoSize = true;
            this.labelSetSubnet.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSetSubnet.Location = new System.Drawing.Point(697, 455);
            this.labelSetSubnet.Name = "labelSetSubnet";
            this.labelSetSubnet.Size = new System.Drawing.Size(103, 23);
            this.labelSetSubnet.TabIndex = 157;
            this.labelSetSubnet.Text = "Set Subnet";
            this.labelSetSubnet.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelModuleScan
            // 
            this.labelModuleScan.AutoSize = true;
            this.labelModuleScan.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelModuleScan.Location = new System.Drawing.Point(319, 10);
            this.labelModuleScan.Name = "labelModuleScan";
            this.labelModuleScan.Size = new System.Drawing.Size(118, 23);
            this.labelModuleScan.TabIndex = 161;
            this.labelModuleScan.Text = "Module Scan";
            this.labelModuleScan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tboxNets
            // 
            this.tboxNets.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tboxNets.Location = new System.Drawing.Point(16, 45);
            this.tboxNets.Multiline = true;
            this.tboxNets.Name = "tboxNets";
            this.tboxNets.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tboxNets.Size = new System.Drawing.Size(261, 468);
            this.tboxNets.TabIndex = 162;
            // 
            // labelHostName
            // 
            this.labelHostName.AutoSize = true;
            this.labelHostName.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHostName.Location = new System.Drawing.Point(14, 13);
            this.labelHostName.Name = "labelHostName";
            this.labelHostName.Size = new System.Drawing.Size(101, 23);
            this.labelHostName.TabIndex = 163;
            this.labelHostName.Text = "Hostname:";
            this.labelHostName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblHostname
            // 
            this.lblHostname.AutoSize = true;
            this.lblHostname.BackColor = System.Drawing.Color.Gainsboro;
            this.lblHostname.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHostname.Location = new System.Drawing.Point(112, 13);
            this.lblHostname.Name = "lblHostname";
            this.lblHostname.Size = new System.Drawing.Size(94, 23);
            this.lblHostname.TabIndex = 165;
            this.lblHostname.Text = "Hostname";
            this.lblHostname.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelNoAdapter
            // 
            this.labelNoAdapter.AutoSize = true;
            this.labelNoAdapter.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNoAdapter.ForeColor = System.Drawing.Color.Red;
            this.labelNoAdapter.Location = new System.Drawing.Point(366, 469);
            this.labelNoAdapter.Name = "labelNoAdapter";
            this.labelNoAdapter.Size = new System.Drawing.Size(298, 25);
            this.labelNoAdapter.TabIndex = 166;
            this.labelNoAdapter.Text = "No Adapter For This Subnet";
            this.labelNoAdapter.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cboxUp
            // 
            this.cboxUp.Appearance = System.Windows.Forms.Appearance.Button;
            this.cboxUp.BackColor = System.Drawing.Color.White;
            this.cboxUp.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cboxUp.Checked = true;
            this.cboxUp.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cboxUp.FlatAppearance.CheckedBackColor = System.Drawing.Color.WhiteSmoke;
            this.cboxUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboxUp.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboxUp.Location = new System.Drawing.Point(152, 520);
            this.cboxUp.Name = "cboxUp";
            this.cboxUp.Size = new System.Drawing.Size(121, 50);
            this.cboxUp.TabIndex = 168;
            this.cboxUp.Text = "Up";
            this.cboxUp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cboxUp.UseVisualStyleBackColor = false;
            this.cboxUp.Click += new System.EventHandler(this.cboxUp_Click);
            // 
            // labelFilter
            // 
            this.labelFilter.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFilter.Location = new System.Drawing.Point(18, 517);
            this.labelFilter.Name = "labelFilter";
            this.labelFilter.Size = new System.Drawing.Size(128, 54);
            this.labelFilter.TabIndex = 513;
            this.labelFilter.Text = "Filter";
            this.labelFilter.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelScanning
            // 
            this.labelScanning.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelScanning.Location = new System.Drawing.Point(300, 232);
            this.labelScanning.Name = "labelScanning";
            this.labelScanning.Size = new System.Drawing.Size(100, 23);
            this.labelScanning.TabIndex = 514;
            this.labelScanning.Text = "Scanning";
            this.labelScanning.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelIPAddress
            // 
            this.labelIPAddress.AutoSize = true;
            this.labelIPAddress.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIPAddress.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.labelIPAddress.Location = new System.Drawing.Point(484, 10);
            this.labelIPAddress.Name = "labelIPAddress";
            this.labelIPAddress.Size = new System.Drawing.Size(99, 23);
            this.labelIPAddress.TabIndex = 516;
            this.labelIPAddress.Text = "IP Address";
            this.labelIPAddress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 145F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 62F));
            this.tableLayoutPanel1.Controls.Add(this.lblBtnIMU, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblBtnGPS, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.labelIMU, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblIMU_IP, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblBtnMachine, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.labelSteer, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblGPSIP, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblSteerIP, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblBtnSteer, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelMachine, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblMachineIP, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.labelGPS, 0, 2);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(298, 35);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(435, 177);
            this.tableLayoutPanel1.TabIndex = 519;
            // 
            // lblBtnIMU
            // 
            this.lblBtnIMU.AutoSize = true;
            this.lblBtnIMU.BackColor = System.Drawing.Color.Transparent;
            this.lblBtnIMU.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBtnIMU.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBtnIMU.Location = new System.Drawing.Point(375, 1);
            this.lblBtnIMU.Name = "lblBtnIMU";
            this.lblBtnIMU.Size = new System.Drawing.Size(56, 43);
            this.lblBtnIMU.TabIndex = 533;
            this.lblBtnIMU.Text = "-";
            this.lblBtnIMU.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBtnGPS
            // 
            this.lblBtnGPS.AutoSize = true;
            this.lblBtnGPS.BackColor = System.Drawing.Color.Transparent;
            this.lblBtnGPS.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBtnGPS.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBtnGPS.Location = new System.Drawing.Point(375, 89);
            this.lblBtnGPS.Name = "lblBtnGPS";
            this.lblBtnGPS.Size = new System.Drawing.Size(56, 43);
            this.lblBtnGPS.TabIndex = 532;
            this.lblBtnGPS.Text = "-";
            this.lblBtnGPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelIMU
            // 
            this.labelIMU.AutoSize = true;
            this.labelIMU.BackColor = System.Drawing.Color.Transparent;
            this.labelIMU.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelIMU.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIMU.Location = new System.Drawing.Point(4, 1);
            this.labelIMU.Name = "labelIMU";
            this.labelIMU.Size = new System.Drawing.Size(139, 43);
            this.labelIMU.TabIndex = 524;
            this.labelIMU.Text = "IMU";
            this.labelIMU.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIMU_IP
            // 
            this.lblIMU_IP.AutoSize = true;
            this.lblIMU_IP.BackColor = System.Drawing.Color.Transparent;
            this.lblIMU_IP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblIMU_IP.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIMU_IP.Location = new System.Drawing.Point(150, 1);
            this.lblIMU_IP.Name = "lblIMU_IP";
            this.lblIMU_IP.Size = new System.Drawing.Size(218, 43);
            this.lblIMU_IP.TabIndex = 526;
            this.lblIMU_IP.Text = "..";
            this.lblIMU_IP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBtnMachine
            // 
            this.lblBtnMachine.AutoSize = true;
            this.lblBtnMachine.BackColor = System.Drawing.Color.Transparent;
            this.lblBtnMachine.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBtnMachine.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBtnMachine.Location = new System.Drawing.Point(375, 133);
            this.lblBtnMachine.Name = "lblBtnMachine";
            this.lblBtnMachine.Size = new System.Drawing.Size(56, 43);
            this.lblBtnMachine.TabIndex = 531;
            this.lblBtnMachine.Text = "-";
            this.lblBtnMachine.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelSteer
            // 
            this.labelSteer.AutoSize = true;
            this.labelSteer.BackColor = System.Drawing.Color.Transparent;
            this.labelSteer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelSteer.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSteer.Location = new System.Drawing.Point(4, 45);
            this.labelSteer.Name = "labelSteer";
            this.labelSteer.Size = new System.Drawing.Size(139, 43);
            this.labelSteer.TabIndex = 521;
            this.labelSteer.Text = "Steer";
            this.labelSteer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGPSIP
            // 
            this.lblGPSIP.AutoSize = true;
            this.lblGPSIP.BackColor = System.Drawing.Color.Transparent;
            this.lblGPSIP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblGPSIP.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGPSIP.Location = new System.Drawing.Point(150, 89);
            this.lblGPSIP.Name = "lblGPSIP";
            this.lblGPSIP.Size = new System.Drawing.Size(218, 43);
            this.lblGPSIP.TabIndex = 530;
            this.lblGPSIP.Text = "..";
            this.lblGPSIP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSteerIP
            // 
            this.lblSteerIP.AutoSize = true;
            this.lblSteerIP.BackColor = System.Drawing.Color.Transparent;
            this.lblSteerIP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSteerIP.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSteerIP.Location = new System.Drawing.Point(150, 45);
            this.lblSteerIP.Name = "lblSteerIP";
            this.lblSteerIP.Size = new System.Drawing.Size(218, 43);
            this.lblSteerIP.TabIndex = 526;
            this.lblSteerIP.Text = "..";
            this.lblSteerIP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBtnSteer
            // 
            this.lblBtnSteer.AutoSize = true;
            this.lblBtnSteer.BackColor = System.Drawing.Color.Transparent;
            this.lblBtnSteer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBtnSteer.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBtnSteer.Location = new System.Drawing.Point(375, 45);
            this.lblBtnSteer.Name = "lblBtnSteer";
            this.lblBtnSteer.Size = new System.Drawing.Size(56, 43);
            this.lblBtnSteer.TabIndex = 521;
            this.lblBtnSteer.Text = "-";
            this.lblBtnSteer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelMachine
            // 
            this.labelMachine.AutoSize = true;
            this.labelMachine.BackColor = System.Drawing.Color.Transparent;
            this.labelMachine.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelMachine.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMachine.Location = new System.Drawing.Point(4, 133);
            this.labelMachine.Name = "labelMachine";
            this.labelMachine.Size = new System.Drawing.Size(139, 43);
            this.labelMachine.TabIndex = 522;
            this.labelMachine.Text = "Machine";
            this.labelMachine.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMachineIP
            // 
            this.lblMachineIP.AutoSize = true;
            this.lblMachineIP.BackColor = System.Drawing.Color.Transparent;
            this.lblMachineIP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMachineIP.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMachineIP.Location = new System.Drawing.Point(150, 133);
            this.lblMachineIP.Name = "lblMachineIP";
            this.lblMachineIP.Size = new System.Drawing.Size(218, 43);
            this.lblMachineIP.TabIndex = 528;
            this.lblMachineIP.Text = "..";
            this.lblMachineIP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelGPS
            // 
            this.labelGPS.AutoSize = true;
            this.labelGPS.BackColor = System.Drawing.Color.Transparent;
            this.labelGPS.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelGPS.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGPS.Location = new System.Drawing.Point(4, 89);
            this.labelGPS.Name = "labelGPS";
            this.labelGPS.Size = new System.Drawing.Size(139, 43);
            this.labelGPS.TabIndex = 523;
            this.labelGPS.Text = "GPS";
            this.labelGPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNewSubnet
            // 
            this.lblNewSubnet.BackColor = System.Drawing.Color.Gainsboro;
            this.lblNewSubnet.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblNewSubnet.Font = new System.Drawing.Font("Tahoma", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewSubnet.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblNewSubnet.Location = new System.Drawing.Point(404, 223);
            this.lblNewSubnet.Name = "lblNewSubnet";
            this.lblNewSubnet.Size = new System.Drawing.Size(244, 45);
            this.lblNewSubnet.TabIndex = 520;
            this.lblNewSubnet.Text = "192 . 168 . 123";
            this.lblNewSubnet.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelUDPMonitor
            // 
            this.labelUDPMonitor.AutoSize = true;
            this.labelUDPMonitor.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUDPMonitor.Location = new System.Drawing.Point(749, 268);
            this.labelUDPMonitor.Name = "labelUDPMonitor";
            this.labelUDPMonitor.Size = new System.Drawing.Size(102, 18);
            this.labelUDPMonitor.TabIndex = 523;
            this.labelUDPMonitor.Text = "UDP Monitor";
            this.labelUDPMonitor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnSerialMonitor
            // 
            this.btnSerialMonitor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSerialMonitor.FlatAppearance.BorderSize = 0;
            this.btnSerialMonitor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSerialMonitor.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSerialMonitor.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnSerialMonitor.Image = global::AgIO.Properties.Resources.ScanNetwork;
            this.btnSerialMonitor.Location = new System.Drawing.Point(756, 207);
            this.btnSerialMonitor.Name = "btnSerialMonitor";
            this.btnSerialMonitor.Size = new System.Drawing.Size(76, 65);
            this.btnSerialMonitor.TabIndex = 522;
            this.btnSerialMonitor.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnSerialMonitor.UseVisualStyleBackColor = true;
            this.btnSerialMonitor.Click += new System.EventHandler(this.btnSerialMonitor_Click);
            // 
            // btnNetworkCPL
            // 
            this.btnNetworkCPL.BackgroundImage = global::AgIO.Properties.Resources.DeviceManager;
            this.btnNetworkCPL.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnNetworkCPL.FlatAppearance.BorderSize = 0;
            this.btnNetworkCPL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNetworkCPL.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNetworkCPL.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnNetworkCPL.Location = new System.Drawing.Point(756, 1);
            this.btnNetworkCPL.Name = "btnNetworkCPL";
            this.btnNetworkCPL.Size = new System.Drawing.Size(76, 65);
            this.btnNetworkCPL.TabIndex = 521;
            this.btnNetworkCPL.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnNetworkCPL.UseVisualStyleBackColor = true;
            this.btnNetworkCPL.Click += new System.EventHandler(this.btnNetworkCPL_Click);
            // 
            // btnUDPOff
            // 
            this.btnUDPOff.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnUDPOff.FlatAppearance.BorderSize = 0;
            this.btnUDPOff.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUDPOff.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUDPOff.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnUDPOff.Image = global::AgIO.Properties.Resources.EthernetOff;
            this.btnUDPOff.Location = new System.Drawing.Point(740, 108);
            this.btnUDPOff.Margin = new System.Windows.Forms.Padding(0);
            this.btnUDPOff.Name = "btnUDPOff";
            this.btnUDPOff.Size = new System.Drawing.Size(107, 65);
            this.btnUDPOff.TabIndex = 151;
            this.btnUDPOff.UseVisualStyleBackColor = true;
            this.btnUDPOff.Click += new System.EventHandler(this.btnUDPOff_Click);
            // 
            // btnSendSubnet
            // 
            this.btnSendSubnet.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSendSubnet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSendSubnet.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSendSubnet.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnSendSubnet.Image = global::AgIO.Properties.Resources.SubnetSend;
            this.btnSendSubnet.Location = new System.Drawing.Point(701, 373);
            this.btnSendSubnet.Name = "btnSendSubnet";
            this.btnSendSubnet.Size = new System.Drawing.Size(92, 79);
            this.btnSendSubnet.TabIndex = 151;
            this.btnSendSubnet.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnSendSubnet.UseVisualStyleBackColor = true;
            this.btnSendSubnet.Click += new System.EventHandler(this.btnSendSubnet_Click);
            // 
            // btnSerialCancel
            // 
            this.btnSerialCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSerialCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSerialCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnSerialCancel.FlatAppearance.BorderSize = 0;
            this.btnSerialCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSerialCancel.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSerialCancel.Image = global::AgIO.Properties.Resources.OK64;
            this.btnSerialCancel.Location = new System.Drawing.Point(766, 502);
            this.btnSerialCancel.Name = "btnSerialCancel";
            this.btnSerialCancel.Size = new System.Drawing.Size(92, 79);
            this.btnSerialCancel.TabIndex = 71;
            this.btnSerialCancel.UseVisualStyleBackColor = true;
            this.btnSerialCancel.Click += new System.EventHandler(this.btnSerialCancel_Click);
            // 
            // pboxSendSteer
            // 
            this.pboxSendSteer.BackgroundImage = global::AgIO.Properties.Resources.ConSt_Mandatory;
            this.pboxSendSteer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pboxSendSteer.Location = new System.Drawing.Point(728, 333);
            this.pboxSendSteer.Name = "pboxSendSteer";
            this.pboxSendSteer.Size = new System.Drawing.Size(38, 39);
            this.pboxSendSteer.TabIndex = 510;
            this.pboxSendSteer.TabStop = false;
            this.pboxSendSteer.Visible = false;
            // 
            // btnAutoSet
            // 
            this.btnAutoSet.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnAutoSet.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnAutoSet.Enabled = false;
            this.btnAutoSet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAutoSet.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAutoSet.Image = global::AgIO.Properties.Resources.DnArrow64;
            this.btnAutoSet.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAutoSet.Location = new System.Drawing.Point(440, 279);
            this.btnAutoSet.Name = "btnAutoSet";
            this.btnAutoSet.Size = new System.Drawing.Size(162, 58);
            this.btnAutoSet.TabIndex = 524;
            this.btnAutoSet.Text = "Auto Fill New Subnet";
            this.btnAutoSet.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAutoSet.UseVisualStyleBackColor = false;
            this.btnAutoSet.Click += new System.EventHandler(this.btnAutoSet_Click);
            // 
            // labelUDPOff
            // 
            this.labelUDPOff.AutoSize = true;
            this.labelUDPOff.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUDPOff.Location = new System.Drawing.Point(763, 173);
            this.labelUDPOff.Name = "labelUDPOff";
            this.labelUDPOff.Size = new System.Drawing.Size(68, 18);
            this.labelUDPOff.TabIndex = 525;
            this.labelUDPOff.Text = "UDP Off";
            this.labelUDPOff.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelNetworkProp
            // 
            this.labelNetworkProp.AutoSize = true;
            this.labelNetworkProp.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNetworkProp.Location = new System.Drawing.Point(739, 61);
            this.labelNetworkProp.Name = "labelNetworkProp";
            this.labelNetworkProp.Size = new System.Drawing.Size(112, 18);
            this.labelNetworkProp.TabIndex = 526;
            this.labelNetworkProp.Text = "Network Prop";
            this.labelNetworkProp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FormUDP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(861, 584);
            this.ControlBox = false;
            this.Controls.Add(this.labelUDPMonitor);
            this.Controls.Add(this.labelNetworkProp);
            this.Controls.Add(this.labelUDPOff);
            this.Controls.Add(this.btnAutoSet);
            this.Controls.Add(this.btnSerialMonitor);
            this.Controls.Add(this.btnNetworkCPL);
            this.Controls.Add(this.lblNewSubnet);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.labelIPAddress);
            this.Controls.Add(this.labelFilter);
            this.Controls.Add(this.cboxUp);
            this.Controls.Add(this.labelNoAdapter);
            this.Controls.Add(this.lblHostname);
            this.Controls.Add(this.labelHostName);
            this.Controls.Add(this.tboxNets);
            this.Controls.Add(this.labelCurrentSubnet);
            this.Controls.Add(this.lblNetworkHelp);
            this.Controls.Add(this.labelModuleScan);
            this.Controls.Add(this.btnUDPOff);
            this.Controls.Add(this.btnSendSubnet);
            this.Controls.Add(this.nudThirdIP);
            this.Controls.Add(this.nudSecndIP);
            this.Controls.Add(this.nudFirstIP);
            this.Controls.Add(this.labelNewSubnet);
            this.Controls.Add(this.btnSerialCancel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.labelSetSubnet);
            this.Controls.Add(this.pboxSendSteer);
            this.Controls.Add(this.labelScanning);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormUDP";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Ethernet Configuration";
            this.Load += new System.EventHandler(this.FormUDp_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudFirstIP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSecndIP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudThirdIP)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pboxSendSteer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnSerialCancel;
        private System.Windows.Forms.Label lblNetworkHelp;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label labelNewSubnet;
        private System.Windows.Forms.NumericUpDown nudFirstIP;
        private System.Windows.Forms.NumericUpDown nudSecndIP;
        private System.Windows.Forms.NumericUpDown nudThirdIP;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelCurrentSubnet;
        private System.Windows.Forms.Label labelSetSubnet;
        private System.Windows.Forms.Label labelModuleScan;
        private System.Windows.Forms.TextBox tboxNets;
        private System.Windows.Forms.Label labelHostName;
        private System.Windows.Forms.Label lblHostname;
        private System.Windows.Forms.Label labelNoAdapter;
        private System.Windows.Forms.CheckBox cboxUp;
        private System.Windows.Forms.PictureBox pboxSendSteer;
        private System.Windows.Forms.Button btnSendSubnet;
        private System.Windows.Forms.Label labelFilter;
        private System.Windows.Forms.Label labelScanning;
        private System.Windows.Forms.Label labelIPAddress;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label labelIMU;
        private System.Windows.Forms.Label labelGPS;
        private System.Windows.Forms.Label labelMachine;
        private System.Windows.Forms.Label labelSteer;
        private System.Windows.Forms.Label lblSteerIP;
        private System.Windows.Forms.Label lblGPSIP;
        private System.Windows.Forms.Label lblMachineIP;
        private System.Windows.Forms.Label lblIMU_IP;
        private System.Windows.Forms.Label lblNewSubnet;
        private System.Windows.Forms.Label lblBtnIMU;
        private System.Windows.Forms.Label lblBtnGPS;
        private System.Windows.Forms.Label lblBtnMachine;
        private System.Windows.Forms.Label lblBtnSteer;
        private System.Windows.Forms.Button btnNetworkCPL;
        private System.Windows.Forms.Button btnSerialMonitor;
        private System.Windows.Forms.Label labelUDPMonitor;
        private System.Windows.Forms.Button btnUDPOff;
        private System.Windows.Forms.Button btnAutoSet;
        private System.Windows.Forms.Label labelUDPOff;
        private System.Windows.Forms.Label labelNetworkProp;
    }
}