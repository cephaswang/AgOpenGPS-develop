﻿using System.Windows;

namespace AgOpenGPS.WpfApp.Field
{
    public partial class StartNewFieldDialog : Window
    {
        public StartNewFieldDialog()
        {
            InitializeComponent();
        }
    }
}
