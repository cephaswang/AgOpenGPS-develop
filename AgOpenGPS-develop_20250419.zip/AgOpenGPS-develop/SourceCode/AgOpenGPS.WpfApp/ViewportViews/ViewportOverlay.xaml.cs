﻿using System.Windows.Controls;

namespace AgOpenGPS.WpfApp.ViewportViews
{
    public partial class ViewportOverlay : UserControl
    {
        public ViewportOverlay()
        {
            InitializeComponent();
        }
    }
}
