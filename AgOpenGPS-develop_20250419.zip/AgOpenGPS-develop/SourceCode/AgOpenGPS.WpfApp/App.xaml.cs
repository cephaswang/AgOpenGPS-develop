﻿using System.Windows;

namespace AgOpenGPS.WpfApp
{
    public partial class App : Application
    {
    }
}
