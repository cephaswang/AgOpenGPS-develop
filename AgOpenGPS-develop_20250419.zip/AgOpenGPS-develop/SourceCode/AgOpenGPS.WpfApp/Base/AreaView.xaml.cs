﻿using System.Windows.Controls;

namespace AgOpenGPS.WpfApp.Base
{
    public partial class AreaView : UserControl
    {
        public AreaView()
        {
            InitializeComponent();
        }
    }
}
