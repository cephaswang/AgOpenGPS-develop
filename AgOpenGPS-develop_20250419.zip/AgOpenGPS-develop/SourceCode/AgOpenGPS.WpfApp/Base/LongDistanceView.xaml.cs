﻿using System.Windows.Controls;

namespace AgOpenGPS.WpfApp.Base
{
    public partial class LongDistanceView : UserControl
    {
        public LongDistanceView()
        {
            InitializeComponent();
        }
    }
}
