﻿using AgLibrary.Logging;
using AgOpenGPS.Controls;
using AgOpenGPS.Culture;
using AgOpenGPS.Helpers;
using System;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace AgOpenGPS
{
    public partial class FormSteerWiz : Form
    {
        private readonly FormGPS mf = null;

        private bool toSend252 = false, toSend251 = false, isSARight = false, isSALeft = false;
        private int counter252 = 0, counter251 = 0, cntr;
        private vec3 startFix;
        private double diameter, steerAngleRight, steerAngleLeft, dist, startAngleLeft;
        private bool isWizardStarted = false;

        //Form stuff
        public FormSteerWiz(Form callingForm)
        {
            mf = callingForm as FormGPS;
            InitializeComponent();
            nudMaxCounts.Controls[0].Enabled = false;

            nudAntennaHeight.Controls[0].Enabled = false;
            nudAntennaOffset.Controls[0].Enabled = false;
            nudAntennaPivot.Controls[0].Enabled = false;
            nudVehicleTrack.Controls[0].Enabled = false;
            nudWheelbase.Controls[0].Enabled = false;

            this.label3.Text = gStr.gsAgressiveness;
            this.label5.Text = gStr.gsOvershootReduction;
            
            //this.Width = 378;
            //this.Height = 462;
        }

        // 方法：獲取 user.config 文件的完整路徑
        private string GetUserConfigPath()
        {
            try
            {
                // 獲取當前應用程式的配置檔案路徑
                var config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.PerUserRoamingAndLocal);
                return config.FilePath; // 返回 user.config 的完整路徑
            }
            catch (Exception ex)
            {
                // 如果無法獲取路徑，返回錯誤信息
                return $"Error retrieving config path: {ex.Message}";
            }
        }

        private void FormSteer_Load(object sender, EventArgs e)
        {
            // 獲取 user.config 文件的完整路徑
            string configPath = GetUserConfigPath();
            // 設置表單標題，包含原始標題和數據保存路徑
            this.Text = $"{gStr.gsAutoSteerConfiguration}-Path:{configPath}";


            btnAckReset.Text = gStr.gsAckReset;
            btnCloseAll.Text = gStr.gsCloseAll;
            btnFreeDrive.Text = gStr.gsFreeDrive;
            btnFreeDriveZero.Text = gStr.gsFreeDriveZero;
            btnLeftPGain.Text = gStr.gsLeftPGain;
            btnLoadDefaults.Text = gStr.gsLoadDefaults;
            btnMinGainLeft.Text = gStr.gsMinGainLeft;
            btnMinGainRight.Text = gStr.gsMinGainRight;
            btnNext_PGain.Text = gStr.gsNext_PGain;
            btnOK_Next.Text = gStr.gsOK_Next;
            btnOkNext_A2D.Text = gStr.gsOkNext_A2D;
            btnOkNext_ButtonSwitch.Text = gStr.gsOkNext_ButtonSwitch;
            btnOkNext_CountsPerDeg.Text = gStr.gsOkNext_CountsPerDeg;
            btnOKNext_CPDSetup.Text = gStr.gsOKNext_CPDSetup;
            btnOkNext_Danfoss.Text = gStr.gsOkNext_Danfoss;
            btnOkNext_InvertRelays.Text = gStr.gsOkNext_InvertRelays;
            btnOkNext_LoadDefault.Text = gStr.gsOkNext_LoadDefault;
            btnOkNext_MotorDirection.Text = gStr.gsOkNext_MotorDirectio;
            btnOkNext_MotorDriver.Text = gStr.gsOkNext_MotorDriver;
            btnOkNext_PanicStop.Text = gStr.gsOkNext_PanicStop;
            btnOkNext_WAS_Zero.Text = gStr.gsOkNext_WAS_Zero;
            btnOkNextCancelGuidance.Text = gStr.gsOkNextCancelGuidance;
            btnOkNextMaxSteerAngle.Text = gStr.gsOkNextMaxSteerAngle;
            btnOkSetMaximumSteerAngle.Text = gStr.gsOkSetMaximumSteerAng;
            btnOkWAS.Text = gStr.gsOkWAS;
            btnPrev_A2D.Text = gStr.gsPrev_A2D;
            btnPrev_CancelGuidance.Text = gStr.gsPrev_CancelGuidance;
            btnPrev_CountsPerDegree.Text = gStr.gsPrev_CountsPerDegree;
            btnPrev_Danfoss.Text = gStr.gsPrev_Danfoss;
            btnPrev_End.Text = gStr.gsPrev_End;
            btnPrev_Gain.Text = gStr.gsPrev_Gain;
            btnPrev_InvertRelays.Text = gStr.gsPrev_InvertRelays;
            btnPrev_InvertWAS.Text = gStr.gsPrev_InvertWAS;
            btnPrev_MaxSteerAngle.Text = gStr.gsPrev_MaxSteerAngle;
            btnPrev_MotorDirection.Text = gStr.gsPrev_MotorDirection;
            btnPrev_MotorDriver.Text = gStr.gsPrev_MotorDriver;
            btnPrev_Panic.Text = gStr.gsPrev_Panic;
            btnPrev_PGain.Text = gStr.gsPrev_PGain;
            btnRemoveWasOffset.Text = gStr.gsRemoveWasOffset;
            btnRemoveZeroOffset.Text = gStr.gsRemoveZeroOffset;
            btnRestartWizard.Text = gStr.gsRestartWizard;
            btnRightPGain.Text = gStr.gsRightPGain;
            btnSkipCPD_Setup.Text = gStr.gsSkipCPD_Setup;
            btnStartSA.Text = gStr.gsStartSA;
            btnStartSA_Left.Text = gStr.gsStartSA_Left;
            btnStartWizard.Text = gStr.gsStartWizard;
            btnSteerLeft.Text = gStr.gsSteerLeft;
            btnSteerRight.Text = gStr.gsSteerRight;
            btnSteerStatus.Text = gStr.gsSteerStatus;
            btnZeroMinMovementSetting.Text = gStr.gsZeroMinMovementSetti;
            btnZeroPGain.Text = gStr.gsZeroPGain;
            btnZeroWAS.Text = gStr.gsZeroWAS;
            tabWheelBase.Text = gStr.gsWheelBase;
            btnAckReset.Text = gStr.gsAckReset;


            btnStopWizard.Text = gStr.gsStopWizard;
            btnExit.Text = gStr.gsExit;
            btnZeroRoll.Text = gStr.gsZeroRoll;
            tabStart.Text = gStr.gsStart;
            tabMotorDriver.Text = gStr.gsMotorDriver;
            tabInvertRelays.Text = gStr.gsInvertRelays;
            tabMaxSteerAngle.Text = gStr.gsMaxSteerAngle;
            tabAntennaHeight.Text = gStr.gsAntennaHeight;
            tabAntennaOffset.Text = gStr.gsAntennaOffset;


            tabLoadDef.Text = gStr.gsLoadDef;

            tabWheelTrack.Text = gStr.gsWheelTrack;
            tabAntennaDistance.Text = gStr.gsAntennaDistance;
            tabButtonSwitch.Text = gStr.gsButtonSwitch;
            tabA2DConv.Text = gStr.gsA2DConv;
            tabDanfoss.Text = gStr.gsDanfoss;
            tabRollInv.Text = gStr.gsRollInv;
            tabRollZero.Text = gStr.gsRollZero;
            tabWAS_Zero.Text = gStr.gsWAS_Zero;
            tabMotorDirection.Text = gStr.gsMotorDirection;
            tabCPD_Setup.Text = gStr.gsCPD_Setup;
            tabCountsPerDeg.Text = gStr.gsCountsPerDeg;
            tabAckCPD.Text = gStr.gsAckCPD;
            tabCancelGuidance.Text = gStr.gsCancelGuidance;
            tabPanicStop.Text = gStr.gsPanicStop;




            label1.Text = gStr.gsFormSteerWizLab_1;
            label10.Text = gStr.gsFormSteerWizLab_10;
            label101.Text = gStr.gsFormSteerWizLab_101;
            label102.Text = gStr.gsFormSteerWizLab_102;
            label103.Text = gStr.gsFormSteerWizLab_103;
            label104.Text = gStr.gsFormSteerWizLab_104;
            label105.Text = gStr.gsFormSteerWizLab_105;
            label106.Text = gStr.gsFormSteerWizLab_106;
            label107.Text = gStr.gsFormSteerWizLab_107;
            label108.Text = gStr.gsFormSteerWizLab_108;
            label109.Text = gStr.gsFormSteerWizLab_109;
            label11.Text = gStr.gsFormSteerWizLab_11;
            label110.Text = gStr.gsFormSteerWizLab_110;
            label111.Text = gStr.gsFormSteerWizLab_111;
            label112.Text = gStr.gsFormSteerWizLab_112;
            label113.Text = gStr.gsFormSteerWizLab_113;
            label115.Text = gStr.gsFormSteerWizLab_115;
            label116.Text = gStr.gsFormSteerWizLab_116;
            label12.Text = gStr.gsFormSteerWizLab_12;
            label13.Text = gStr.gsFormSteerWizLab_13;
            label14.Text = gStr.gsFormSteerWizLab_14;
            label15.Text = gStr.gsFormSteerWizLab_15;
            label17.Text = gStr.gsFormSteerWizLab_17;
            label18.Text = gStr.gsFormSteerWizLab_18;
            label19.Text = gStr.gsFormSteerWizLab_19;
            label2.Text = gStr.gsFormSteerWizLab_2;
            label20.Text = gStr.gsFormSteerWizLab_20;
            label21.Text = gStr.gsFormSteerWizLab_21;
            label22.Text = gStr.gsFormSteerWizLab_22;
            label23.Text = gStr.gsFormSteerWizLab_23;
            label24.Text = gStr.gsFormSteerWizLab_24;
            label25.Text = gStr.gsFormSteerWizLab_25;
            label26.Text = gStr.gsFormSteerWizLab_26;
            label27.Text = gStr.gsFormSteerWizLab_27;
            label28.Text = gStr.gsFormSteerWizLab_28;
            label29.Text = gStr.gsFormSteerWizLab_29;
            label3.Text = gStr.gsFormSteerWizLab_3;
            label30.Text = gStr.gsFormSteerWizLab_30;
            label32.Text = gStr.gsFormSteerWizLab_32;
            label33.Text = gStr.gsFormSteerWizLab_33;
            label34.Text = gStr.gsFormSteerWizLab_34;
            label35.Text = gStr.gsFormSteerWizLab_35;
            label36.Text = gStr.gsFormSteerWizLab_36;
            label37.Text = gStr.gsFormSteerWizLab_37;
            label38.Text = gStr.gsFormSteerWizLab_38;
            label39.Text = gStr.gsFormSteerWizLab_39;
            label4.Text = gStr.gsFormSteerWizLab_4;
            label40.Text = gStr.gsFormSteerWizLab_40;
            label41.Text = gStr.gsFormSteerWizLab_41;
            label42.Text = gStr.gsFormSteerWizLab_42;
            label43.Text = gStr.gsFormSteerWizLab_43;
            label44.Text = gStr.gsFormSteerWizLab_44;
            label45.Text = gStr.gsFormSteerWizLab_45;
            label46.Text = gStr.gsFormSteerWizLab_46;
            label47.Text = gStr.gsFormSteerWizLab_47;
            label48.Text = gStr.gsFormSteerWizLab_48;
            label49.Text = gStr.gsFormSteerWizLab_49;
            label5.Text = gStr.gsFormSteerWizLab_5;
            label50.Text = gStr.gsFormSteerWizLab_50;
            label51.Text = gStr.gsFormSteerWizLab_51;
            label52.Text = gStr.gsFormSteerWizLab_52;
            label53.Text = gStr.gsFormSteerWizLab_53;
            label54.Text = gStr.gsFormSteerWizLab_54;
            label55.Text = gStr.gsFormSteerWizLab_55;
            label56.Text = gStr.gsFormSteerWizLab_56;
            label57.Text = gStr.gsFormSteerWizLab_57;
            label58.Text = gStr.gsFormSteerWizLab_58;
            label59.Text = gStr.gsFormSteerWizLab_59;
            label6.Text = gStr.gsFormSteerWizLab_6;
            label60.Text = gStr.gsFormSteerWizLab_60;
            label61.Text = gStr.gsFormSteerWizLab_61;
            label62.Text = gStr.gsFormSteerWizLab_62;
            label63.Text = gStr.gsFormSteerWizLab_63;
            label64.Text = gStr.gsFormSteerWizLab_64;
            label65.Text = gStr.gsFormSteerWizLab_65;
            label66.Text = gStr.gsFormSteerWizLab_66;
            label67.Text = gStr.gsFormSteerWizLab_67;
            label68.Text = gStr.gsFormSteerWizLab_68;
            label69.Text = gStr.gsFormSteerWizLab_69;
            label7.Text = gStr.gsFormSteerWizLab_7;
            label70.Text = gStr.gsFormSteerWizLab_70;
            label71.Text = gStr.gsFormSteerWizLab_71;
            label72.Text = gStr.gsFormSteerWizLab_72;
            label73.Text = gStr.gsFormSteerWizLab_73;
            label74.Text = gStr.gsFormSteerWizLab_74;
            label75.Text = gStr.gsFormSteerWizLab_75;
            label76.Text = gStr.gsFormSteerWizLab_76;
            label77.Text = gStr.gsFormSteerWizLab_77;
            label78.Text = gStr.gsFormSteerWizLab_78;
            label79.Text = gStr.gsFormSteerWizLab_79;
            label8.Text = gStr.gsFormSteerWizLab_8;
            label80.Text = gStr.gsFormSteerWizLab_80;
            label81.Text = gStr.gsFormSteerWizLab_81;
            label83.Text = gStr.gsFormSteerWizLab_83;
            label84.Text = gStr.gsFormSteerWizLab_84;
            label85.Text = gStr.gsFormSteerWizLab_85;
            label86.Text = gStr.gsFormSteerWizLab_86;
            label87.Text = gStr.gsFormSteerWizLab_87;
            label88.Text = gStr.gsFormSteerWizLab_88;
            label9.Text = gStr.gsFormSteerWizLab_9;
            label90.Text = gStr.gsFormSteerWizLab_90;
            label91.Text = gStr.gsFormSteerWizLab_91;
            label92.Text = gStr.gsFormSteerWizLab_92;
            label93.Text = gStr.gsFormSteerWizLab_93;
            label94.Text = gStr.gsFormSteerWizLab_94;
            label95.Text = gStr.gsFormSteerWizLab_95;
            label98.Text = gStr.gsFormSteerWizLab_98;
            label99.Text = gStr.gsFormSteerWizLab_99;
            labelCurrentTurnSensor.Text = gStr.gsFormSteerWizLab_CurrentTurnSensor;
            labelEncoder.Text = gStr.gsFormSteerWizLab_Encoder;
            labelPressureTurnSensor.Text = gStr.gsFormSteerWizLab_PressureTurnSensor;
            lblRollZeroOffset.Text = gStr.gsRollZeroOffset;
            tab_MinimumGain.Text = gStr.gsMinimumGain;
            tabEnd.Text = gStr.gsEnd;
            tabPGain.Text = gStr.gsPGain;
            tabWAS.Text = gStr.gsWAS;


            // MessageBox.Show(gStr.gsPanicStop);

            tabWiz.Appearance = TabAppearance.FlatButtons;
            tabWiz.ItemSize = new Size(0, 1);
            tabWiz.SizeMode = TabSizeMode.Fixed;

            pbarProgress.Maximum = tabWiz.TabCount - 1;

            hsbarWasOffset.Value = Properties.Settings.Default.setAS_wasOffset;
            hsbarCountsPerDegree.Value = Properties.Settings.Default.setAS_countsPerDegree;

            lblCountsPerDegree.Text = hsbarCountsPerDegree.Value.ToString();
            lblSteerAngleSensorZero.Text = (hsbarWasOffset.Value / (double)(hsbarCountsPerDegree.Value)).ToString("N2");

            hsbarAckerman.Value = Properties.Settings.Default.setAS_ackerman;
            lblAckerman.Text = hsbarAckerman.Value.ToString();

            //min pwm, kP
            hsbarMinPWM.Value = Properties.Settings.Default.setAS_minSteerPWM;
            lblMinPWM.Text = hsbarMinPWM.Value.ToString();

            hsbarProportionalGain.Value = Properties.Settings.Default.setAS_Kp;
            lblProportionalGain.Text = hsbarProportionalGain.Value.ToString();

            //low steer, high steer
            hsbarLowSteerPWM.Value = Properties.Settings.Default.setAS_lowSteerPWM;
            lblLowSteerPWM.Text = hsbarLowSteerPWM.Value.ToString();

            hsbarHighSteerPWM.Value = Properties.Settings.Default.setAS_highSteerPWM;
            lblHighSteerPWM.Text = hsbarHighSteerPWM.Value.ToString();

            hsbarMaxSteerAngle.Value = (Int16)Properties.Settings.Default.setVehicle_maxSteerAngle;
            lblMaxSteerAngle.Text = hsbarMaxSteerAngle.Value.ToString();

            mf.vehicle.stanleyDistanceErrorGain = Properties.Settings.Default.stanleyDistanceErrorGain;
            hsbarStanleyGain.Value = (Int16)(mf.vehicle.stanleyDistanceErrorGain * 10);
            lblStanleyGain.Text = mf.vehicle.stanleyDistanceErrorGain.ToString();

            mf.vehicle.stanleyHeadingErrorGain = Properties.Settings.Default.stanleyHeadingErrorGain;
            hsbarHeadingErrorGain.Value = (Int16)(mf.vehicle.stanleyHeadingErrorGain * 10);
            lblHeadingErrorGain.Text = mf.vehicle.stanleyHeadingErrorGain.ToString();

            hsbarIntegral.Value = (int)(Properties.Settings.Default.stanleyIntegralGainAB * 100);
            lblIntegralPercent.Text = ((int)(mf.vehicle.stanleyIntegralGainAB * 100)).ToString();

            hsbarIntegralPurePursuit.Value = (int)(Properties.Settings.Default.purePursuitIntegralGainAB * 100);
            lblPureIntegral.Text = ((int)(mf.vehicle.purePursuitIntegralGain * 100)).ToString();

            hsbarSideHillComp.Value = (int)(Properties.Settings.Default.setAS_sideHillComp * 100);
            mf.gyd.sideHillCompFactor = Properties.Settings.Default.setAS_sideHillComp;

            mf.vehicle.goalPointLookAheadMult = Properties.Settings.Default.setVehicle_goalPointLookAheadMult;
            hsbarLookAheadMult.Value = (Int16)(mf.vehicle.goalPointLookAheadMult * 10);
            lblLookAheadMult.Text = mf.vehicle.goalPointLookAheadMult.ToString();

            nudAntennaPivot.Value = (int)((Properties.Settings.Default.setVehicle_antennaPivot) * mf.m2InchOrCm);
            nudAntennaHeight.Value = (int)(Properties.Settings.Default.setVehicle_antennaHeight * mf.m2InchOrCm);
            nudAntennaOffset.Value = (int)(Properties.Settings.Default.setVehicle_antennaOffset * mf.m2InchOrCm);
            nudWheelbase.Value = (int)(Math.Abs(Properties.Settings.Default.setVehicle_wheelbase) * mf.m2InchOrCm);
            nudVehicleTrack.Value = (int)(Math.Abs(Properties.Settings.Default.setVehicle_trackWidth) * mf.m2InchOrCm);

            cboxDataInvertRoll.Checked = Properties.Settings.Default.setIMU_invertRoll;
            mf.ahrs.isRollInvert = Properties.Settings.Default.setIMU_invertRoll;

            lblRollZeroOffset.Text = ((double)Properties.Settings.Default.setIMU_rollZero).ToString("N2");
            mf.ahrs.rollZero = Properties.Settings.Default.setIMU_rollZero;
            lblRollZeroOffset.Text = "0.00";

            //make sure free drive is off
            btnFreeDrive.Image = Properties.Resources.SteerDriveOff;
            mf.vehicle.isInFreeDriveMode = false;
            btnSteerAngleDown.Enabled = false;
            btnSteerAngleUp.Enabled = false;
            btnFreeDriveZero.Enabled = false;
            //hSBarFreeDrive.Value = 0;
            mf.vehicle.driveFreeSteerAngle = 0;

            toSend252 = false;
            toSend251 = false;

            int sett = Properties.Settings.Default.setArdSteer_setting0;

            if ((sett & 1) == 0) chkInvertWAS.Checked = false;
            else chkInvertWAS.Checked = true;

            if ((sett & 2) == 0) chkSteerInvertRelays.Checked = false;
            else chkSteerInvertRelays.Checked = true;

            if ((sett & 4) == 0) chkInvertSteer.Checked = false;
            else chkInvertSteer.Checked = true;

            if ((sett & 8) == 0) cboxConv.Text = "Differential";
            else cboxConv.Text = "Single";

            if ((sett & 16) == 0) cboxMotorDrive.Text = "IBT2";
            else cboxMotorDrive.Text = "Cytron";

            if ((sett & 32) == 32) cboxSteerEnable.Text = "Switch";
            else if ((sett & 64) == 64) cboxSteerEnable.Text = "Button";
            else cboxSteerEnable.Text = "None";

            if ((sett & 128) == 0) cboxEncoder.Checked = false;
            else cboxEncoder.Checked = true;

            nudMaxCounts.Value = (decimal)Properties.Settings.Default.setArdSteer_maxPulseCounts;
            hsbarSensor.Value = (int)Properties.Settings.Default.setArdSteer_maxPulseCounts;
            lblhsbarSensor.Text = ((int)((double)hsbarSensor.Value * 0.3921568627)).ToString() + "%";

            sett = Properties.Settings.Default.setArdSteer_setting1;

            if ((sett & 1) == 0) cboxDanfoss.Checked = false;
            else cboxDanfoss.Checked = true;

            if ((sett & 2) == 0) cboxPressureSensor.Checked = false;
            else cboxPressureSensor.Checked = true;

            if ((sett & 4) == 0) cboxCurrentSensor.Checked = false;
            else cboxCurrentSensor.Checked = true;

            if (cboxEncoder.Checked)
            {
                cboxPressureSensor.Checked = false;
                cboxCurrentSensor.Checked = false;
                label61.Visible = true;
                lblPercentFS.Visible = true;
                nudMaxCounts.Visible = true;
                pbarSensor.Visible = false;
                hsbarSensor.Visible = false;
                lblhsbarSensor.Visible = false;
                label61.Text = gStr.gsEncoderCounts;
            }
            else if (cboxPressureSensor.Checked)
            {
                cboxEncoder.Checked = false;
                cboxCurrentSensor.Checked = false;
                label61.Visible = true;
                lblPercentFS.Visible = true;
                nudMaxCounts.Visible = false;
                pbarSensor.Visible = true;
                hsbarSensor.Visible = true;
                lblhsbarSensor.Visible = true;

                label61.Text = "Off at %";
            }
            else if (cboxCurrentSensor.Checked)
            {
                cboxPressureSensor.Checked = false;
                cboxEncoder.Checked = false;
                label61.Visible = true;
                lblPercentFS.Visible = true;
                nudMaxCounts.Visible = false;
                pbarSensor.Visible = true;
                hsbarSensor.Visible = true;
                lblhsbarSensor.Visible = true;

                label61.Text = "Off at %";
            }
            else
            {
                cboxPressureSensor.Checked = false;
                cboxCurrentSensor.Checked = false;
                cboxEncoder.Checked = false;
                label61.Visible = false;
                lblPercentFS.Visible = false;
                nudMaxCounts.Visible = false;
                pbarSensor.Visible = false;
                hsbarSensor.Visible = false;
                lblhsbarSensor.Visible = false;
                return;
            }

            if (!ScreenHelper.IsOnScreen(Bounds))
            {
                Top = 0;
                Left = 0;
            }
        }

        private void FormSteer_FormClosing(object sender, FormClosingEventArgs e)
        {
            mf.vehicle.isInFreeDriveMode = false;

            Properties.Settings.Default.stanleyHeadingErrorGain = mf.vehicle.stanleyHeadingErrorGain;
            Properties.Settings.Default.stanleyDistanceErrorGain = mf.vehicle.stanleyDistanceErrorGain;
            Properties.Settings.Default.stanleyIntegralGainAB = mf.vehicle.stanleyIntegralGainAB;

            Properties.Settings.Default.purePursuitIntegralGainAB = mf.vehicle.purePursuitIntegralGain;
            Properties.Settings.Default.setVehicle_goalPointLookAheadMult = mf.vehicle.goalPointLookAheadMult;

            Properties.Settings.Default.setVehicle_maxSteerAngle = mf.vehicle.maxSteerAngle;

            Properties.Settings.Default.setAS_countsPerDegree = mf.p_252.pgn[mf.p_252.countsPerDegree] = unchecked((byte)hsbarCountsPerDegree.Value);
            Properties.Settings.Default.setAS_ackerman = mf.p_252.pgn[mf.p_252.ackerman] = unchecked((byte)hsbarAckerman.Value);

            Properties.Settings.Default.setAS_wasOffset = hsbarWasOffset.Value;
            mf.p_252.pgn[mf.p_252.wasOffsetHi] = unchecked((byte)(hsbarWasOffset.Value >> 8));
            mf.p_252.pgn[mf.p_252.wasOffsetLo] = unchecked((byte)(hsbarWasOffset.Value));

            Properties.Settings.Default.setAS_highSteerPWM = mf.p_252.pgn[mf.p_252.highPWM] = unchecked((byte)hsbarHighSteerPWM.Value);
            Properties.Settings.Default.setAS_lowSteerPWM = mf.p_252.pgn[mf.p_252.lowPWM] = unchecked((byte)hsbarLowSteerPWM.Value);
            Properties.Settings.Default.setAS_Kp = mf.p_252.pgn[mf.p_252.gainProportional] = unchecked((byte)hsbarProportionalGain.Value);
            Properties.Settings.Default.setAS_minSteerPWM = mf.p_252.pgn[mf.p_252.minPWM] = unchecked((byte)hsbarMinPWM.Value);

            hsbarSideHillComp.Value = (int)(Properties.Settings.Default.setAS_sideHillComp * 100);

            Properties.Settings.Default.setIMU_invertRoll = mf.ahrs.isRollInvert;

            //save current vehicle
            Properties.Settings.Default.Save();
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            if (isSARight)
            {
                dist = glm.Distance(startFix, mf.pivotAxlePos);
                cntr++;
                if (dist > diameter)
                {
                    diameter = dist;
                    cntr = 0;
                }
                lblDiameter.Text = diameter.ToString("N2") + " m";

                if (cntr > 9)
                {
                    steerAngleRight = Math.Atan(mf.vehicle.VehicleConfig.Wheelbase / ((diameter - mf.vehicle.VehicleConfig.TrackWidth * 0.5) / 2));
                    steerAngleRight = glm.toDegrees(steerAngleRight);

                    lblCalcSteerAngleInner.Text = steerAngleRight.ToString("N1") + "\u00B0";
                    lblDiameter.Text = diameter.ToString("N2") + " m";
                    btnStartSA.Image = Properties.Resources.BoundaryRecord;
                    isSARight = false;

                    try
                    {
                        //force cpd a bit on the low side
                        double cpd = (mf.mc.actualSteerAngleDegrees / steerAngleRight * hsbarCountsPerDegree.Value);
                        cpd *= 0.9;
                        hsbarCountsPerDegree.Value = (int)cpd;
                        lblCPDError.Text = "CPD set to: " + hsbarCountsPerDegree.Value.ToString();
                    }
                    catch (Exception ed)
                    {
                        hsbarCountsPerDegree.Value = 100;
                        lblCPDError.Text = "Error, CPD set to 100";
                        Log.EventWriter("Error, CPD set to 100" + ed.ToString());
                    }
                }
            }

            if (isSALeft)
            {
                dist = glm.Distance(startFix, mf.pivotAxlePos);
                cntr++;
                if (dist > diameter)
                {
                    diameter = dist;
                    cntr = 0;
                }
                lblDiameterLeft.Text = diameter.ToString("N2") + " m";

                if (cntr > 9)
                {
                    steerAngleLeft = Math.Atan(mf.vehicle.VehicleConfig.Wheelbase / ((diameter - mf.vehicle.VehicleConfig.TrackWidth * 0.5) / 2));
                    steerAngleLeft = glm.toDegrees(steerAngleLeft);

                    lblCalcSteerAngleLeft.Text = steerAngleLeft.ToString("N1") + "\u00B0";
                    lblDiameterLeft.Text = diameter.ToString("N2") + " m";
                    btnStartSA_Left.Image = Properties.Resources.BoundaryRecord;
                    isSALeft = false;

                    try
                    {
                        hsbarAckerman.Value = (int)((steerAngleLeft / Math.Abs(startAngleLeft)) * 100);
                        lblAckermannError.Text = "Ackermann Set to: " + hsbarAckerman.Value.ToString();
                    }
                    catch (Exception eh)
                    {
                        hsbarAckerman.Value = 100;
                        lblAckermannError.Text = "Error, Ackermann set to 100";
                        Log.EventWriter("Error, Ackermann set to 100"+ eh.ToString());
                    }
                }
            }

            //steering bar
            double actAng = mf.mc.actualSteerAngleDegrees;
            if (actAng > 0)
            {
                if (actAng > 49) actAng = 49;
                CExtensionMethods.SetProgressNoAnimation(pbarRight, (int)actAng);
                pbarLeft.Value = 0;
            }
            else
            {
                if (actAng < -49) actAng = -49;
                pbarRight.Value = 0;
                CExtensionMethods.SetProgressNoAnimation(pbarLeft, (int)-actAng);
            }

            //wizard progress bar
            CExtensionMethods.SetProgressNoAnimation(pbarProgress, tabWiz.SelectedIndex);

            lblSteerAngle.Text = mf.SetSteerAngle;
            lblSteerAngleActual.Text = mf.mc.actualSteerAngleDegrees.ToString("N1") + "\u00B0";
            //lblActualSteerAngleUpper.Text = lblSteerAngleActual.Text;
            double err = (mf.mc.actualSteerAngleDegrees - mf.guidanceLineSteerAngle * 0.01);
            lblError.Text = Math.Abs(err).ToString("N1") + "\u00B0";
            if (err > 0) lblError.ForeColor = Color.Red;
            else lblError.ForeColor = Color.DarkGreen;

            lblPWMDisplay.Text = mf.mc.pwmDisplay.ToString();
            counter252++;
            counter251++;

            if (toSend252 && counter252 > 3)
            {
                Properties.Settings.Default.setAS_countsPerDegree = mf.p_252.pgn[mf.p_252.countsPerDegree] = unchecked((byte)hsbarCountsPerDegree.Value);
                Properties.Settings.Default.setAS_ackerman = mf.p_252.pgn[mf.p_252.ackerman] = unchecked((byte)hsbarAckerman.Value);

                Properties.Settings.Default.setAS_wasOffset = hsbarWasOffset.Value;
                mf.p_252.pgn[mf.p_252.wasOffsetHi] = unchecked((byte)(hsbarWasOffset.Value >> 8));
                mf.p_252.pgn[mf.p_252.wasOffsetLo] = unchecked((byte)(hsbarWasOffset.Value));

                Properties.Settings.Default.setAS_highSteerPWM = mf.p_252.pgn[mf.p_252.highPWM] = unchecked((byte)hsbarHighSteerPWM.Value);
                Properties.Settings.Default.setAS_lowSteerPWM = mf.p_252.pgn[mf.p_252.lowPWM] = unchecked((byte)hsbarLowSteerPWM.Value);
                Properties.Settings.Default.setAS_Kp = mf.p_252.pgn[mf.p_252.gainProportional] = unchecked((byte)hsbarProportionalGain.Value);
                Properties.Settings.Default.setAS_minSteerPWM = mf.p_252.pgn[mf.p_252.minPWM] = unchecked((byte)hsbarMinPWM.Value);

                Properties.Settings.Default.Save();

                mf.SendPgnToLoop(mf.p_252.pgn);
                toSend252 = false;
                counter252 = 0;
            }
            //*************************************************************
            else if (toSend251 && counter251 > 3)
            {
                int set = 1;
                int reset = 2046;
                int sett = 0;

                if (chkInvertWAS.Checked) sett |= set;
                else sett &= reset;

                set <<= 1;
                reset <<= 1;
                reset += 1;
                if (chkSteerInvertRelays.Checked) sett |= set;
                else sett &= reset;

                set <<= 1;
                reset <<= 1;
                reset += 1;
                if (chkInvertSteer.Checked) sett |= set;
                else sett &= reset;

                set <<= 1;
                reset <<= 1;
                reset += 1;
                if (cboxConv.Text == "Single") sett |= set;
                else sett &= reset;

                set <<= 1;
                reset <<= 1;
                reset += 1;
                if (cboxMotorDrive.Text == "Cytron") sett |= set;
                else sett &= reset;

                set <<= 1;
                reset <<= 1;
                reset += 1;
                if (cboxSteerEnable.Text == "Switch") sett |= set;
                else sett &= reset;

                set <<= 1;
                reset <<= 1;
                reset += 1;
                if (cboxSteerEnable.Text == "Button") sett |= set;
                else sett &= reset;

                set <<= 1;
                reset <<= 1;
                reset += 1;
                if (cboxEncoder.Checked) sett |= set;
                else sett &= reset;

                //set = (set << 1);
                //reset = (reset << 1);
                //reset = (reset + 1);
                //if ( ) sett |= set;
                //else sett &= reset;

                Properties.Settings.Default.setArdSteer_setting0 = (byte)sett;
                Properties.Settings.Default.setArdMac_isDanfoss = cboxDanfoss.Checked;

                if (cboxCurrentSensor.Checked || cboxPressureSensor.Checked)
                {
                    Properties.Settings.Default.setArdSteer_maxPulseCounts = (byte)hsbarSensor.Value;
                }
                else
                {
                    Properties.Settings.Default.setArdSteer_maxPulseCounts = (byte)nudMaxCounts.Value;
                }

                // Settings1
                set = 1;
                reset = 2046;
                sett = 0;

                if (cboxDanfoss.Checked) sett |= set;
                else sett &= reset;

                set <<= 1;
                reset <<= 1;
                reset += 1;
                if (cboxPressureSensor.Checked) sett |= set;
                else sett &= reset;

                set <<= 1;
                reset <<= 1;
                reset += 1;
                if (cboxCurrentSensor.Checked) sett |= set;
                else sett &= reset;

                Properties.Settings.Default.setArdSteer_setting1 = (byte)sett;

                Properties.Settings.Default.Save();

                mf.p_251.pgn[mf.p_251.set0] = Properties.Settings.Default.setArdSteer_setting0;
                mf.p_251.pgn[mf.p_251.set1] = Properties.Settings.Default.setArdSteer_setting1;
                mf.p_251.pgn[mf.p_251.maxPulse] = Properties.Settings.Default.setArdSteer_maxPulseCounts;
                mf.p_251.pgn[mf.p_251.minSpeed] = unchecked((byte)(Properties.Settings.Default.setAS_minSteerSpeed * 10)); //0.5 kmh

                mf.SendPgnToLoop(mf.p_251.pgn);

                toSend251 = false;
                counter251 = 0;
            }

            if (hsbarMinPWM.Value > hsbarLowSteerPWM.Value) lblMinPWM.ForeColor = Color.OrangeRed;
            else lblMinPWM.ForeColor = SystemColors.ControlText;

            if (mf.mc.sensorData != -1)
            {
                if (mf.mc.sensorData < 0 || mf.mc.sensorData > 255) mf.mc.sensorData = 0;
                CExtensionMethods.SetProgressNoAnimation(pbarSensor, mf.mc.sensorData);
                lblPercentFS.Text = ((int)((double)mf.mc.sensorData * 0.3921568627)).ToString() + "%";
            }

            // Emulate the OGL Steer circle
            if (mf.mc.steerSwitchHigh)
                btnSteerStatus.BackColor = Color.Red;
            else if (mf.isBtnAutoSteerOn)
                btnSteerStatus.BackColor = Color.Green;
            else
                btnSteerStatus.BackColor = Color.Yellow;

            //we have lost connection to steer module
            if (mf.steerModuleConnectedCounter > 30)
            {
                btnSteerStatus.BackColor = Color.Magenta;
            }
        }

        private void sideBarTimer_Tick(object sender, EventArgs e)
        {
            //roll zero
            if (tabWiz.SelectedTab.Name == "tabWAS_Zero") lblCurrentHeading.Text = mf.Heading;

            //ackermann
            else if (tabWiz.SelectedTab.Name == "tabAckCPD")
            {
                if (hsbarAckerman.Value != 100)
                {
                    btnStartSA_Left.Enabled = false;
                }
                else
                {
                    btnStartSA_Left.Enabled = true;
                }
            }

            //roll invert
            else if (tabWiz.SelectedTab.Name == "tabRollInv")
            {
                lblRoll.Text = mf.RollInDegrees;
            }

            //roll zero
            else if (tabWiz.SelectedTab.Name == "tabRollZero")
            {
                lblRoll2.Text = mf.RollInDegrees;
            }

            lblBarAck.Text = hsbarAckerman.Value.ToString();
            lblBarWasOffset.Text = hsbarWasOffset.Value.ToString();
            lblBarCPD.Text = hsbarCountsPerDegree.Value.ToString();
        }

        #region ButtonControl

        private void btnLoadDefaults_Click(object sender, EventArgs e)
        {
            mf.TimedMessageBox(2000, "Reset To Default", "Values Set to Inital Default");
            Properties.Settings.Default.setVehicle_maxSteerAngle = mf.vehicle.maxSteerAngle
                = 45;

            Properties.Settings.Default.setAS_countsPerDegree = 100;

            Properties.Settings.Default.setAS_ackerman = 100;

            Properties.Settings.Default.setAS_wasOffset = 0;

            Properties.Settings.Default.setAS_highSteerPWM = 150;
            Properties.Settings.Default.setAS_lowSteerPWM = 30;
            Properties.Settings.Default.setAS_Kp = 120;
            Properties.Settings.Default.setAS_minSteerPWM = 25;

            Properties.Settings.Default.setArdSteer_setting0 = 56;
            Properties.Settings.Default.setArdSteer_setting1 = 0;
            Properties.Settings.Default.setArdMac_isDanfoss = false;

            Properties.Settings.Default.setArdSteer_maxPulseCounts = 0;

            Properties.Settings.Default.setVehicle_goalPointLookAheadMult = 1;

            Properties.Settings.Default.stanleyHeadingErrorGain = 1;
            Properties.Settings.Default.stanleyDistanceErrorGain = 1;
            Properties.Settings.Default.stanleyIntegralGainAB = 0;

            Properties.Settings.Default.purePursuitIntegralGainAB = 0;

            Properties.Settings.Default.setAS_sideHillComp = 0;

            Properties.Settings.Default.setVehicle_wheelbase = 2.8;

            Properties.Settings.Default.setVehicle_trackWidth = 1.9;

            Properties.Settings.Default.setVehicle_antennaPivot = 0.1;

            Properties.Settings.Default.setVehicle_antennaHeight = 3;

            Properties.Settings.Default.setVehicle_antennaOffset = 0;

            Properties.Settings.Default.setIMU_invertRoll = false;

            Properties.Settings.Default.setIMU_rollZero = mf.ahrs.rollZero;

            toSend252 = true;
            counter252 = 3;
            toSend251 = true;
            counter251 = 2;

            //save current vehicle
            Properties.Settings.Default.Save();

            FormSteer_Load(this, e);
        }

        private void btnStartWizard_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            isWizardStarted = true;
            tabWiz.SelectedIndex++;
        }

        private void btnStopWizard_Click(object sender, EventArgs e)
        {
            isWizardStarted = false;
            FreeDrive(false);
            tabWiz.SelectedIndex = 0;
            panel1.Visible = true;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        #endregion ButtonControl

        #region Wizard

        private void nudMaxCounts_Click(object sender, EventArgs e)
        {
            if (((NudlessNumericUpDown)sender).ShowKeypad(this))
            {
                if (isWizardStarted)
                {
                    toSend251 = true;
                    counter251 = 0;
                }
            }
        }

        private void cboxMotorDrive_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (isWizardStarted)
            {
                toSend251 = true;
                counter251 = 0;
            }
        }

        private void cboxConv_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (isWizardStarted)
            {
                toSend251 = true;
                counter251 = 0;
            }
        }

        private void chkInvertWAS_CheckedChanged(object sender, EventArgs e)
        {
            if (isWizardStarted)
            {
                toSend251 = true;
                counter251 = 0;
            }
        }

        private void chkInvertSteer_CheckedChanged(object sender, EventArgs e)
        {
            if (isWizardStarted)
            {
                toSend251 = true;
                counter251 = 0;
            }
        }

        private void cboxSteerEnable_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (isWizardStarted)
            {
                toSend251 = true;
                counter251 = 0;
            }
        }

        private void cboxDanfoss_CheckedChanged(object sender, EventArgs e)
        {
            if (isWizardStarted)
            {
                toSend251 = true;
                counter251 = 0;
            }
        }

        private void chkSteerInvertRelays_CheckedChanged(object sender, EventArgs e)
        {
            if (isWizardStarted)
            {
                toSend251 = true;
                counter251 = 0;
            }
        }

        private void cboxCancelGuidance_Click(object sender, EventArgs e)
        {
            if (sender is CheckBox checkbox)
            {
                if (checkbox.Name == "cboxEncoder" || checkbox.Name == "cboxPressureSensor"
                    || checkbox.Name == "cboxCurrentSensor")
                {
                    if (!checkbox.Checked)
                    {
                        cboxPressureSensor.Checked = false;
                        cboxCurrentSensor.Checked = false;
                        cboxEncoder.Checked = false;
                        label61.Visible = false;
                        lblPercentFS.Visible = false;
                        nudMaxCounts.Visible = false;
                        pbarSensor.Visible = false;
                        hsbarSensor.Visible = false;
                        lblhsbarSensor.Visible = false;
                        if (isWizardStarted)
                        {
                            toSend251 = true;
                            counter251 = 0;
                        }
                        return;
                    }

                    if (checkbox == cboxPressureSensor)
                    {
                        cboxEncoder.Checked = false;
                        cboxCurrentSensor.Checked = false;
                        label61.Visible = true;
                        lblPercentFS.Visible = true;
                        nudMaxCounts.Visible = false;
                        pbarSensor.Visible = true;
                        label61.Text = "Off at %";
                        hsbarSensor.Visible = true;
                        lblhsbarSensor.Visible = true;
                    }
                    else if (checkbox == cboxCurrentSensor)
                    {
                        cboxPressureSensor.Checked = false;
                        cboxEncoder.Checked = false;
                        label61.Visible = true;
                        lblPercentFS.Visible = true;
                        nudMaxCounts.Visible = false;
                        hsbarSensor.Visible = true;
                        pbarSensor.Visible = true;
                        label61.Text = "Off at %";
                        lblhsbarSensor.Visible = true;
                    }
                    else if (checkbox == cboxEncoder)
                    {
                        cboxPressureSensor.Checked = false;
                        cboxCurrentSensor.Checked = false;
                        label61.Visible = true;
                        lblPercentFS.Visible = false;
                        nudMaxCounts.Visible = true;
                        pbarSensor.Visible = false;
                        hsbarSensor.Visible = false;
                        lblhsbarSensor.Visible = false;
                        label61.Text = gStr.gsEncoderCounts;
                    }
                }
            }

            if (isWizardStarted)
            {
                toSend251 = true;
                counter251 = 0;
            }
        }

        private void btnOkNextCancelGuidance_Click(object sender, EventArgs e)
        {
            //btnSendSteerConfigPGN.PerformClick();
            tabWiz.SelectedIndex = (tabWiz.SelectedIndex + 1 < tabWiz.TabCount) ?
                tabWiz.SelectedIndex + 1 : tabWiz.SelectedIndex;
        }

        private void hsbarSensor_Scroll(object sender, ScrollEventArgs e)
        {
            lblhsbarSensor.Text = ((int)((double)hsbarSensor.Value * 0.3921568627)).ToString() + "%";
            if (isWizardStarted)
            {
                toSend251 = true;
                counter251 = 0;
            }
        }

        private void btnOkNext_Click(object sender, EventArgs e)
        {
            tabWiz.SelectedIndex = (tabWiz.SelectedIndex + 1 < tabWiz.TabCount) ?
                 tabWiz.SelectedIndex + 1 : tabWiz.SelectedIndex;
            lblCPDError.Text = "...";
            lblAckermannError.Text = "...";
            lblStartAngleLeft.Text = "...";
            lblRightStartAngle.Text = "...";
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            if (tabWiz.SelectedTab == tabWiz.TabPages["tabMaxSteerAngle"])
            {
                tabWiz.SelectedIndex = (tabWiz.SelectedIndex - 3 < tabWiz.TabCount) ?
                                 tabWiz.SelectedIndex - 3 : tabWiz.SelectedIndex;
            }
            else
            {
                tabWiz.SelectedIndex = (tabWiz.SelectedIndex - 1 < tabWiz.TabCount) ?
                                 tabWiz.SelectedIndex - 1 : tabWiz.SelectedIndex;
            }

            lblCPDError.Text = "...";
            lblAckermannError.Text = "...";
            lblStartAngleLeft.Text = "...";
            lblRightStartAngle.Text = "...";
        }

        private void btnSkipCPD_Setup_Click(object sender, EventArgs e)
        {
            tabWiz.SelectedIndex = (tabWiz.SelectedIndex + 3 < tabWiz.TabCount) ?
                tabWiz.SelectedIndex + 3 : tabWiz.SelectedIndex;
        }

        private void btnOKNext_CPDSetup_Click(object sender, EventArgs e)
        {
            mf.TimedMessageBox(3000, "Defaults Set", "CPD and Ackermann set to defaults");
            hsbarCountsPerDegree.Value = 100;
            hsbarAckerman.Value = 100;

            tabWiz.SelectedIndex = (tabWiz.SelectedIndex + 1 < tabWiz.TabCount) ?
             tabWiz.SelectedIndex + 1 : tabWiz.SelectedIndex;
        }

        private void btnRemoveWasOffset_Click(object sender, EventArgs e)
        {
            hsbarWasOffset.Value = 0;
        }

        private void btnRestartWizard_Click(object sender, EventArgs e)
        {
            isWizardStarted = false;
            FreeDrive(false);
            tabWiz.SelectedIndex = 0;
        }

        private void tabMotorDirection_Enter(object sender, EventArgs e)
        {
            FreeDrive(true);
        }

        private void tabMotorDirection_Leave(object sender, EventArgs e)
        {
            FreeDrive(false);
        }

        private void FreeDrive(bool isOn)
        {
            if (isOn)
            {
                mf.vehicle.isInFreeDriveMode = true;
                mf.vehicle.driveFreeSteerAngle = 0;
                lblSteerAngle.Text = "0";
            }
            else
            {
                mf.vehicle.isInFreeDriveMode = false;
                mf.vehicle.driveFreeSteerAngle = 0;
                lblSteerAngle.Text = "0";
            }
        }

        #endregion Wizard

        #region Gain

        private void hsbarMinPWM_ValueChanged(object sender, EventArgs e)
        {
            lblMinPWM.Text = unchecked((byte)hsbarMinPWM.Value).ToString();
            hsbarLowSteerPWM.Value = hsbarMinPWM.Value + 2;
            if (isWizardStarted)
            {
                toSend252 = true;
                counter252 = 0;
            }
        }

        private void hsbarProportionalGain_ValueChanged(object sender, EventArgs e)
        {
            lblProportionalGain.Text = unchecked((byte)hsbarProportionalGain.Value).ToString();
            if (isWizardStarted)
            {
                toSend252 = true;
                counter252 = 0;
            }
        }

        private void hsbarLowSteerPWM_ValueChanged(object sender, EventArgs e)
        {
            if (hsbarLowSteerPWM.Value > hsbarHighSteerPWM.Value) hsbarHighSteerPWM.Value = hsbarLowSteerPWM.Value;
            lblLowSteerPWM.Text = unchecked((byte)hsbarLowSteerPWM.Value).ToString();
            if (isWizardStarted)
            {
                toSend252 = true;
                counter252 = 0;
            }
        }

        private void hsbarHighSteerPWM_ValueChanged(object sender, EventArgs e)
        {
            if (hsbarLowSteerPWM.Value > hsbarHighSteerPWM.Value) hsbarLowSteerPWM.Value = hsbarHighSteerPWM.Value;
            lblHighSteerPWM.Text = unchecked((byte)hsbarHighSteerPWM.Value).ToString();
            if (isWizardStarted)
            {
                toSend252 = true;
                counter252 = 0;
            }
        }

        #endregion Gain

        #region WAS

        private void hsbarAckerman_ValueChanged(object sender, EventArgs e)
        {
            lblAckerman.Text = unchecked((byte)hsbarAckerman.Value).ToString();

            if (isWizardStarted)
            {
                toSend252 = true;
                counter252 = 0;
            }
        }

        private void hsbarMaxSteerAngle_ValueChanged(object sender, EventArgs e)
        {
            mf.vehicle.maxSteerAngle = hsbarMaxSteerAngle.Value;
            lblMaxSteerAngle.Text = hsbarMaxSteerAngle.Value.ToString();
        }

        private void hsbarCountsPerDegree_ValueChanged(object sender, EventArgs e)
        {
            lblCountsPerDegree.Text = unchecked((byte)hsbarCountsPerDegree.Value).ToString();
            lblSteerAngleSensorZero.Text = (hsbarWasOffset.Value / (double)(hsbarCountsPerDegree.Value)).ToString("N2");
            if (isWizardStarted)
            {
                toSend252 = true;
                counter252 = 0;
            }
        }

        private void hsbarSteerAngleSensorZero_ValueChanged(object sender, EventArgs e)
        {
            lblSteerAngleSensorZero.Text = (hsbarWasOffset.Value / (double)(hsbarCountsPerDegree.Value)).ToString("N2");
            if (isWizardStarted)
            {
                toSend252 = true;
                counter252 = 0;
            }
        }

        private void btnZeroWAS_Click(object sender, EventArgs e)
        {
            int offset = (int)(hsbarCountsPerDegree.Value * -mf.mc.actualSteerAngleDegrees + hsbarWasOffset.Value);
            if (Math.Abs(offset) > 3900) mf.TimedMessageBox(2000, "Exceeded Range", "Excessive Steer Angle - Cannot Zero");
            else
            {
                hsbarWasOffset.Value += (int)(hsbarCountsPerDegree.Value * -mf.mc.actualSteerAngleDegrees);
            }
            if (isWizardStarted)
            {
                toSend252 = true;
                counter252 = 0;
            }
        }

        private void btnStartSA_Click(object sender, EventArgs e)
        {
            if (!isSARight)
            {
                isSARight = true;
                startFix = mf.pivotAxlePos;
                dist = 0;
                diameter = 0;
                cntr = 0;
                btnStartSA.Image = Properties.Resources.boundaryStop;
                lblDiameter.Text = "0";
                lblCalcSteerAngleInner.Text = "Drive Steady";
                lblRightStartAngle.Text = mf.mc.actualSteerAngleDegrees.ToString("N1");
            }
            else
            {
                isSARight = false;
                lblCalcSteerAngleInner.Text = "0.0" + "\u00B0";
                btnStartSA.Image = Properties.Resources.BoundaryRecord;
                lblRightStartAngle.Text = "..." + "\u00B0";
            }

            lblCPDError.Text = "...";
        }

        private void btnStartSA_Left_Click(object sender, EventArgs e)
        {
            if (!isSALeft)
            {
                isSALeft = true;
                startFix = mf.pivotAxlePos;
                startAngleLeft = mf.mc.actualSteerAngleDegrees;
                dist = 0;
                diameter = 0;
                cntr = 0;
                btnStartSA_Left.Image = Properties.Resources.boundaryStop;
                lblDiameterLeft.Text = "0";
                lblCalcSteerAngleLeft.Text = "Drive Steady";
                lblStartAngleLeft.Text = startAngleLeft.ToString("N1") + "\u00B0";
            }
            else
            {
                isSALeft = false;
                lblCalcSteerAngleLeft.Text = "..." + "\u00B0";
                btnStartSA_Left.Image = Properties.Resources.BoundaryRecord;
            }

            lblAckermannError.Text = "...";
        }

        #endregion WAS

        #region Stanley

        private void hsbarStanleyGain_ValueChanged(object sender, EventArgs e)
        {
            mf.vehicle.stanleyDistanceErrorGain = hsbarStanleyGain.Value * 0.1;
            lblStanleyGain.Text = mf.vehicle.stanleyDistanceErrorGain.ToString();
        }

        private void hsbarHeadingErrorGain_ValueChanged(object sender, EventArgs e)
        {
            mf.vehicle.stanleyHeadingErrorGain = hsbarHeadingErrorGain.Value * 0.1;
            lblHeadingErrorGain.Text = mf.vehicle.stanleyHeadingErrorGain.ToString();
        }

        private void hsbarIntegral_ValueChanged(object sender, EventArgs e)
        {
            mf.vehicle.stanleyIntegralGainAB = hsbarIntegral.Value * 0.01;
            lblIntegralPercent.Text = hsbarIntegral.Value.ToString();
        }

        #endregion Stanley

        #region Pure

        private void hsbarIntegralPurePursuit_ValueChanged(object sender, EventArgs e)
        {
            mf.vehicle.purePursuitIntegralGain = hsbarIntegralPurePursuit.Value * 0.01;
            lblPureIntegral.Text = hsbarIntegralPurePursuit.Value.ToString();
        }

        private void hsbarSideHillComp_ValueChanged(object sender, EventArgs e)
        {
            double deg = hsbarSideHillComp.Value;
            deg *= 0.01;
            lblSideHillComp.Text = (deg.ToString("N2") + "\u00B0");
            Properties.Settings.Default.setAS_sideHillComp = deg;
            mf.gyd.sideHillCompFactor = deg;
        }

        //private void hsbarLookAhead_ValueChanged(object sender, EventArgs e)
        //{
        //    mf.vehicle.goalPointLookAhead = hsbarLookAhead.Value * 0.1;
        //    lblLookAhead.Text = mf.vehicle.goalPointLookAhead.ToString();
        //    //mf.AutoSteerSettingsOutToPort();
        //}

        private void btnOkSetMaximumSteerAngle_Click(object sender, EventArgs e)
        {
            if (Math.Abs((int)mf.mc.actualSteerAngleDegrees) < 5)
            {
                mf.TimedMessageBox(1500, "Steer Angle Too Low", "Must be Greater than 5 degrees");
                return;
            }

            hsbarMaxSteerAngle.Value = Math.Abs((int)(mf.mc.actualSteerAngleDegrees));
        }

        private void hsbarLookAheadMult_ValueChanged(object sender, EventArgs e)
        {
            mf.vehicle.goalPointLookAheadMult = hsbarLookAheadMult.Value * 0.1;
            lblLookAheadMult.Text = mf.vehicle.goalPointLookAheadMult.ToString();
        }

        #endregion Pure

        #region MinMovement

        private void btnMinGainLeft_Click(object sender, EventArgs e)
        {
            if (CheckSteerSwitch())
                mf.vehicle.driveFreeSteerAngle -= 2;
            else
                mf.TimedMessageBox(1500, "Steering Disabled", "Enable Steer Switch");
        }

        private void btnMinGainRight_Click(object sender, EventArgs e)
        {
            if (CheckSteerSwitch())
                mf.vehicle.driveFreeSteerAngle += 2;
            else
                mf.TimedMessageBox(1500, "Steering Disabled", "Enable Steer Switch");
        }

        private void btnZeroMinMovementSetting_Click(object sender, EventArgs e)
        {
            if (CheckSteerSwitch())
                mf.vehicle.driveFreeSteerAngle = 0;
            else
                mf.TimedMessageBox(1500, "Steering Disabled", "Enable Steer Switch");
        }

        private void tab_MinimumGain_Enter(object sender, EventArgs e)
        {
            hsbarProportionalGain.Value = 1;
            FreeDrive(true);
            mf.TimedMessageBox(2000, "P Gain Change", "Proportional Gain set to 1");
        }

        private void tab_MinimumGain_Leave(object sender, EventArgs e)
        {
            FreeDrive(false);
            hsbarProportionalGain.Value = 40;
        }

        private void tabPGain_Enter(object sender, EventArgs e)
        {
            FreeDrive(true);
        }

        private void tabPGain_Leave(object sender, EventArgs e)
        {
            FreeDrive(false);
        }

        private void btnZeroPGain_Click(object sender, EventArgs e)
        {
            if (mf.vehicle.driveFreeSteerAngle == 0)
                mf.vehicle.driveFreeSteerAngle = 5;
            else mf.vehicle.driveFreeSteerAngle = 0;
        }

        private void btnLeftPGain_Click(object sender, EventArgs e)
        {
            mf.vehicle.driveFreeSteerAngle--;
            if (mf.vehicle.driveFreeSteerAngle < -40) mf.vehicle.driveFreeSteerAngle = -40;
        }

        private void btnRightPGain_Click(object sender, EventArgs e)
        {
            mf.vehicle.driveFreeSteerAngle++;
            if (mf.vehicle.driveFreeSteerAngle > 40) mf.vehicle.driveFreeSteerAngle = 40;
        }

        private void nudWheelbase_Click(object sender, EventArgs e)
        {
            if (((NudlessNumericUpDown)sender).ShowKeypad(this))
            {
                Properties.Settings.Default.setVehicle_wheelbase = (double)nudWheelbase.Value * mf.inchOrCm2m;
                mf.vehicle.VehicleConfig.Wheelbase = Properties.Settings.Default.setVehicle_wheelbase;
                Properties.Settings.Default.Save();
            }
        }

        private void nudVehicleTrack_Click(object sender, EventArgs e)
        {
            if (((NudlessNumericUpDown)sender).ShowKeypad(this))
            {
                Properties.Settings.Default.setVehicle_trackWidth = (double)nudVehicleTrack.Value * mf.inchOrCm2m;
                mf.vehicle.VehicleConfig.TrackWidth = Properties.Settings.Default.setVehicle_trackWidth;
                mf.tram.halfWheelTrack = mf.vehicle.VehicleConfig.TrackWidth * 0.5;
                Properties.Settings.Default.Save();
            }
        }

        private void nudAntennaPivot_Click(object sender, EventArgs e)
        {
            if (((NudlessNumericUpDown)sender).ShowKeypad(this))
            {
                Properties.Settings.Default.setVehicle_antennaPivot = (double)nudAntennaPivot.Value * mf.inchOrCm2m;
                mf.vehicle.VehicleConfig.AntennaPivot = Properties.Settings.Default.setVehicle_antennaPivot;
                Properties.Settings.Default.Save();
            }
        }

        private void btnAckReset_Click(object sender, EventArgs e)
        {
            hsbarAckerman.Value = 100;
        }

        private void cboxDataInvertRoll_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.setIMU_invertRoll = cboxDataInvertRoll.Checked;
            mf.ahrs.isRollInvert = Properties.Settings.Default.setIMU_invertRoll;
        }

        private void btnZeroRoll_Click(object sender, EventArgs e)
        {
            if (mf.ahrs.imuRoll != 88888)
            {
                mf.ahrs.imuRoll += mf.ahrs.rollZero;
                mf.ahrs.rollZero = mf.ahrs.imuRoll;
                lblRollZeroOffset.Text = (mf.ahrs.rollZero).ToString("N2");
            }
            else
            {
                lblRollZeroOffset.Text = "***";
            }

            Properties.Settings.Default.setIMU_rollZero = mf.ahrs.rollZero;
        }

        private void btnRemoveZeroOffset_Click(object sender, EventArgs e)
        {
            mf.ahrs.rollZero = 0;
            lblRollZeroOffset.Text = "0.00";
            Properties.Settings.Default.setIMU_rollZero = mf.ahrs.rollZero;
        }

        private void tabRollInv_Click(object sender, EventArgs e)
        {

        }

        private void label95_Click(object sender, EventArgs e)
        {

        }

        private void nudAntennaHeight_Click(object sender, EventArgs e)
        {
            if (((NudlessNumericUpDown)sender).ShowKeypad(this))
            {
                Properties.Settings.Default.setVehicle_antennaHeight = (double)nudAntennaHeight.Value * mf.inchOrCm2m;
                mf.vehicle.VehicleConfig.AntennaHeight = Properties.Settings.Default.setVehicle_antennaHeight;
                Properties.Settings.Default.Save();
            }
        }

        private void nudAntennaOffset_Click(object sender, EventArgs e)
        {
            if (((NudlessNumericUpDown)sender).ShowKeypad(this))
            {
                Properties.Settings.Default.setVehicle_antennaOffset = (double)nudAntennaOffset.Value * mf.inchOrCm2m;
                mf.vehicle.VehicleConfig.AntennaOffset = Properties.Settings.Default.setVehicle_antennaOffset;
                Properties.Settings.Default.Save();
            }
        }

        private bool CheckSteerSwitch()
        {
            return (btnSteerStatus.BackColor == Color.Yellow);
        }

        #endregion MinMovement

        #region Free Drive

        private void btnFreeDrive_Click(object sender, EventArgs e)
        {
            if (mf.vehicle.isInFreeDriveMode)
            {
                //turn OFF free drive mode
                btnFreeDrive.Image = Properties.Resources.SteerDriveOff;
                btnFreeDrive.BackColor = Color.FromArgb(50, 50, 70);
                mf.vehicle.isInFreeDriveMode = false;
                btnSteerAngleDown.Enabled = false;
                btnSteerAngleUp.Enabled = false;
                btnFreeDriveZero.Enabled = false;
                mf.vehicle.driveFreeSteerAngle = 0;
            }
            else
            {
                //turn ON free drive mode
                btnFreeDrive.Image = Properties.Resources.SteerDriveOn;
                btnFreeDrive.BackColor = Color.LightGreen;
                mf.vehicle.isInFreeDriveMode = true;
                btnSteerAngleDown.Enabled = true;
                btnSteerAngleUp.Enabled = true;
                btnFreeDriveZero.Enabled = true;
                mf.vehicle.driveFreeSteerAngle = 0;
                lblSteerAngle.Text = "0";
            }
        }

        private void btnSteerLeft_Click(object sender, EventArgs e)
        {
            mf.vehicle.driveFreeSteerAngle--;
            if (mf.vehicle.driveFreeSteerAngle < -40) mf.vehicle.driveFreeSteerAngle = -40;
        }

        private void btnSteerRight_Click(object sender, EventArgs e)
        {
            mf.vehicle.driveFreeSteerAngle++;
            if (mf.vehicle.driveFreeSteerAngle > 40) mf.vehicle.driveFreeSteerAngle = 40;
        }

        private void btnFreeDriveZero_Click(object sender, EventArgs e)
        {
            if (mf.vehicle.driveFreeSteerAngle == 0)
                mf.vehicle.driveFreeSteerAngle = 5;
            else mf.vehicle.driveFreeSteerAngle = 0;
            //hSBarFreeDrive.Value = mf.driveFreeSteerAngle;
        }

        private void btnSteerAngleUp_MouseDown(object sender, MouseEventArgs e)
        {
            mf.vehicle.driveFreeSteerAngle++;
            if (mf.vehicle.driveFreeSteerAngle > 40) mf.vehicle.driveFreeSteerAngle = 40;
        }

        private void btnSteerAngleDown_MouseDown(object sender, MouseEventArgs e)
        {
            mf.vehicle.driveFreeSteerAngle--;
            if (mf.vehicle.driveFreeSteerAngle < -40) mf.vehicle.driveFreeSteerAngle = -40;
        }

        #endregion Free Drive
    }
}