﻿//Please, if you use this, share the improvements

using AgLibrary.Logging;
using AgOpenGPS.Properties;
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Reflection.Emit;
using System.Windows.Forms;
using AgOpenGPS.Culture;

namespace AgOpenGPS
{
    public partial class FormAllSettings : Form
    {
        //class variables
        private readonly FormGPS mf = null;

        public FormAllSettings(Form callingForm)
        {
            //get copy of the calling main form
            mf = callingForm as FormGPS;
            InitializeComponent();

            //Language keys
        }

        private void LoadLabels()
        {
            label4.Text = Properties.Settings.Default.setVehicle_maxSteerAngle.ToString();
            label6.Text = Properties.Settings.Default.setAS_countsPerDegree.ToString();
            label8.Text = Properties.Settings.Default.setAS_ackerman.ToString();
            label10.Text = Properties.Settings.Default.setAS_wasOffset.ToString();
            label12.Text = Properties.Settings.Default.setAS_highSteerPWM.ToString();
            label14.Text = Properties.Settings.Default.setAS_lowSteerPWM.ToString();
            label16.Text = Properties.Settings.Default.setAS_minSteerPWM.ToString();
            label18.Text = Properties.Settings.Default.setAS_Kp.ToString();
            label20.Text = Properties.Settings.Default.setVehicle_panicStopSpeed.ToString();
           
            label22.Text = Properties.Settings.Default.setVehicle_goalPointAcquireFactor.ToString("N2");
            label24.Text = Properties.Settings.Default.setVehicle_goalPointLookAheadHold.ToString();
            label168.Text = Properties.Settings.Default.setVehicle_goalPointLookAheadMult.ToString();
            label26.Text = Properties.Settings.Default.stanleyHeadingErrorGain.ToString();
            label28.Text = Properties.Settings.Default.stanleyDistanceErrorGain.ToString();
            label30.Text = Properties.Settings.Default.stanleyIntegralGainAB.ToString();
            label32.Text = Properties.Settings.Default.setAS_sideHillComp.ToString();
            label34.Text = Properties.Settings.Default.setVehicle_wheelbase.ToString();
            label36.Text = Properties.Settings.Default.setVehicle_trackWidth.ToString();
            label38.Text = Properties.Settings.Default.setVehicle_antennaPivot.ToString();
            label40.Text = Properties.Settings.Default.setVehicle_antennaHeight.ToString();
            label42.Text = Properties.Settings.Default.setVehicle_antennaOffset.ToString();
            label46.Text = Properties.Settings.Default.setIMU_rollZero.ToString();
            label48.Text = Properties.Settings.Default.purePursuitIntegralGainAB.ToString();
            label50.Text = Properties.Settings.Default.setAS_snapDistance.ToString();
            label52.Text = Properties.Settings.Default.setAS_snapDistanceRef.ToString();
            label56.Text = Properties.Settings.Default.setDisplay_isAutoStartAgIO.ToString();
            label58.Text = Properties.Settings.Default.setDisplay_isAutoOffAgIO.ToString();

            label60.Text = RegistrySettings.culture;
            label64.Text = Properties.Settings.Default.setF_isRemoteWorkSystemOn.ToString();
            label66.Text = Properties.Settings.Default.setF_isSteerWorkSwitchEnabled.ToString(); 
            label68.Text = Properties.Settings.Default.setF_isSteerWorkSwitchManualSections.ToString();
            label70.Text = Properties.Settings.Default.setF_isWorkSwitchActiveLow.ToString();
            label72.Text = Properties.Settings.Default.setF_isWorkSwitchEnabled.ToString();
            label74.Text = Properties.Settings.Default.setF_isWorkSwitchManualSections.ToString();
            label76.Text = Properties.Settings.Default.setF_minHeadingStepDistance.ToString();
            label78.Text = RegistrySettings.vehiclesDirectory + " -> " 
                    + RegistrySettings.vehicleFileName + ".xml";
            
            label80.Text = Properties.Settings.Default.setGPS_ageAlarm.ToString();
            label82.Text = Properties.Settings.Default.setGPS_dualHeadingOffset.ToString();
            label84.Text = Properties.Settings.Default.setGPS_dualReverseDetectionDistance.ToString();
            label88.Text = Properties.Settings.Default.setGPS_headingFromWhichSource.ToString();
            label92.Text = Properties.Settings.Default.setGPS_isRTK.ToString();
            label94.Text = Properties.Settings.Default.setGPS_isRTK_KillAutoSteer.ToString();
            label96.Text = Properties.Settings.Default.setGPS_minimumStepLimit.ToString();
            label98.Text = Properties.Settings.Default.setHeadland_isSectionControlled.ToString();
            label100.Text = Properties.Settings.Default.setIMU_fusionWeight2.ToString();
            label102.Text = Properties.Settings.Default.setIMU_invertRoll.ToString();
            label104.Text = Properties.Settings.Default.setIMU_isDualAsIMU.ToString();
            label106.Text = Properties.Settings.Default.setIMU_isReverseOn.ToString();
            label108.Text = Properties.Settings.Default.setIMU_rollFilter.ToString();
            label110.Text = Properties.Settings.Default.setSection_isFast.ToString();
            label112.Text = Properties.Settings.Default.setTool_isSectionOffWhenOut.ToString();
            label114.Text = Properties.Settings.Default.setTool_isSectionsNotZones.ToString();
            label116.Text = Properties.Settings.Default.setTool_isToolFront.ToString();
            label118.Text = Properties.Settings.Default.setTool_isToolRearFixed.ToString();
            label120.Text = Properties.Settings.Default.setTool_isToolTBT.ToString();
            label122.Text = Properties.Settings.Default.setTool_isToolTrailing.ToString();

            label124.Text = Properties.Settings.Default.setTool_toolTrailingHitchLength.ToString();
            label126.Text = Properties.Settings.Default.setTool_trailingToolToPivotLength.ToString();
            label128.Text = Properties.Settings.Default.setVehicle_hitchLength.ToString();
            label130.Text = Properties.Settings.Default.setVehicle_hydraulicLiftLookAhead.ToString();
            label132.Text = "*****";
            label134.Text = Properties.Settings.Default.setVehicle_isStanleyUsed.ToString();
            label136.Text = "*****";
            label138.Text = Properties.Settings.Default.setVehicle_maxAngularVelocity.ToString();
            label140.Text = Properties.Settings.Default.set_youTurnRadius.ToString();
            label142.Text = Properties.Settings.Default.setVehicle_numSections.ToString();
            label144.Text = Properties.Settings.Default.setVehicle_slowSpeedCutoff.ToString();
            label146.Text = Properties.Settings.Default.setVehicle_tankTrailingHitchLength.ToString();
            label148.Text = Properties.Settings.Default.setVehicle_toolLookAheadOn.ToString();
            label150.Text = Properties.Settings.Default.setVehicle_toolLookAheadOff.ToString();
            label152.Text = Properties.Settings.Default.setVehicle_toolOffDelay.ToString();
            label154.Text = Properties.Settings.Default.setVehicle_toolOffset.ToString();
            label156.Text = Properties.Settings.Default.setVehicle_toolOverlap.ToString();
            label158.Text = Properties.Settings.Default.setVehicle_toolWidth.ToString();
            label162.Text = Properties.Settings.Default.setVehicle_vehicleType.ToString();
            label164.Text = Properties.Settings.Default.setAS_isSteerInReverse.ToString();

            label251.Text = Settings.Default.setAS_deadZoneDelay.ToString();
            label252.Text = Settings.Default.setAS_deadZoneHeading.ToString();

            lblFrameTime.Text = mf.frameTime.ToString("N1");
            lblTimeSlice.Text = (1 / mf.timeSliceOfLastFix).ToString("N3");
            lblHz.Text = mf.gpsHz.ToString("N1");

            lblEastingField.Text = Math.Round(mf.pn.fix.easting, 2).ToString();
            lblNorthingField.Text = Math.Round(mf.pn.fix.northing, 2).ToString();

            //lblLatitude.Text = mf.Latitude;
            //lblLongitude.Text = mf.Longitude;

            //lblEastingField2.Text = Math.Round(mf.pnTwo.fix.easting, 2).ToString();
            //lblNorthingField2.Text = Math.Round(mf.pnTwo.fix.northing, 2).ToString();

            //lblLatitude2.Text = mf.pnTwo.latitude.ToString("N7");
            //lblLongitude2.Text = mf.pnTwo.longitude.ToString("N7");

            //other sat and GPS info
            lblSatsTracked.Text = mf.SatsTracked;
            lblHDOP.Text = mf.HDOP;

            lblIMUHeading.Text = mf.GyroInDegrees;
            lblFix2FixHeading.Text = mf.GPSHeading;
            lblFuzeHeading.Text = (mf.fixHeading * 57.2957795).ToString("N1");

            lblAngularVelocity.Text = mf.ahrs.imuYawRate.ToString("N2");

            lbludpWatchCounts.Text = mf.missedSentenceCount.ToString();

            if (mf.isMetric)
            {
                lblAltitude.Text = mf.Altitude;
            }
            else //imperial
            {
                lblAltitude.Text = mf.AltitudeFeet;
            }

            label254.Text = mf.FixQuality;
        }

        private void btnScreenShot_Click(object sender, EventArgs e)
        {
            Bitmap bm = new Bitmap(this.Width, this.Height);
            this.DrawToBitmap(bm, new Rectangle(0, 0, this.Width, this.Height));
            Clipboard.SetImage(bm);
            mf.TimedMessageBox(2000, "Captured", "Copied to Clipboard, Paste (CTRL-V) in Telegram");
            Log.EventWriter("View All Settings to Clipboard");
        }

        private void btnCreatePNG_Click(object sender, EventArgs e)
        {
            Bitmap bm = new Bitmap(this.Width, this.Height);
            this.DrawToBitmap(bm, new Rectangle(0, 0, this.Width, this.Height));
            bm.Save(Path.Combine(RegistrySettings.baseDirectory, "AllSet.PNG"), ImageFormat.Png);
            System.Diagnostics.Process.Start("explorer.exe", RegistrySettings.baseDirectory);
            Log.EventWriter("View All Settings to PNG");
            Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            LoadLabels();
        }

        private void FormAllSettings_Load(object sender, EventArgs e)
        {

            this.labelAckermann.Text = gStr.gsAckermann;
            this.labelAntennaHeight.Text = gStr.gsAntennaHeight;
            this.labelAntennaOffset.Text = gStr.gsAntennaOffset;
            this.labelAquireFactor.Text = gStr.gsAquireFactor;
            this.labelAutoOffAgIO.Text = gStr.gsAutoOffAgIO;
            this.labelAutoStartAgIO.Text = gStr.gsAutoStartAgIO;
            this.labelIMU.Text = gStr.gsIMU;
            this.labelInvertRoll.Text = gStr.gsInvertRoll;
            this.labelLookAhead.Text = gStr.gsLookAhead;
            this.labelTrack.Text = gStr.gsTrack;
            this.labelRollFilter.Text = gStr.gsRollFilter;
            this.labelRollZero.Text = gStr.gsRollZero;


            this.Text = gStr.gsFormAllSettings;
            this.label1StanleyUsed.Text = gStr.gsSettingStanleyUsed;
            this.label75.Text = gStr.gsSetting75;
            this.label78.Text = gStr.gsSetting78;
            this.label79.Text = gStr.gsSetting79;
            this.label87.Text = gStr.gsSetting87;
            this.label95.Text = gStr.gsSetting95;
            this.label99.Text = gStr.gsSetting99;
            this.labelAntennaPivot.Text = gStr.gsAntennaPivot;
            this.labelCPD.Text = gStr.gsCPD;
            this.labelCopyToClipboard.Text = gStr.gsCopyToClipboard;
            this.labelCreatePNG.Text = gStr.gsCreatePNG;
            this.labelCulture.Text = gStr.gsCulture;
            this.labelDeadZone.Text = gStr.gsDeadZone;
            this.labelDeadZoneDelay.Text = gStr.gsDeadZoneDelay;
            this.labelDirectory.Text = gStr.gsDirectory;
            this.labelDistanceError.Text = gStr.gsDistanceError;
            this.labelDualHeadingOffset.Text = gStr.gsDualHeadingOffset;
            this.labelDualReverseDist.Text = gStr.gsDualReverseDist;
            this.labelDualasIMU.Text = gStr.gsDualasIMU;
            this.labelEast.Text = gStr.gsEast;
            this.labelElev.Text = gStr.gsElev;
            this.labelFastSections.Text = gStr.gsFastSections;
            this.labelFix2Fix.Text = gStr.gsFix2Fix;
            this.labelFrame.Text = gStr.gsFrame;
            this.labelHDOP.Text = gStr.gsHDOP;
            this.labelHeadandSecControl.Text = gStr.gsHeadandSecControl;
            this.labelHeading.Text = gStr.gsHeading;
            this.labelHeadingError.Text = gStr.gsHeadingError;
            this.labelHighPWM.Text = gStr.gsHighPWM;
            this.labelHydraulicLIftLookAheadOn.Text = gStr.gsHydraulicLIftLookAheadOn;
            this.labelHz.Text = gStr.gsHz;
            this.labelKP.Text = gStr.gsKP;
            this.labelLowPWM.Text = gStr.gsLowPWM;
            this.labelLowSpeedCutOff.Text = gStr.gsLowSpeedCutOff;
            this.labelMaxAngularVelocity.Text = gStr.gsMaxAngularVelocity;
            this.labelMaxSteerDegree.Text = gStr.gsMaxSteerDegree;
            this.labelMinPWM.Text = gStr.gsMinPWM;
            this.labelMinUturnRadius.Text = gStr.gsMinUturnRadius;
            this.labelMissed.Text = gStr.gsMissed;
            this.labelNorth.Text = gStr.gsNorth;
            this.labelNumberOfSats.Text = gStr.gsNumberOfSats;
            this.labelNumberOfSections.Text = gStr.gsNumberOfSections;
            this.labelPPIntegral.Text = gStr.gsPPIntegral;
            this.labelPanicStop.Text = gStr.gsPanicStop;
            this.labelPivotBehindAnt.Text = gStr.gsPivotBehindAnt;
            this.labelRTKAlarm.Text = gStr.gsRTKAlarm;
            this.labelRTKAlarmKillSteer.Text = gStr.gsRTKAlarmKillSteer;
            this.labelRawHz.Text = gStr.gsRawHz;
            this.labelRefSnapDistance.Text = gStr.gsRefSnapDistance;
            this.labelRemoteWork.Text = gStr.gsRemoteWork;
            this.labelReverseOn.Text = gStr.gsReverseOn;
            this.labelSectionOffOutBounds.Text = gStr.gsSectionOffOutBounds;
            this.labelSectionsNotAsZones.Text = gStr.gsSectionsNotAsZones;
            this.labelSideHillDemo.Text = gStr.gsSideHillDemo;
            this.labelSnapDistance.Text = gStr.gsSnapDistance;
            this.labelSpeedFactor.Text = gStr.gsSpeedFactor;
            this.labelStanleyIntegral.Text = gStr.gsStanleyIntegral;
            this.labelSteerAxleBehind.Text = gStr.gsSteerAxleBehind;
            this.labelSteerInReverse.Text = gStr.gsSteerInReverse;
            this.labelSteerWork.Text = gStr.gsSteerWork;
            this.labelSteerWorkMan.Text = gStr.gsSteerWorkMan;
            this.labelTankHitchLength.Text = gStr.gsTankHitchLength;
            this.labelToolFront.Text = gStr.gsToolFront;
            this.labelToolLookAheadOff.Text = gStr.gsToolLookAheadOff;
            this.labelToolLookAheadOn.Text = gStr.gsToolLookAheadOn;
            this.labelToolOffDelay.Text = gStr.gsToolOffDelay;
            this.labelToolOffset.Text = gStr.gsToolOffset;
            this.labelToolOverlap.Text = gStr.gsToolOverlap;
            this.labelToolRearFixed.Text = gStr.gsToolRearFixed;
            this.labelToolTBT.Text = gStr.gsToolTBT;
            this.labelToolToPivot.Text = gStr.gsToolToPivot;
            this.labelToolTrailing.Text = gStr.gsToolTrailing;
            this.labelToolWidth.Text = gStr.gsToolWidth;
            this.labelTrailingHitchLength.Text = gStr.gsTrailingHitchLength;
            this.labelVehicleHitchLength.Text = gStr.gsVehicleHitchLength;
            this.labelVehicleType.Text = gStr.gsVehicleType;
            this.labelWasOffset.Text = gStr.gsWasOffset;
            this.labelWheelbase.Text = gStr.gsWheelbase;
            this.labelWorkActiveLow.Text = gStr.gsWorkActiveLow;
            this.labelWorkManualSec.Text = gStr.gsWorkManualSec;
            this.labelWorkSwitch.Text = gStr.gsWorkSwitch;
            this.lblAltitude.Text = gStr.gsAltitude;
            this.lblEastingField.Text = gStr.gsEastingField;
            this.lblFrameTime.Text = gStr.gsFrameTime;
            this.lblHDOP.Text = gStr.gsHDOP;
            this.lblHz.Text = gStr.gsHz;
            this.lblNorthingField.Text = gStr.gsNorthingField;
            this.lblSatsTracked.Text = gStr.gsSatsTracked;
            this.lblTimeSlice.Text = gStr.gsMsec;
            this.lbludpWatchCounts.Text = gStr.gsMsec;

            this.labelWorkSwitch.Text = gStr.gsWorkSwitch;
            this.labelRollZero.Text = gStr.gsRollZero;
            this.labelWheelbase.Text = gStr.gsWheelbase;
            this.labelTrack.Text = gStr.gsTrack;

        }
    }
}