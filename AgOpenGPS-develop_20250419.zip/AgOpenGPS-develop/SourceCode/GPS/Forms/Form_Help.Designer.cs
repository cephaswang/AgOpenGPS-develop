﻿namespace AgOpenGPS
{
    partial class Form_Help
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelUpdate = new System.Windows.Forms.Label();
            this.labelDiscuss = new System.Windows.Forms.Label();
            this.linkLabelGit = new System.Windows.Forms.LinkLabel();
            this.linkLabelCombineForum = new System.Windows.Forms.LinkLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.lblVersion = new System.Windows.Forms.Label();
            this.linkLabelYouTube = new System.Windows.Forms.LinkLabel();
            this.labelYotube = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // labelUpdate
            // 
            this.labelUpdate.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.labelUpdate.Location = new System.Drawing.Point(270, 5);
            this.labelUpdate.Name = "labelUpdate";
            this.labelUpdate.Size = new System.Drawing.Size(398, 28);
            this.labelUpdate.TabIndex = 16;
            this.labelUpdate.Text = "Check for Updates\r\n";
            // 
            // labelDiscuss
            // 
            this.labelDiscuss.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.labelDiscuss.Location = new System.Drawing.Point(4, 5);
            this.labelDiscuss.Name = "labelDiscuss";
            this.labelDiscuss.Size = new System.Drawing.Size(260, 28);
            this.labelDiscuss.TabIndex = 15;
            this.labelDiscuss.Text = "Discussions at....";
            // 
            // linkLabelGit
            // 
            this.linkLabelGit.AutoSize = true;
            this.linkLabelGit.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelGit.Location = new System.Drawing.Point(270, 43);
            this.linkLabelGit.Name = "linkLabelGit";
            this.linkLabelGit.Size = new System.Drawing.Size(407, 19);
            this.linkLabelGit.TabIndex = 11;
            this.linkLabelGit.TabStop = true;
            this.linkLabelGit.Text = "https://github.com/farmerbriantee/AgOpenGPS/releases";
            this.linkLabelGit.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelGit_LinkClicked);
            // 
            // linkLabelCombineForum
            // 
            this.linkLabelCombineForum.AutoSize = true;
            this.linkLabelCombineForum.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelCombineForum.Location = new System.Drawing.Point(4, 43);
            this.linkLabelCombineForum.Name = "linkLabelCombineForum";
            this.linkLabelCombineForum.Size = new System.Drawing.Size(251, 19);
            this.linkLabelCombineForum.TabIndex = 12;
            this.linkLabelCombineForum.TabStop = true;
            this.linkLabelCombineForum.Text = "https://discourse.agopengps.com/";
            this.linkLabelCombineForum.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelCombineForum_LinkClicked);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::AgOpenGPS.Properties.Resources.AgOpenYouTubeChannel;
            this.pictureBox1.Location = new System.Drawing.Point(484, 92);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(184, 169);
            this.pictureBox1.TabIndex = 557;
            this.pictureBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Image = global::AgOpenGPS.Properties.Resources.OK64;
            this.button1.Location = new System.Drawing.Point(578, 302);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 65);
            this.button1.TabIndex = 10;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // lblVersion
            // 
            this.lblVersion.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVersion.Location = new System.Drawing.Point(4, 118);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(237, 38);
            this.lblVersion.TabIndex = 34;
            this.lblVersion.Text = "Version";
            // 
            // linkLabelYouTube
            // 
            this.linkLabelYouTube.AutoSize = true;
            this.linkLabelYouTube.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelYouTube.Location = new System.Drawing.Point(28, 324);
            this.linkLabelYouTube.Name = "linkLabelYouTube";
            this.linkLabelYouTube.Size = new System.Drawing.Size(354, 19);
            this.linkLabelYouTube.TabIndex = 11;
            this.linkLabelYouTube.TabStop = true;
            this.linkLabelYouTube.Text = "https://www.youtube.com/@AgOpenGPS/videos";
            this.linkLabelYouTube.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelYouTube_LinkClicked);
            // 
            // labelYotube
            // 
            this.labelYotube.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelYotube.Location = new System.Drawing.Point(12, 257);
            this.labelYotube.Name = "labelYotube";
            this.labelYotube.Size = new System.Drawing.Size(229, 33);
            this.labelYotube.TabIndex = 558;
            this.labelYotube.Text = "YouTube Tutorials";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::AgOpenGPS.Properties.Resources.boundaryPlay;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox2.Location = new System.Drawing.Point(247, 238);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(88, 71);
            this.pictureBox2.TabIndex = 559;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Form_Help
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(689, 371);
            this.ControlBox = false;
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.labelYotube);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblVersion);
            this.Controls.Add(this.labelUpdate);
            this.Controls.Add(this.labelDiscuss);
            this.Controls.Add(this.linkLabelYouTube);
            this.Controls.Add(this.linkLabelGit);
            this.Controls.Add(this.linkLabelCombineForum);
            this.Controls.Add(this.button1);
            this.MinimizeBox = false;
            this.Name = "Form_Help";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "AgOpenGPS Help";
            this.Load += new System.EventHandler(this.Form_About_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label labelUpdate;
        private System.Windows.Forms.Label labelDiscuss;
        private System.Windows.Forms.LinkLabel linkLabelGit;
        private System.Windows.Forms.LinkLabel linkLabelCombineForum;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.LinkLabel linkLabelYouTube;
        private System.Windows.Forms.Label labelYotube;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}