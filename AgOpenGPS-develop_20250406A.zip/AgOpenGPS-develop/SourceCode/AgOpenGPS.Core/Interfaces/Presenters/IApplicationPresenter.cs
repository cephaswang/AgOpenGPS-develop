﻿namespace AgOpenGPS.Core.Interfaces
{
    public interface IApplicationPresenter
    {
        IErrorPresenter ErrorPresenter { get; }
    }
}

