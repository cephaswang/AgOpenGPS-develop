﻿using System.Windows.Controls;

namespace AgOpenGPS.WpfApp.ViewportViews
{
    public partial class SimulatorBar : UserControl
    {
        public SimulatorBar()
        {
            InitializeComponent();
        }
    }
}
