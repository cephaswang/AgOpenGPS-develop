﻿using System.Windows.Controls;

namespace AgOpenGPS.WpfApp.MainViews
{
    public partial class HeaderBar : UserControl
    {
        public HeaderBar()
        {
            InitializeComponent();
        }
    }
}
