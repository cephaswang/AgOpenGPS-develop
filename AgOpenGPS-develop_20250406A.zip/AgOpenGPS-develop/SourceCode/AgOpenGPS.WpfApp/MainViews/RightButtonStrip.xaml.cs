﻿using System.Windows.Controls;

namespace AgOpenGPS.WpfApp.MainViews
{
    public partial class RightButtonStrip : UserControl
    {
        public RightButtonStrip()
        {
            InitializeComponent();
        }
    }
}
