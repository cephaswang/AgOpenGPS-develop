﻿using System.Windows;

namespace AgOpenGPS.WpfApp.Field
{
    public partial class CreateFromExistingFieldDialog : Window
    {
        public CreateFromExistingFieldDialog()
        {
            InitializeComponent();
        }
    }
}
