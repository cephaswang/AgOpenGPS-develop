﻿using System.Windows;

namespace AgOpenGPS.WpfApp.Field
{
    public partial class SelectNearFieldDialog : Window
    {
        public SelectNearFieldDialog()
        {
            InitializeComponent();
        }
    }
}
